<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\API\CartController;
use App\Http\Controllers\API\OrderController;
use App\Http\Controllers\API\AddressController;
use App\Http\Controllers\API\CompanyController;
use App\Http\Controllers\API\ProductController;
use App\Http\Controllers\API\CategoryController;
use App\Http\Controllers\API\AdsController;
use App\Http\Controllers\API\GeneralController;
use App\Http\Controllers\API\StoreController;
use App\Http\Controllers\API\PassportAuthController;
use App\Http\Controllers\API\OrderOrderDetailsController;
use App\Http\Controllers\API\UserController;



/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "api" middleware group. Make something great!
|
*/

Route::post('register', [PassportAuthController::class, 'register']);
Route::post('api/login', [PassportAuthController::class, 'login']);
Route::post('verify', [PassportAuthController::class, 'verify']);

Route::post('search', [GeneralController::class, 'search']);

Route::apiResource('products', ProductController::class);

Route::get('products/show_by_category/{category_id}', [ProductController::class, 'show_by_category']);
Route::get('products/show_by_company/{company_id}', [ProductController::class, 'show_by_company']);

Route::apiResource('companies', CompanyController::class);

Route::apiResource('categories', CategoryController::class);
Route::get('categories/show_by_parent/{parent_id}', [CategoryController::class, 'show_by_parent']);
Route::apiResource('ads', AdsController::class);

Route::get('terms', function () {
    $html = <<<HTML
    <!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>🛡️ اتفاقية الخصوصية لتطبيق عين الفرات</title>
  <style>
    body {
      font-family: "Tajawal", "Cairo", sans-serif;
      direction: rtl;
      text-align: right;
      background-color: #f9fafb;
      color: #222;
      margin: 0;
      padding: 20px;
      line-height: 1.8;
    }
    h1, h2 { color: #0a3d62; }
    h1 { text-align: center; margin-bottom: 30px; }
    section {
      background: #fff;
      padding: 20px;
      margin-bottom: 20px;
      border-radius: 10px;
      box-shadow: 0 2px 6px rgba(0,0,0,0.1);
    }
    ul { list-style-type: "• "; padding-right: 20px; }
    strong { color: #1e3799; }
    footer { text-align: center; margin-top: 30px; font-size: 0.9em; color: #555; }
    @media (max-width:600px){
      body { padding: 12px; }
      section { padding: 16px; }
    }
  </style>
</head>
<body>

  <h1>🛡️ اتفاقية الخصوصية لتطبيق عين الفرات</h1>

  <p><strong>آخر تحديث:</strong> 17 أكتوبر 2025</p>

  <section>
    <p>
      مرحبًا بك في تطبيق <strong>عين الفرات</strong> (“نحن” أو “التطبيق”).
      نحن نحترم خصوصيتك ونلتزم بحماية بياناتك الشخصية. تهدف هذه السياسة إلى توضيح كيفية جمعنا واستخدامنا وحماية معلوماتك عند استخدامك للتطبيق.
    </p>
  </section>

  <section>
    <h2>1. المعلومات التي نجمعها</h2>
    <p>نقوم بجمع أنواع مختلفة من المعلومات لتقديم خدمة أفضل لك، وتشمل:</p>

    <p><strong>أ. المعلومات الشخصية:</strong></p>
    <ul>
      <li>الاسم الكامل</li>
      <li>رقم الهاتف</li>
      <li>البريد الإلكتروني</li>
      <li>عنوان الشحن أو موقع التسليم</li>
      <li>بيانات الدفع (مثل بطاقات الائتمان أو المحافظ الإلكترونية) عبر مزودي خدمة آمنين</li>
    </ul>

    <p><strong>ب. المعلومات غير الشخصية:</strong></p>
    <ul>
      <li>نوع الجهاز ونظام التشغيل</li>
      <li>عنوان IP</li>
      <li>البيانات التحليلية مثل مدة الجلسة وسلوك التصفح داخل التطبيق</li>
    </ul>
  </section>

  <section>
    <h2>2. كيفية استخدام المعلومات</h2>
    <ul>
      <li>إنشاء حساب المستخدم وإدارته</li>
      <li>معالجة الطلبات والمدفوعات</li>
      <li>تحسين تجربة المستخدم والخدمة</li>
      <li>إرسال إشعارات حول الطلبات والعروض</li>
      <li>الامتثال للالتزامات القانونية ومكافحة الاحتيال</li>
    </ul>
  </section>

  <section>
    <h2>3. مشاركة البيانات</h2>
    <p>قد نشارك بياناتك مع أطراف ثالثة في الحالات التالية فقط:</p>
    <ul>
      <li><strong>مزودو الدفع:</strong> لمعالجة المعاملات بأمان.</li>
      <li><strong>شركات الشحن:</strong> لتوصيل الطلبات إلى عنوانك.</li>
      <li><strong>الجهات القانونية:</strong> إذا طُلب منا ذلك بموجب القانون أو لحماية حقوقنا القانونية.</li>
    </ul>
    <p><strong>نحن لا نبيع أو نؤجر بياناتك لأي طرف ثالث لأي سبب تجاري.</strong></p>
  </section>

  <section>
    <h2>4. حماية البيانات</h2>
    <ul>
      <li>تشفير البيانات الحساسة أثناء النقل والتخزين.</li>
      <li>تقييد الوصول إلى البيانات داخل الشركة.</li>
      <li>مراجعة دورية لإجراءات الأمان.</li>
    </ul>
  </section>

  <section>
    <h2>5. حقوق المستخدم</h2>
    <ul>
      <li>الوصول إلى بياناتك الشخصية.</li>
      <li>طلب تصحيح أو حذف بياناتك.</li>
      <li>سحب الموافقة على استخدام بياناتك في أي وقت.</li>
    </ul>
  </section>

  <section>
    <h2>6. ملفات تعريف الارتباط (Cookies)</h2>
    <p>قد نستخدم ملفات تعريف الارتباط لتحسين تجربة التصفح داخل التطبيق وتحليل الأداء. يمكنك تعطيلها من إعدادات جهازك، لكن ذلك قد يؤثر على بعض الوظائف.</p>
  </section>

  <section>
    <h2>7. التغييرات على سياسة الخصوصية</h2>
    <p>قد نقوم بتحديث هذه السياسة من وقت لآخر. سيتم إخطارك عبر التطبيق أو البريد الإلكتروني عند إجراء أي تعديل جوهري.</p>
  </section>

  <footer>© 2025 تطبيق عين الفرات — جميع الحقوق محفوظة.</footer>

</body>
</html>

HTML;

    return response($html, 200)
        ->header('Content-Type', 'text/html; charset=UTF-8');
});

Route::middleware('auth:api')->group(function () {
    Route::get('get-user', [PassportAuthController::class, 'userInfo']);
    Route::post('delete_account', [PassportAuthController::class, 'delete_account']);

    Route::apiResource('cart', CartController::class);

    //  Route::apiResource('order_details', OrderDetailsController::class);

    //  Route::apiResource('orders', OrderController::class);

    Route::apiResource('orders', OrderController::class);
    Route::post('/orders/get_agent_orders', [OrderController::class, 'get_agent_orders']);

    Route::get('/agents/change_status', [OrderController::class, 'change_status']);

    Route::apiResource('address', AddressController::class);
    Route::apiResource('store', StoreController::class);
});

Route::middleware('auth:sanctum')->get('/user', function (Request $request) {
    return $request->user();
});
