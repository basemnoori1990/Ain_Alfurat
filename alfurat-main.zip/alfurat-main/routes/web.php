<?php

use App\Http\Controllers\AdminController;
use App\Http\Controllers\RoleController;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\UserController;
use App\Http\Controllers\UnitController;
use App\Http\Controllers\UnitgroupsController;
use App\Http\Controllers\ProductController;
use App\Http\Controllers\CategoryController;
use App\Http\Controllers\CompanyController;
use App\Http\Controllers\AdsController;
use App\Http\Controllers\Category_specificationsController;
use App\Http\Controllers\WeborderController;
use App\Http\Controllers\Auth\LoginController;
use App\Http\Controllers\PermissionController;
use App\Http\Controllers\SettingsController;


/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/statuses/{id}', function ($id) {
    $Order = new \App\Models\Order;
    //    dd($Order->statuses($id));
});
Route::get('/', function () {
    return view('dashboard');
})->name('dashboard')->middleware('permission:لوحة التحكم');;

Route::get('login', function () {
    return view('auth.login');
})->name('login');

Route::post('login', [LoginController::class, 'login'])->name('auth.login');

Route::middleware('auth:web')->group(function () {

    Route::get(
        'logout',
        function () {
            auth()->logout();
            return redirect('/login');
        }
    )->name('logout');

    Route::resource('/permissions', PermissionController::class)->only(['store'])->middleware('permission:الصلاحيات');;
    Route::resource('/roles', RoleController::class)->except(['show', 'create'])->middleware('permission:الصلاحيات');
    Route::middleware('permission:المسئولون')->group(function () {
        Route::resource('/admins', AdminController::class);
        Route::get('/admins/status/{id}', [AdminController::class, 'change_status'])->name('admins.status');
        Route::get('/admins_get_archive', [AdminController::class, 'get_archive'])->name('admins.get_archive');
        Route::get('/admins_restore/{id}', [AdminController::class, 'restore_archive'])->name('admins.restore_archive');
    });

    Route::middleware('permission:المستخدمون')->group(function () {
        Route::resource('/users', UserController::class);
        Route::get('/users_get_archive', [UserController::class, 'get_archive'])->name('users.get_archive');
        Route::get('/users_restore/{id}', [UserController::class, 'restore_archive'])->name('users.restore_archive');
        Route::post('/users/change_status', [UserController::class, 'change_status'])->name('users.change_status');
    });
    Route::middleware('permission:المناديب')->group(function () {
        Route::get('/agents', [UserController::class, 'agents'])->name('agents');
        Route::post('/agents/add_agent', [UserController::class, 'add_agent'])->name('agents.add_agent');
        Route::get('/agents/{agent}/edit_agent', [UserController::class, 'edit_agent'])->name('agents.edit');
        Route::put('/agents/update/{agent}', [UserController::class, 'update_agent'])->name('agents.update');
        Route::delete('/agents/destroy/{agent}', [UserController::class, 'update_agent'])->name('agents.update');
        Route::get('/agents_get_archive', [UserController::class, 'agents_get_archive'])->name('agents.get_archive');
    });
    Route::middleware('permission:الوحدات')->group(function () {
        Route::post('/units/get_units_by_unit_group', [UnitController::class, 'get_units_by_unit_group'])->name('units.get_units_by_unit_group');
        Route::resource('/units', UnitController::class);
        Route::post('/units/change_status', [UnitController::class, 'change_status'])->name('units.change_status');
        Route::get('/units_get_archive', [UnitController::class, 'get_archive'])->name('units.get_archive');
        Route::get('/units_restore/{id}', [UnitController::class, 'restore_archive'])->name('units.restore_archive');
    });
    Route::middleware('permission:مجموعات الوحدات')->group(function () {
        Route::resource('/unitgroups', UnitgroupsController::class);
        Route::post('/unitgroups/change_status', [UnitgroupsController::class, 'change_status'])->name('unitgroups.change_status');
        Route::post('/unitgroups/change_status', [UnitgroupsController::class, 'change_status'])->name('unitgroups.change_status');
        Route::get('/unitgroups_get_archive', [UnitgroupsController::class, 'get_archive'])->name('unitgroups.get_archive');
        Route::get('/unitgroups_restore/{id}', [UnitgroupsController::class, 'restore_archive'])->name('unitgroups.restore_archive');
    });
    Route::middleware('permission:المنتجات')->prefix('web')->group(function () {
        Route::resource('products', ProductController::class)->names([
            'index' => 'web.products.index',
            'show' => 'web.products.show',
            'store' => 'web.products.store',
            'update' => 'web.products.update',
            'destroy' => 'web.products.destroy',
        ]);
    });

    Route::middleware('permission:المنتجات')->group(function () {
        Route::get('/products/required_products/{product_id}', [ProductController::class, 'required_products'])->name('required_products');
        Route::post('/products/add_required_product', [ProductController::class, 'add_required_product'])->name('/products/add_required_product');
        Route::get('/products/get_product_units/{product_id}', [ProductController::class, 'get_product_units']);
        Route::post('/products/change_status', [ProductController::class, 'change_status'])->name('products.change_status');
        Route::get('/products/get_products/{product_id}', [ProductController::class, 'get_products']);
        Route::get('/products_get_archive', [ProductController::class, 'get_archive'])->name('products.get_archive');
        Route::get('/products_restore/{id}', [ProductController::class, 'restore_archive'])->name('products.restore_archive');
    });

    Route::middleware('permission:المجموعات')->group(function () {
        Route::resource('/categories', CategoryController::class)->names([
            'index' => 'web.categories.index',
            'show' => 'web.categories.show',
            'store' => 'web.categories.store',
            'update' => 'web.categories.update',
            'destroy' => 'web.categories.destroy',
        ]);
        Route::post('/categories/change_status', [CategoryController::class, 'change_status'])->name('categories.change_status');
        Route::post('/categories/get_sub_categories', [CategoryController::class, 'get_sub_categories'])->name('categories.get_sub_categories');
        Route::get('/categories_get_archive', [CategoryController::class, 'get_archive'])->name('categories.get_archive');
        Route::get('/categories_restore/{id}', [CategoryController::class, 'restore_archive'])->name('categories.restore_archive');
    });

    Route::middleware('permission:الشركات')->group(function () {
        Route::resource('/companies', CompanyController::class)->names([
            'index' => 'web.companies.index',
            'show' => 'web.companies.show',
            'store' => 'web.companies.store',
            'update' => 'web.companies.update',
            'destroy' => 'web.companies.destroy',
        ]);
        Route::post('/companies/change_status', [CompanyController::class, 'change_status'])->name('companies.change_status');
        Route::get('/companies_archive', [CompanyController::class, 'get_archive'])->name('companies.get_archive');
        Route::get('/companies_restore_archive/{id}', [CompanyController::class, 'restore_archive'])->name('companies.restore_archive');
    });

    Route::middleware('permission:الإعلانات')->group(function () {
        Route::resource('/ads', AdsController::class)->names([
            'index' => 'web.ads.index',
            'show' => 'web.ads.show',
            'store' => 'web.ads.store',
            'update' => 'web.ads.update',
            'destroy' => 'web.ads.destroy',
        ]);
        Route::post('/ads/change_status', [AdsController::class, 'change_status'])->name('ads.change_status');
        Route::get('/ads_get_archive', [AdsController::class, 'get_archive'])->name('ads.get_archive');
        Route::get('/ads_restore/{id}', [AdsController::class, 'restore_archive'])->name('ads.restore_archive');
    });

    Route::middleware('permission:خواص المنتجات')->group(function () {
        Route::resource('/categoryspecifications', Category_specificationsController::class);
        Route::get('/categoryspecifications_get_archive', [Category_specificationsController::class, 'get_archive'])->name('categoryspecifications.get_archive');
        Route::get('/categoryspecifications_restore/{id}', [Category_specificationsController::class, 'restore_archive'])->name('categoryspecifications.restore_archive');

        Route::post('/categoryspecifications/change_status', [WeborderController::class, 'change_status'])->name('categoryspecifications.change_status');
        Route::resource('/weborders', WeborderController::class)->names([
            'index' => 'web.orders.index',
            'show' => 'web.orders.show',
            'store' => 'web.orders.store',
            'update' => 'web.orders.update',
            'destroy' => 'web.orders.destroy',
        ]);
    });
    Route::middleware('permission:الطلبات')->group(function () {
        Route::post('/orders/change_status', [WeborderController::class, 'change_status'])->name('orders.change_status');
        Route::post('/orders/change_order_status', [WeborderController::class, 'change_status'])->name('orders.change_order_status');
        Route::get('/orders/print_order/{id}', [WeborderController::class, 'print_order'])->name('orders.print_order');
        Route::post('/orders/change_agent', [WeborderController::class, 'change_agent'])->name('orders.change_agent');
        Route::get('/weborders_get_archive', [WeborderController::class, 'get_archive'])->name('weborders.get_archive');
        Route::get('/weborders_restore/{id}', [WeborderController::class, 'restore_archive'])->name('weborders.restore_archive');
    });
    Route::get('/home', [App\Http\Controllers\HomeController::class, 'index'])->name('home');
    Route::resource('/settings', SettingsController::class)->middleware('permission:الضبط');
    Route::get(
        '/map',
        function () {
            return view('map');
        }
    )->name('map');
    Route::view('/profile', 'profile')->name('profile');

    Route::get('/config-cache', function () {
        Artisan::call('config:cache');
        // Do whatever you want either a print a message or exit
    });
    Route::get('/migrate', function () {
        Artisan::call('migrate');
        // Do whatever you want either a print a message or exit
    });
});
