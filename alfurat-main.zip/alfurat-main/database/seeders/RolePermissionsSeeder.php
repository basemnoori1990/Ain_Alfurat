<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Spatie\Permission\Models\Permission;
use Spatie\Permission\Models\Role;
use Illuminate\Support\Str;
use App\Models\Admin;

class RolePermissionsSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        //
        $permissions = [
            'لوحة التحكم',
            'المسئولون',
            'الصلاحيات',
            'الشركات',
            'المستخدمون',
            'العملاء',
            'خواص المنتجات',
            'المجموعات',
            'المنتجات',
            'المناديب',
            'الطلبات',
            'الوحدات',
            'مجموعات الوحدات',
            'الإعلانات',
            'الضبط',
        ];

        foreach ($permissions as $permission) {
            Permission::firstOrCreate([
                'name' => $permission,
                'guard_name' => 'web',
            ]);
        }

        $adminRole = Role::firstOrCreate([
            'name' => 'المالك',
            'guard_name' => 'web',
        ]);

        $adminRole->syncPermissions($permissions);

        $admin = Admin::find(1);
        // create([
        //     'name' => 'admin',
        //     'email' => 'admin@dinar.com',
        //     'email_verified_at' => now(),
        //     'password' => bcrypt('password'),
        //     'remember_token' => Str::random(10),
        // ]);

        $admin->assignRole($adminRole);
    }

    
}
