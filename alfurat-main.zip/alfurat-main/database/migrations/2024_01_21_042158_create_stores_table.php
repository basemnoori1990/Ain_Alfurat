<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        if (!Schema::hasTable('stores')) {

            Schema::create('stores', function (Blueprint $table) {
                $table->id();
                $table->text('owner_name');
                $table->text('store_name');
                $table->text('district');
                $table->text('address');
                $table->text('phone');
                $table->decimal('lng',18,8);
                $table->decimal('lat',18,8);
                $table->foreignId('user_id')->constraint('users')->onDelete('cascade');
                $table->tinyinteger('status')->default(1);
                $table->softDeletes();
                $table->timestamps();
            });}
        }
    
        /**
         * Reverse the migrations.
         */
        public function down(): void
        {
            Schema::dropIfExists('stores');
    }
};
