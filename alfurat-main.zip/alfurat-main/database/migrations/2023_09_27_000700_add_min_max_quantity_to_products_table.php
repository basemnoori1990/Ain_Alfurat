<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
            if (Schema::hasTable('products')) {
                Schema::table('products', function (Blueprint $table) {
                        $table->decimal('min_whole_quantity', 24, 6)->default(5);
                        $table->decimal('min_retail_quantity', 24, 6)->default(5);
                        $table->decimal('min_vip_quantity', 24, 6)->default(5);
                        $table->decimal('max_whole_quantity', 24, 6)->default(-1);
                        $table->decimal('max_retail_quantity', 24, 6)->default(-1);
                });
            }
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('products', function (Blueprint $table) {
            $table->dropColumn('min_whole_quantity');
            $table->dropColumn('min_retail_quantity');
            $table->dropColumn('min_vip_quantity');
            $table->dropColumn('max_whole_quantity');
            $table->dropColumn('max_retail_quantity');
        });
    }
};
