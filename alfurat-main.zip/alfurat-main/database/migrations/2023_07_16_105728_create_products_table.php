<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        if (!Schema::hasTable('products')) {
    
        Schema::create('products', function (Blueprint $table) {
            $table->id();
            $table->text('product_name');
            $table->text('description');
            $table->text('image');
            $table->decimal('whole_sale_price',18,4)->default('0.00');
            $table->decimal('retail_price',18,4)->default('0.00');
            $table->decimal('vip_price',18,4)->default('0.00');
            // $table->nullable();
            $table->integer('category_id');
            $table->integer('company_id');
            $table->integer('unit_group_id')->nullable();
            $table->integer('whole_unit_id')->nullable();
            $table->integer('retail_unit_id')->nullable();
            $table->integer('vip_unit_id')->nullable();
            // $table->foreign('category_id')->references('id')->on('categories');
            $table->decimal('discount',3,2)->default('0.00');
            $table->tinyinteger('status')->default(1);
            $table->softDeletes();
            $table->timestamps();
        });
    }
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('products');
    }
};
