<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        if (Schema::hasTable('users')) {

       
                Schema::table('users', function (Blueprint $table) {
                    $table->text('country_code')->nullable();
                    $table->text('verification_code')->nullable();
                    $table->datetime('expire_at')->nullable();
                    $table->tinyInteger('phone_verified')->nullable();
                    $table->text('token_device')->nullable();
                    $table->text('current_device_id')->nullable();
                }
            );
        
    }         
    }


    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('users', function (Blueprint $table) {
            $table->dropColumn('country_code');
            $table->dropColumn('verification_code');
            $table->dropColumn('expire_at');
            $table->dropColumn('phone_verified');
            $table->dropColumn('token_device');
            $table->dropColumn('current_device_id');
        });
    }
};
