<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        if (!Schema::hasTable('categories')) {
    
        Schema::create('categories', function (Blueprint $table) {
            $table->increments('id');
            $table->text('category_name');
            $table->text('description');
            $table->text('image')->nullable();
            $table->integer('level')->default(1);
            $table->integer('parent_id')->nullable();
            // $table->foreign('parent_id')->references('id')->on('categories');
            $table->tinyinteger('status')->default(1);
            $table->softDeletes();
            $table->timestamps();
        });
        //->nullable();
        //$table->softDeletes();
//        $table->foreign('user_id')->references('id')->on('users');

    }
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('categories');
    }
};
