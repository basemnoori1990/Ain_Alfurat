$(function(){
    
    $('#order_status').on('change',function(e)
    {
        alert(e.id)
    })
})