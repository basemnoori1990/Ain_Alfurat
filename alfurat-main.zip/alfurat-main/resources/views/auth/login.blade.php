<?php
session_start();

?>
<!DOCTYPE html >
<html lang="en"dir="rtl" ng-app="app">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="مجموعة عين الفرات التجاري والتقنية">
    <meta name="author" content="JUST IT">
    <meta name="keyword" content="مجموعة عين الفرات التجاري والتقنية">
    <!-- <link rel="shortcut icon" href="assets/ico/favicon.png"> -->
    <title>عين الفرات التجاري والتقنية</title>
    <!-- Icons -->
    <link href="{{asset('css/font-awesome.min.css')}}" rel="stylesheet">
    <link href="{{asset('css/simple-line-icons.css')}}" rel="stylesheet">
    <!--<script src="https://ajax.googleapis.com/ajax/libs/angularjs/1.7.8/angular.min.js"></script>-->
    <!-- Main styles for this application -->
    <link href="{{asset('dest/style.css')}}" rel="stylesheet">
</head>

<body class="">
    <div class="container">
        <div class="row">
        <form name="form" method="post" action="{{route('auth.login')}}" id="LoginForm">
            @csrf
            <div class="col-md-8 m-x-auto pull-xs-none vamiddle">
                <div class="card-group ">
                    <div class="card card-inverse card-primary p-y-3" style="width:44%">
                        <div class="card-block text-xs-center">
                            <div>
                                <h2>مجموعة عين الفرات التجاري والتقنية</h2>
                                @if (\Session::has('success'))
                                    <div class="alert alert-success">
                                        <ul>
                                            <li>{!! \Session::get('msg') !!}</li>
                                        </ul>
                                    </div>
                                @endif
                               {{-- <img src="images/logo.png"> --}}
                                <!--
                                     <p>نظام البلاغات</p><button type="button" class="btn btn-primary active m-t-1"></button>-->
                            </div>
                        </div>
                    </div>
                    <div class="card p-a-2">
                        <div class="card-block">
                            <h1>مرحبا</h1>
                            <p class="text-muted">تسجيل الدخول</p>
                            <div class="input-group m-b-1">
                                <span class="input-group-addon"><i class="icon-user"></i>
                                </span>
                                <input type="text" name="email" class="form-control en" placeholder="البريد الإلكتروني">
                            </div>
                            <div class="input-group m-b-2">
                                <span class="input-group-addon"><i class="icon-lock"></i>
                                </span>
                                <input type="password" name="password" class="form-control en" placeholder="كلمة المرور">
                            </div>
                            <div class="row">
                                <div class="col-xs-6">
                                    <button type="submit"  class="btn btn-primary p-x-2">
                                        <i class="icon-login"></i>
                                        تسجيل دخول</button>
                                </div>
                                <div class="col-xs-6 text-xs-right">
                                    <button type="button" class="btn btn-link p-x-0">فقدان كلمة المرور</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
</form>
        </div>
    </div>
    <!-- Bootstrap and necessary plugins -->
    <script src="{{asset('js\libs\jquery.min.js')}}"></script>
    <script src="https://npmcdn.com/tether@1.2.4/dist/js/tether.min.js"></script>
    <script src="{{asset('js\libs\bootstrap.min.js')}}"></script>
    <script>
        function verticalAlignMiddle()
        {
            var bodyHeight = $(window).height();
            var formHeight = $('.vamiddle').height();
            var marginTop = (bodyHeight / 2) - (formHeight / 2);
            if (marginTop > 0)
            {
                $('.vamiddle').css('margin-top', marginTop);
            }
        }
        $(document).ready(function()
        {
            verticalAlignMiddle();
        });
        $(window).bind('resize', verticalAlignMiddle);
    

</script>
     
</body>

</html>

