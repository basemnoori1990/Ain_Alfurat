@include('layouts.header')
@include('layouts.nav', [
    'breadcrumbs' => [['title' => 'المسئولون', 'route' => route('admins.index'), 'icon' => 'icon-people']],
])
<div class="container-fluid">

    <div class="animated fadeIn container-fluid">
        <div class="row">
            <div class='col-lg-6'>
                <form method="POST" action="{{ route('admins.store') }}">
                    @csrf
                    @if (session()->has('success'))
                        <div class="alert alert-success">{{ session('success') }}</div>
                    @endif
                    @if (session()->has('error'))
                        <div class="alert alert-success">{{ session('error') }}</div>
                    @endif
                    <div class="form-group">
                        <label for="specification_name">الاسم</label>
                        <input class="form-control" name='name'>
                        @error('name')
                            <span class="text-danger" role="alert">{{ $message }}</span>
                        @enderror
                    </div>

                    <div class="form-group">
                        <label for="description">الإيميل</label>
                        <input class="form-control" name='email'>
                        @error('email')
                            <span class="text-danger" role="alert">{{ $message }}</span>
                        @enderror
                    </div>
                    <div class="form-group">
                        <label for="description">رقم التليفون</label>
                        <input class="form-control" name='phone'>
                        @error('phone')
                            <span class="text-danger" role="alert">{{ $message }}</span>
                        @enderror
                    </div>
                    <div class="form-group">
                        <label for="description">كلمة السر</label>
                        <input type="password" class="form-control" name='password'>
                        @error('password')
                            <span class="text-danger" role="alert">{{ $message }}</span>
                        @enderror
                    </div>
                    <div class="form-group">
                        <label for="description">تأكيد كلمة السر</label>
                        <input type="password" class="form-control" name='password_confirmation'>
                    </div>
                    <div class="form-group">
                        <label for="role">الدور</label>
                        <select id="role" name='role' class="form-control">
                            <option selected>اختار الدور</option>
                            @foreach($roles as $role)
                                <option value="{{ $role->id }}">{{ $role->name }}</option>
                            @endforeach
                        </select>
                    </div>
                    <input type="submit" class="btn btn-success" value="حفظ">
                    <a href="{{ route('admins.get_archive') }}" class="btn btn-info">الأرشيف</a>
                </form>
            </div>
            <div class="col-lg-6">
                <table class="table table-responsive table-striped">
                    <thead>
                        <tr class="bg-navy disabled ">
                            <th class="text-center">تحكم</th>
                            <th class="text-center">الرقم</th>
                            <th class="text-center">الاسم</th>
                            <th class="text-center">الإيميل</th>
                            <th class="text-center">رقم التليفون</th>
                            <th class="text-center">الدور</th>
                            <th class="text-center">الحالة</th>
                        </tr>
                    </thead>'
                    <tbody>
                        <?php 
                                    
                                $i = 1;
                                
                                foreach($admins as $ad)
                            {
                                ?>
                        <tr>
                            <td class="text-center control">
                                <a href="{{ route('admins.edit', $ad->id) }}"
                                    class="btn btn-info btn-icon control-buttons" title="Edit "><i
                                        class="fa fa-pencil-square-o fa-pencil"></i></a>
                                <form action="{{ route('admins.destroy', $ad->id) }}" method="post">
                                    @csrf
                                    @method('DELETE')
                                    <button type="submit" class="btn btn-danger btn-icon control-buttons"><i
                                            class="fa fa-trash-o"></i></button>
                                    {{-- <span id="delete" data-id="{{$ad->id}}" data-model="admins" class="btn btn-danger btn-icon control-buttons delete" title="Delete"><i class="fa fa-trash-o"></i></span> --}}
                                </form>
                            </td>
                            <td class="text-center">{{ $ad->id }}</td>
                            <td class="text-center">{{ $ad->name }}</td>
                            <td class="text-center">{{ $ad->email }}</td>
                            <td class="text-center">{{ $ad->phone }}</td>
                            <td class="text-center">{{ $ad->getRoleNames()->first() }}</td>
                            <td class="text-center">
                                <label class="switch switch-text switch-info">
                                    <form action="{{ route('admins.status', $ad->id) }}" method="get"
                                        id="status{{ $ad->id }}"></form>
                                    <input onchange="$('#status{{ $ad->id }}').submit()" type="checkbox"
                                        class="switch-input status" data-type="admin" data-id="{{ $ad->id }}"
                                        @if ($ad->status == 1) checked @endif>
                                    <span class="switch-label" data-on="مفعل" data-off="معطل"></span>
                                    <span class="switch-handle"></span>
                            </td>
                        </tr>
                        <?php
                                }
                                ?>
                    </tbody>
                </table>
            </div>
        </div>
        <!--/row-->
    </div>

</div>
@include('layouts.footer')

</html>
