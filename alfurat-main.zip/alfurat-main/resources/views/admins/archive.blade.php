@include('layouts.header')
@include('layouts.nav', [
    'breadcrumbs' => [
        ['title' => 'المسئولون',
        'route' => route("admins.index"),
        'icon' => 'icon-people',],
        
        ['title' => 'الأرشيف',
        'route' => '',
        'icon' => '',]
    ],
])
<div class="container-fluid">

    <div class="animated fadeIn container-fluid">
        <div class="row">
            
            <div class="col-lg-12">
                <table class="table table-responsive table-striped">
                    <thead>
                        <tr class="bg-navy disabled ">
                            <th class="text-center">تحكم</th>
                            <th class="text-center">الرقم</th>
                            <th class="text-center">الاسم</th>
                            <th class="text-center">الإيميل</th>
                            <th class="text-center">رقم التليفون</th>
                        </tr>
                    </thead>'
                    <tbody>
                        <?php 
                                    
                                $i = 1;
                                
                                foreach($admins as $ad)
                            {
                                ?>
                        <tr>
                            <td class="text-center control">
                                <a href="{{ route('admins.restore_archive', $ad->id) }}"
                                    class="btn btn-info btn-icon control-buttons" title="restore "><i
                                        class="fa fa-undo"></i></a>
                            </td>
                            <td class="text-center">{{ $ad->id }}</td>
                            <td class="text-center">{{ $ad->name }}</td>
                            <td class="text-center">{{ $ad->email }}</td>
                            <td class="text-center">{{ $ad->phone }}</td>
                        </tr>
                        <?php
                                }
                                ?>
                    </tbody>
                </table>
            </div>
        </div>
        <!--/row-->
    </div>

</div>
@include('layouts.footer')

</html>
