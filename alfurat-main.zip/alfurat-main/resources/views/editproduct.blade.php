@include('layouts.header')
@include('layouts.nav', [
    'breadcrumbs' => [
        ['title' => 'المنتجات',
        'route' => route('web.products.index'),
        'icon' => 'icon-grid',],
        ['title' => 'تعديل',
        'route' => '',
        'icon' => '',],
    ],
])
<div class="container-fluid">

        <div class="animated fadeIn">
            <div class="row">
                <div class='col-lg-4'>
                    <form method="POST" enctype="multipart/form-data" action="{{ route('web.products.update', $product->id) }}">
                        @csrf
                        @method('PUT')
                        <div class="form-group">
                            <label for="product_name">اسم المنتج</label>
                            <input class="form-control" value="{{ $product->product_name }}" name='product_name'>
                        </div>
                        <div class="form-group">
                            <label for="description">الوصف</label>
                            <input class="form-control" value="{{ $product->description }}" name='description'>
                        </div>
                        <div class="form-group">
                            <label for="product_name">الصورة</label>
                            <input class="form-control" type="file" name='image'>
                        </div>
                        <div class="form-group">
                            <label for="image">الصورة</label>
                            <img src="{{asset('storage/' . $product->image)}}" style="width:200px"/>
                        </div>
                        <div class="form-group">
                            <label for="whole_sale_price">سعر الجملة</label>
                            <input class="form-control" value="{{ isset($product->whole_sale_price) ? $product->whole_sale_price:0 }}" type="number" step="0.00001" name='whole_sale_price'>
                        </div>
                        <div class="form-group">
                            <label for="retail_price">سعر المفرد</label>
                            <input class="form-control" value="{{ isset($product->retail_price) ? $product->retail_price:0 }}"  type="number" step="0.00001" name='retail_price'>
                        </div>
                        <div class="form-group">
                            <label for="vip_price">السعر كبار التجار</label>
                            <input class="form-control" value="{{ isset($product->vip_price) ? $product->vip_price:0 }}"  type="number" step="0.00001" name='vip_price'>
                        </div>
                        <div class="form-group">
                            <label for="category_id">المجموعة</label>
                            <select class="select form-control" name="category_id">
                                @foreach ($categories as $category)
                                    <option
                                    @if($category->id==$product->category_id)
                                    selected
                                    @endif
                                    value="{{ $category->id }}">{{ $category->category_name }}</option>
                                @endforeach
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="company_id">الشركة</label>
                            <select class="select form-control" name="company_id">
                                @foreach ($companies as $company)
                                    <option         
                                    @if($company->id==$product->company_id)
                                    selected
                                    @endif
                                    value="{{ $company->id }}">{{ $company->company_name }}</option>
                                @endforeach
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="unit_group_id">مجموعة الوحدات</label>
                            <select class="select form-control" name="unit_group_id">
                                @foreach ($unitgroups as $unitgroup)
                                    <option 
                                    @if($unitgroup->id==$product->unit_group_id)
                                    selected
                                    @endif
                                    value="{{ $unitgroup->id }}">{{ $unitgroup->unit_group_name }}</option>
                                @endforeach
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="whole_unit_id">وحدة الجملة</label>
                            <select class="select form-control" name="whole_unit_id">
                                @foreach ($units as $unit)
                                
                                    <option
                                    @if($unit->id==$product->whole_unit_id)
                                    selected
                                    @endif
                                     value="{{ $unit->id }}">{{ $unit->unit_name }}</option>
                                @endforeach
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="retail_unit_id">وحدة المفرد</label>
                            <select class="select form-control" name="retail_unit_id">
                                @foreach ($units as $unit)
                                    <option 
                                    @if($unit->id==$product->retail_unit_id)
                                    selected
                                    @endif
                                    value="{{ $unit->id }}">{{ $unit->unit_name }}</option>
                                @endforeach
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="vip_unit_id">وحدة كبار التجار</label>
                            <select class="select form-control" name="vip_unit_id">
                                @foreach ($units as $unit)
                                    <option
                                    @if($unit->id==$product->vip_unit_id)
                                    selected
                                    @endif
                                    value="{{ $unit->id }}">{{ $unit->unit_name }}</option>
                                @endforeach
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="discount">التخفيض</label>
                            <input class="form-control" required value="{{ isset($product->discount)?$product->discount:0 }}" type="number" step="0.0001" name='discount'>
                        </div>
                        <div class="form-group">
                            <label for="min_whole_quantity">اقل كمية جملة</label>
                            <input class="form-control" required  value="{{ isset($product->min_whole_quantity)?$product->min_whole_quantity:0 }}"type="number" step="0.0001" name='min_whole_quantity'>
                        </div>
                        <div class="form-group">
                            <label for="min_retail_quantity">اقل كمية مفرد</label>
                            <input class="form-control" required value="{{ isset($product->min_retail_quantity)?$product->min_retail_quantity:0 }}" type="number" step="0.0001" name='min_retail_quantity'>
                        </div>
                        <div class="form-group">
                            <label for="min_vip_quantity">اقل كمية كبار تجار</label>
                            <input class="form-control" required value="{{ isset($product->min_vip_quantity)?$product->min_vip_quantity:0 }}" type="number" step="0.0001" name='min_vip_quantity'>
                        </div>
                        <div class="form-group">
                            <label for="max_whole_quantity">اكبر كمية جملة</label>
                            <input class="form-control" required value="{{ isset($product->max_whole_quantity)?$product->max_whole_quantity:0 }}" type="number" step="0.0001" name='max_whole_quantity'>
                        </div>
                        <div class="form-group">
                            <label for="max_retail_quantity">اكبر كمية مفرد</label>
                            <input class="form-control" required value="{{ isset($product->max_retail_quantity)?$product->max_retail_quantity:0 }}" type="number" step="0.0001" name='max_retail_quantity'>
                        </div>

                        <input type="submit" class="btn btn-success" value="حفظ">
                    </form>
                </div>
            </div>
            <!--/row-->
        </div>
    </div>
    @include('layouts.footer')
    </html>