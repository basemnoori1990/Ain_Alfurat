<!--
 * CoreUI - Open Source Bootstrap Admin Template
 * @version v1.0.0-alpha.2
 * @link http://coreui.io
 * Copyright (c) 2016 creativeLabs Łukasz Holeczek
 * @license MIT
 -->
 <!DOCTYPE html>
 <html lang="IR-fa" dir="rtl">
 
 <head>
     <meta charset="utf-8">
     <meta http-equiv="X-UA-Compatible" content="IE=edge">
     <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
     <meta name="description" content="Dinar">
     <meta name="author" content="Mustafa Muawia">
     <meta name="keyword" content="دينار">
     <!-- <link rel="shortcut icon" href="assets/ico/favicon.png"> -->
     <title>دينار</title>
     <!-- Icons -->
     <link href="{{ asset('css/font-awesome.min.css') }}" rel="stylesheet">
     <link href="{{ asset('css/simple-line-icons.css') }}" rel="stylesheet">
     <!-- Main styles for this application -->
     <link href="{{ asset('dest/style.css') }}" rel="stylesheet">
     <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
     {{-- <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css" integrity="sha384-xOolHFLEh07PJGoPkLv1IbcEPTNtaed2xpHsD9ESMhqIYd0nLMwNLD69Npy4HI+N" crossorigin="anonymous"> --}}
     <link rel="stylesheet" href="https://cdn.datatables.net/2.0.8/css/dataTables.dataTables.css" />
     <link rel="stylesheet" href="https://code.jquery.com/ui/1.14.0/themes/base/jquery-ui.css">
     <script>
         const app_url = "{{ env('APP_URL') }}"
     </script>
 </head>
 <!-- BODY options, add following classes to body to change options
   1. 'compact-nav'     	  - Switch sidebar to minified version (width 50px)
   2. 'sidebar-nav'		  - Navigation on the left
    2.1. 'sidebar-off-canvas'	- Off-Canvas
     2.1.1 'sidebar-off-canvas-push'	- Off-Canvas which move content
     2.1.2 'sidebar-off-canvas-with-shadow'	- Add shadow to body elements
   3. 'fixed-nav'			  - Fixed navigation
   4. 'navbar-fixed'		  - Fixed navbar
  -->
 
 <body class="navbar-fixed sidebar-nav fixed-nav">
     <header class="navbar">
         <div class="container-fluid">
             <button class="navbar-toggler mobile-toggler hidden-lg-up" type="button">&#9776;</button>
             <a class="navbar-brand" href="#"></a>
             <ul class="nav navbar-nav hidden-md-down">
                 <li class="nav-item">
                     <a class="nav-link navbar-toggler layout-toggler" href="#">&#9776;</a>
                 </li>
 
                 <!--<li class="nav-item p-x-1">
                     <a class="nav-link" href="#">داشبورد</a>
                 </li>
                 <li class="nav-item p-x-1">
                     <a class="nav-link" href="#">Users</a>
                 </li>
                 <li class="nav-item p-x-1">
                     <a class="nav-link" href="#">Settings</a>
                 </li>-->
             </ul>
                <ul class="nav navbar-nav pull-left hidden-md-down mx">
                    {{-- <li class="nav-item">
                        <a class="nav-link aside-toggle" href="#"><i class="icon-bell"></i><span
                                class="tag tag-pill tag-danger">5</span></a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#"><i class="icon-list"></i></a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#"><i class="icon-location-pin"></i></a>
                    </li> --}}
                    <li class="mx-5"></li>
                    <li class="nav-item dropdown">
                           <a class="nav-link dropdown-toggle nav-link" data-toggle="dropdown" href="#" role="button"
                            aria-haspopup="true" aria-expanded="false">
                            <img src="{{ asset('img/avatars/6.jpg?v='.time().'') }}" class="img-avatar" alt="admin@bootstrapmaster.com">
                            <span class="hidden-md-down"></span>
                        </a>
                        <div class="dropdown-menu dropdown-menu-right">
                            <a class="dropdown-item" href="{{ route('profile') }}"><i class="fa fa-user"></i> الملف
                                الشخصي</a>
                            <!--<a class="dropdown-item" href="#"><i class="fa fa-usd"></i> Payments<span class="tag tag-default">42</span></a>-->
                            <div class="divider"></div>
                            <a class="dropdown-item" href="{{ route('logout') }}"><i class="fa fa-lock"></i> خروج</a>
                        </div>
                    </li>
                    {{-- <li class="nav-item">
                        <a class="nav-link navbar-toggler aside-toggle" href="#">&#9776;</a>
                    </li> --}}
    
                </ul>
         </div>
     </header>