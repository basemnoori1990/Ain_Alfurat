<div class="sidebar">
    <nav class="sidebar-nav">
        <ul class="nav">
            @can('لوحة التحكم')
                <li class="nav-item">
                <a class="nav-link" href="{{ url('/') }}"><i class="icon-speedometer"></i> لوحةالتحكم
                    {{-- <span class="tag tag-info">جدید</span> --}}
                </a>
            </li>
            @endcan
            
            @can('الصلاحيات')
            <li class="nav-title">
                <a class="nav-link" href="{{ route('roles.index') }}"><i class="icon-people"></i>الصلاحيات</a>
            </li>
            @endcan
            
            @can('المسئولون')
            <li class="nav-title">
                <a class="nav-link" href="{{ route('admins.index') }}"><i class="icon-people"></i>المسئولون</a>
            </li>
            @endcan
            
            @can('الشركات')
            <li class="nav-title">
                <a class="nav-link" href="{{ route('web.companies.index') }}"><i class="icon-folder-alt"></i>الشركات</a>
            </li>
            @endcan
            
            @can('المستخدمون')
            <li class="nav-title">
                <a class="nav-link" href="{{ route('users.index') }}"><i class="icon-people"></i>العملاء</a>
            </li>
            @endcan
            
            @can('خواص المنتجات')
            <li class="nav-title">
                <a class="nav-link" href="{{ route('categoryspecifications.index') }}"><i class="icon-cursor"></i>خواص
                    المنتجات</a>
            </li>
            @endcan
            
            @can('المجموعات')
            <li class="nav-title">
                <a class="nav-link" href="{{ route('web.categories.index') }}"><i
                        class="icon-organization"></i>المجموعات</a>
            </li>
            @endcan
            
            @can('المنتجات')
            <li class="nav-title">
                <a class="nav-link" href="{{ route('web.products.index') }}"><i class="icon-grid"></i>المنتجات</a>
            </li>
            @endcan
            
            @can('المناديب')
            <li class="nav-title">
                <a class="nav-link" href="{{ route('agents') }}"><i class="icon-map"></i>المناديب</a>
            </li>
            @endcan
            
            @can('الطلبات')
            <li class="nav-title">
                <a class="nav-link" href="{{ route('web.orders.index') }}"><i class="icon-chart"></i>الطلبات</a>
            </li>
            @endcan
            
            @can('الوحدات')
            <li class="nav-title">
                <a class="nav-link" href="{{ route('units.index') }}"><i class="icon-compass"></i>الوحدات</a>
            </li>
            @endcan
            
            @can('مجموعات الوحدات')
            <li class="nav-title">
                <a class="nav-link" href="{{ route('unitgroups.index') }}"><i class="icon-drawer"></i>مجموعات
                    الوحدات</a>
            </li>
            @endcan
            
            @can('الإعلانات')
            <li class="nav-title">
                <a class="nav-link" href="{{ route('web.ads.index') }}"><i
                        class="icon-screen-desktop"></i>الاعلانات</a>
            </li>
            @endcan
            
            @can('الضبط')
            <li class="nav-title">
                <a class="nav-link" href="{{ route('settings.index') }}"><i class="icon-settings"></i>الضبط</a>
            </li>
            @endcan

            {{-- <li class="nav-item">
            <a class="nav-link" href="#"><i class="icon-user-follow"></i> ثبت کاربر</a>
            <a class="nav-link" href="#"><i class="icon-people"></i> لیست کاربران</a>
            <a class="nav-link" href="#"><i class="icon-user-following"></i> دسترسی کاربران</a>
        </li> --}}


        </ul>
    </nav>
</div>

<main class="main">

    <!-- Breadcrumb -->
    <ol class="breadcrumb">
        <li class="breadcrumb-item text-light"><a class="text-muted" href="{{ route('dashboard') }}"><i
                    class="icon-home"></i>الرئيسية</a></li>
        @foreach ($breadcrumbs as $breadcrumb)
            {{-- {{ dd($breadcrumbs) }} --}}
            <li class="breadcrumb-item text-light">
                <a class="text-muted" href="{{ $breadcrumb['route'] }}">
                    <i class="{{ $breadcrumb['icon'] }}"></i>{{ $breadcrumb['title'] }}
                </a>
            </li>
        @endforeach
    </ol>
