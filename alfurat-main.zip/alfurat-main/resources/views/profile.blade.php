@include('layouts.header')
@include('layouts.nav', [
    'breadcrumbs' => [
        ['title' => 'الصفحة الشخصية',
        'route' => route("profile"),
        'icon' => 'icon-user',],
    ],
])
<div class="container-fluid">
    <div class="animated fadeIn">
        <div class="row">
            <div class='col-lg-12'>
                <h3 class="mb-5">تعديل البيانات</h3>
                <form method="POST" action="{{ route('admins.update', auth()->user()->id) }}">
                    @csrf
                    @method('put')
                    @if (session()->has('success'))
                        <div class="alert alert-success">{{ session('success') }}</div>
                    @endif
                    <div class="form-group">
                        <label for="specification_name">الاسم</label>
                        <input class="form-control" name='name' value="{{ auth()->user()->name }}" type="text">
                        @error('name')
                            <span class="text-danger" role="alert">{{ $message }}</span>
                        @enderror
                    </div>

                    <div class="form-group">
                        <label for="description">الإيميل</label>
                        <input class="form-control" name='email' value="{{ auth()->user()->email }}">
                        @error('email')
                            <span class="text-danger" role="alert">{{ $message }}</span>
                        @enderror
                    </div>
                    <div class="form-group">
                        <label for="description">رقم التليفون</label>
                        <input class="form-control" name='phone' value="{{ auth()->user()->phone }}">
                        @error('phone')
                            <span class="text-danger" role="alert">{{ $message }}</span>
                        @enderror
                    </div>
                    <div class="form-group">
                        <label for="description">كلمة السر</label><span class="text-danger " style="font-size:12px;">  *أدخل كلمة المرور و التأكيد إذا أردت تغييرها</span>
                        <input type="password" class="form-control" name='password'>
                        @error('password')
                            <span class="text-danger" role="alert">{{ $message }}</span>
                        @enderror
                    </div>
                    <div class="form-group">
                        <label for="description">تأكيد كلمة السر</label>
                        <input type="password" class="form-control" name='password_confirmation'>
                    </div>

                    <input type="submit" class="btn btn-success" value="حفظ">
                </form>
            </div>
        </div>
        <!--/row-->
    </div>
</div>
@include('layouts.footer')

</html>
