@include('layouts.header')
@include('layouts.nav', [
    'breadcrumbs' => [
        ['title' => 'الإعدادات',
        'route' => route("settings.index"),
        'icon' => 'icon-settings',],
    ],
])
<div class="container-fluid">
            <div class="animated fadeIn">
                <div class="row">
                    <div class='col-lg-6'>
                        <form method="POST" enctype="multipart/form-data" action="">
                            @csrf
                            <div class="form-group">
                                <label for="title">الموقع الجغرافي</label>
                            <input class="form-control"  name='location' readonly value="{{isset($settings->find(1)->value)&& !empty($settings->find(1)->value) ? $settings->find(1)->value.','.$settings->find(2)->value : '42.92394960,33.55460410'}}" >
                            <button id="opener" type="button" class="btn btn-primary">تحديد الموقع <i class="fa fa-map-marker"></i></button>
                            </div>
                            <div class="form-group">
                                <label for="price_per_kilometer">سعر التوصيل للكيلوميتر</label>
                            <input class="form-control" value="{{isset($settings->find(3)->value)&& !empty($settings->find(3)->value) ? $settings->find(3)->value : '5'}}"  name='price_per_kilometer' type="number" step="any">
                            </div>
                            <div class="form-group">
                                <label for="min_order">الحد الادنى للطلب بالدينار</label>
                            <input class="form-control" value="{{isset($settings->find(4)->value)&& !empty($settings->find(4)->value) ? $settings->find(4)->value : '300000'}}"  name='min_order' type="number" step="any">
                            </div>
                             <input type="submit" class="btn btn-success" value="حفظ">
                        </form>
                    </div>
                </div>
                <!--/row-->
            </div>
        </div>
        <div id="dialog"></div>

    @include('layouts.footer')
    <link rel="stylesheet" href="https://code.jquery.com/ui/1.14.0/themes/base/jquery-ui.css">

    <script src="https://code.jquery.com/ui/1.14.0/jquery-ui.js"></script>

    <script>
$(function () {
    

  $( "#dialog" ).dialog({
    autoOpen: false,
    modal: true,
                   height: 500,
                   width: 500,
                   title: "الموقع الجغرافي",
    buttons:{
            "ok":function(){                                        
                var lng = localStorage.getItem('lng');
                var lat = localStorage.getItem('lat');
                localStorage.clear();
                        $(this).dialog("close"); 
                        
                        processResult(lng,lat);
                    },
            "cancel":function(){                          
                        $(this).dialog("close");     return false;                  
                }
            }   
  }).html('<iframe style="border: 0px; " src="{{url('/map')}}" width="100%" height="100%"></iframe>')
               ;
  
  $("#opener").click(function(e) {
    e.preventDefault();
    $("#dialog").dialog('open');
  });
});

//$mydialog.dialog("open");


function processResult(lng,lat) {
//   $('#txtLng').val(lng)
//   $('#txtLat').val(lat)
$('input[name="location"]').val(lng+','+lat);
}
</script>   
    </html>