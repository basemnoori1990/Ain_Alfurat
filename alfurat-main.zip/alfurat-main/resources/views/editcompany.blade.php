@include('layouts.header')
@include('layouts.nav', [
    'breadcrumbs' => [
        ['title' => 'الشركات',
        'route' => route("web.companies.index"),
        'icon' => 'icon-folder-alt',],
        
        ['title' => 'تعديل',
        'route' => '',
        'icon' => '',]
    ],
])
<div class="container-fluid">
            <div class="animated fadeIn">
                <div class="row">
                    <div class='col-lg-6'>
                        <form method="POST" enctype="multipart/form-data" action="{{route('web.companies.update',$company->id)}}">
                            @csrf   
                            @method('PUT')
                            <div class="form-group">
                                <label for="company_name">اسم الشركة</label>
                            <input class="form-control" value="{{$company->company_name}}" name='company_name' >
                            </div>
                            <div class="form-group">
                                <label for="description">الوصف</label>
                            <input class="form-control" value="{{$company->description}}" name='description' >
                            </div>
                            <div class="form-group">
                                <label for="image">الشعار</label>
                            <input type="file" class="form-control" name='logo' >
                            </div>
                            <div class="form-group">
                                <label for="image">الصورة</label>
                           <img src="{{asset('storage/' . $company->image)}}" style="width:200px"/>
                            </div>
                            <input type="submit" class="btn btn-success" value="حفظ">
                        </form>
                    </div>
                </div>
                <!--/row-->
            </div>
        </div>
        
    @include('layouts.footer')
    </html>