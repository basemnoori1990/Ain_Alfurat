@include('layouts.header')
@include('layouts.nav', [
    'breadcrumbs' => [
        ['title' => 'المنتجات',
        'route' => route('web.products.index'),
        'icon' => 'icon-grid',],
    ],
])
<div class="container-fluid">

    <div class="animated fadeIn">
        <div class="row">
            <div class='col-lg-4'>
                <form method="POST" enctype="multipart/form-data" action="{{ route('web.products.store') }}">
                    @csrf
                    <div class="form-group">
                        <label for="product_name">اسم المنتج</label>
                        <input class="form-control" name='product_name'>
                    </div>
                    <div class="form-group">
                        <label for="description">الوصف</label>
                        <input class="form-control" name='description'>
                    </div>
                    <div class="form-group">
                        <label for="product_name">الصورة</label>
                        <input class="form-control" type="file" name='image'>
                    </div>
                    <div class="form-group">
                        <label for="whole_sale_price">سعر الجملة</label>
                        <input class="form-control" type="number" step="0.00001" name='whole_sale_price'>
                    </div>
                    <div class="form-group">
                        <label for="retail_price">سعر المفرد</label>
                        <input class="form-control" type="number" step="0.00001" name='retail_price'>
                    </div>
                    <div class="form-group">
                        <label for="vip_price">السعر كبار التجار</label>
                        <input class="form-control" type="number" step="0.00001" name='vip_price'>
                    </div>
                    <div class="form-group">
                        <label for="رس">المجموعة</label>
                        <select class="select form-control" name="category_id">
                            @foreach ($categories as $category)
                            <option value="{{ $category->id }}">{{ $category->category_name }}</option>
                            @endforeach
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="company_id">الشركة</label>
                        <select class="select form-control" name="company_id">
                            @foreach ($companies as $company)
                            <option value="{{ $company->id }}">{{ $company->company_name }}</option>
                            @endforeach
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="unit_group_id">مجموعة الوحدات</label>
                        <select class="select form-control" id="unit_group_id" name="unit_group_id">
                            @foreach ($unitgroups as $unitgroup)
                            <option value="{{ $unitgroup->id }}">{{ $unitgroup->unit_group_name }}</option>
                            @endforeach
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="whole_unit_id">وحدة الجملة</label>
                        <select class="select form-control" id="whole_unit_id" name="whole_unit_id">
                            @foreach ($units as $unit)
                            <option value="{{ $unit->id }}">{{ $unit->unit_name }}</option>
                            @endforeach
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="retail_unit_id">وحدة المفرد</label>
                        <select class="select form-control" id="retail_unit_id" name="retail_unit_id">
                            @foreach ($units as $unit)
                            <option value="{{ $unit->id }}">{{ $unit->unit_name }}</option>
                            @endforeach
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="vip_unit_id">وحدة كبار التجار</label>
                        <select class="select form-control" id="vip_unit_id" name="vip_unit_id">
                            @foreach ($units as $unit)
                            <option value="{{ $unit->id }}">{{ $unit->unit_name }}</option>
                            @endforeach
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="discount">التخفيض</label>
                        <input class="form-control" type="number" value="0" step="0.0001" name='discount'>
                    </div>
                    <div class="form-group">
                        <label for="min_whole_quantity">اقل كمية جملة</label>
                        <input class="form-control" type="number" value="5" step="0.0001" name='min_whole_quantity'>

                        <div class="form-group">
                            <label for="min_retail_quantity">اقل كمية مفرد</label>
                            <input class="form-control" value="0" type="number" step="0.0001"
                                name='min_retail_quantity'>
                        </div>
                        <div class="form-group">
                            <label for="min_vip_quantity">اقل كمية كبار تجار</label>
                            <input class="form-control" value="0" type="number" step="0.0001" name='min_vip_quantity'>
                        </div>
                        <div class="form-group">
                            <label for="max_whole_quantity">اكبر كمية جملة</label>
                            <input class="form-control" value="0" type="number" step="0.0001" name='max_whole_quantity'>
                        </div>
                        <div class="form-group">
                            <label for="max_retail_quantity">اكبر كمية مفرد</label>
                            <input class="form-control" value="10" type="number" step="0.0001"
                                name='max_retail_quantity'>
                        </div>
                        <input type="submit" class="btn btn-success" value="حفظ">
                        <a href="{{ route('products.get_archive') }}" class="btn btn-info">الأرشيف</a>
                </form>
            </div>
        </div>
        <div class="col-lg-8">
            <table class="table table-responsive table-striped">
                <thead>
                    <tr class="bg-navy disabled ">
                        <th class="text-center">تحكم</th>
                        <th class="text-center">الرقم</th>
                        <td class="text-center">الاسم</td>
                        <td class="text-center">الوصف</td>
                        <td class="text-center">الصورة</td>
                        <td class="text-center">مجموعة الوحدات</td>
                        <td class="text-center">سعر الجملة</td>
                        <td class="text-center">وحدة الجملة</td>
                        <td class="text-center">سعر المفرد</td>
                        <td class="text-center">وحدة المفرد</td>
                        <td class="text-center">سعر كبار التجار</td>
                        <td class="text-center">وحدة كبار التجار</td>
                        <td class="text-center">المجموعة</td>
                        <td class="text-center">الشركة</td>
                        <td class="text-center">الخصم</td>
                        <th class="text-center">الحالة</th>
                    </tr>
                </thead>
                <tbody>
                    <?php 
                                
                            $i = 1;
                            
                            foreach($products as $product)
                        {
                            ?>
                    <tr>
                        <td class="text-center">
                            <div class="control"><a class="badge badge-warning control-buttons"
                                    href="{{url('products/required_products/'.$product->id)}}" style="color:black">الفرض</a>
                                <a href="{{route('products.edit',$product->id)}}"
                                    class="btn btn-info btn-icon control-buttons" title="Edit "><i
                                        class="fa fa-pencil-square-o fa-pencil"></i></a>
                                <span id="delete" data-id="{{$product->id}}" data-model="products"
                                    class="btn btn-danger btn-icon control-buttons delete" title="Delete"><i
                                        class="fa fa-trash-o"></i></span>
                            </div>
                        </td>
                        <td class="text-center">{{$product->id}}</td>
                        <td class="text-center">{{$product->product_name}}</td>
                        <td class="text-center">{{$product->description}}</td>
                        <td class="text-center">
                            <img src="{{ asset('storage/' . $product->image)}}" style="width:50px">
                        </td>
                        <td class="text-center">{{isset($product->unit_group) ? $product->unit_group->unit_group_name
                            :''}}</td>
                        <td class="text-center">{{number_format($product->whole_sale_price)}}</td>
                        <td class="text-center">{{isset($product->whole_unit) ? $product->whole_unit->unit_name:''}}
                        </td>
                        <td class="text-center">{{number_format($product->retail_price)}}</td>
                        <td class="text-center">{{isset($product->retail_unit) ? $product->retail_unit->unit_name:''}}
                        </td>
                        <td class="text-center">{{number_format($product->vip_price)}}</td>
                        <td class="text-center">{{isset($product->vip_unit) ? $product->vip_unit->unit_name:''}}</td>
                        <td class="text-center">{{isset($product->category) ? $product->category->category_name:''}}
                        </td>
                        <td class="text-center">{{isset($product->company) ? $product->company->company_name:''}}</td>
                        <td class="text-center">{{$product->discount}}</td>
                        <td class="text-center">
                            <label class="switch switch-text switch-info">
                                <input type="checkbox" class="switch-input status" data-type="product" data-id="{{$product->id}}"
                                @if ($product->status==1)
                                checked
                                @endif
                                >
                                <span class="switch-label" data-on="مفعل" data-off="معطل"></span>
                                <span class="switch-handle"></span>
                        </td>
                        <?php
                            }
                            ?>
                </tbody>
            </table>
        </div>
    </div>
    <!--/row-->
</div>
</div>
@include('layouts.footer')
<script>
    $(function()
    {
    
    $('#group_id').select2();
    
    $('#unit_group_id').select2();
    $('#whole_unit_id').select2();
    $('#vip_unit_id').select2();
    $('#retail_unit_id').select2();
    
    $('#unit_group_id').change(function() {
    
    var unit_group_id = $(this).val();
    
    // Clear existing options in the second select
    
    $('#whole_unit_id').empty().trigger('change');
    $('#vip_unit_id').empty().trigger('change');
    $('#retail_unit_id').empty().trigger('change');
    
    if (unit_group_id) {
    // Make an AJAX request to fetch the options
    $.ajax({
    url: "{{ route('units.get_units_by_unit_group') }}", // URL to the server-side script that returns the options
    type: 'post',
    data: { _token: "{{ csrf_token() }}",unit_group_id:unit_group_id },
    success: function(response) {
    // Populate the second select with the response data
    var newOptions = $.map(response, function(option) {
    return {
    id: option.id,
    text: option.unit_name
    };
    });
    
    console.log(newOptions)
    $('#whole_unit_id').empty().select2({
    data: newOptions
    })
    $('#vip_unit_id').empty().select2({
    data: newOptions
    })
    $('#retail_unit_id').empty().select2({
    data: newOptions
    })
    
    },
    error: function(xhr, status, error) {
    console.error('AJAX Error: ' + status + error);
    }
    });
    }
    });
        })



  $(document).ready(function () {

});
     
</script>

</html>