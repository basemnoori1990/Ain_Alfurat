@include('layouts.header')
@include('layouts.nav', [
    'breadcrumbs' => [
        ['title' => 'المجموعات',
        'route' => route("web.categories.index"),
        'icon' => 'icon-organization',],
        ['title' => 'الأرشيف',
        'route' => '',
        'icon' => '',],
    ],
])
        <div class="container-fluid">

            <div class="animated fadeIn">
                <div class="row">
                    <div class="col-lg-12">
                        <table class="table table-responsive table-striped">
                            <thead>
                                <tr class="bg-navy disabled ">
                                    <th class="text-center">تحكم</th>
                                    <th class="text-center">الرقم</th>
                                    <th class="text-center">الاسم</th>
                                    <th class="text-center">الوصف</th>
                                    <th class="text-center">الصورة</th>
                                    <th class="text-center">تندرج تحت</th>
                                    <th class="text-center">الخاصية</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php 
                                    
                                $i = 1;
                                
                                foreach($categories as $category)
                            {
                                ?>
                                <tr>
                                    <td class="text-center"><a href="{{ route('categories.restore_archive', $category->id) }}"
                                        class="btn btn-info btn-icon control-buttons" title="restore "><i
                                            class="fa fa-undo"></i></a>
                                    
                                </td>  
                                    <td class="text-center">{{$category->id}}</td>
                                    <td class="text-center">{{$category->category_name}}</td>
                                    <td class="text-center">{{$category->description}}</td>
                                    <td class="text-center">
                                        <img src="
                                        {{ asset('storage/' . $category->image)}}
                                        "
                                        style="width:50px">
                                    </td>
                                    <td class="text-center">
                                        @if($category->parent!=null)
                                        {{'('.$category->parent_id.') - '.$category->parent->category_name}}
                                        @endif
                                    </td>
                                    <td class="text-center">
                                        @if($category->category_specification!=null)
                                        {{$category->category_specification->specification_name}}
                                        @endif
                                    </td>
                                    
                                    
                                </tr>  
                                <?php
                                }
                                ?>
                            </tbody>
                        </table>
                    </div>
                </div>
                <!--/row-->
            </div>
        </div>
        @include('layouts.footer')
        <script>
            $(function(){
            $('#main_category_id').select2();
        $('#sub_category_id').select2();

        $('#main_category_id').change(function() {
    var main_category_id = $(this).val();
    var sub_category_id = $('#sub_category_id');

    // Clear existing options in the second select
    sub_category_id.empty().trigger('change');

    if (main_category_id) {
        // Make an AJAX request to fetch the options
        $.ajax({
            url: "{{ route('categories.get_sub_categories') }}", // URL to the server-side script that returns the options
            type: 'post',
            data: { _token: "{{ csrf_token() }}",id:$("#main_category_id").val() },
            success: function(response) {
                // Populate the second select with the response data
                var newOptions = $.map(response, function(option) {
                    // console.log(option[0]);
                    return {
                        id: option[0].id,
                        text: option[0].category_name
                    };
                });

                sub_category_id.empty().select2({
data: newOptions
})
            },
            error: function(xhr, status, error) {
                console.error('AJAX Error: ' + status + error);
            }
        });
    }
});
            })
        </script>
        </html>