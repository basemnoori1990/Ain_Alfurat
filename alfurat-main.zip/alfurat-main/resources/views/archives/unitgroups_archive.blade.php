@include('layouts.header')
@include('layouts.nav', [
    'breadcrumbs' => [
        ['title' => 'مجموعات الوحدات',
        'route' => route("unitgroups.index"),
        'icon' => 'icon-drawer',],
        ['title' => 'الأرشيف',
        'route' => '',
        'icon' => '',],
    ],
])
<div class="container-fluid">

            <div class="animated fadeIn">
                <div class="row">
                    
                    <div class="col-lg-12">
                        <table class="table table-responsive table-striped">
                            <thead>
                                <tr class="bg-navy disabled ">
                                    <th class="text-center">تحكم</th>
                                    <th class="text-center">الرقم</th>
                                    <th class="text-center">الاسم</th>
                                    <th class="text-center">الوصف</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php 
                                    
                                $i = 1;
                                
                                foreach($unitgroups as $unitgroup)
                            {
                                ?>
                                <tr>
                                    <td class="text-center">
                                        <a href="{{ route('unitgroups.restore_archive', $unitgroup->id) }}"
                                            class="btn btn-info btn-icon control-buttons" title="restore "><i
                                                class="fa fa-undo"></i></a>
                                    </td>
                                    <td class="text-center">{{$unitgroup->id}}</td>
                                    <td class="text-center">{{$unitgroup->unit_group_name}}</td>
                                    <td class="text-center">{{$unitgroup->description}}</td>
                                </tr>  
                                <?php
                                }
                                ?>
                            </tbody>
                        </table>
                    </div>
                </div>
                <!--/row-->
            </div>
        </div>
        @include('layouts.footer')
        </html>