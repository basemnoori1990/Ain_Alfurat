@include('layouts.header')
@include('layouts.nav', [
    'breadcrumbs' => [
        ['title' => 'خواص المنتجات',
        'route' => route("categoryspecifications.index"),
        'icon' => 'icon-cursor',],
        
        ['title' => 'الأرشيف',
        'route' => '',
        'icon' => '',]
    ],
])
        <div class="container-fluid">
            <div class="animated fadeIn">
                <div class="row">
                    <div class="col-lg-12">
                        <table class="table table-responsive table-striped">
                            <thead>
                                <tr class="bg-navy disabled ">
                                    <th class="text-center">تحكم</th>
                                    <th class="text-center">الرقم</th>
                                    <th class="text-center">الخاصية</th>
                                    <th class="text-center">الوصف</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php 
                                    
                                $i = 1;
                                
                                foreach($specifications as $spec)
                            {
                                    ?>
                                <tr>
                                    <td class="text-center"><a href="{{ route('categoryspecifications.restore_archive', $spec->id) }}"
                                        class="btn btn-info btn-icon control-buttons" title="restore "><i
                                            class="fa fa-undo"></i></a>
                                    
                                </td>
                                    <td class="text-center">{{$spec->id}}</td>
                                    <td class="text-center">{{$spec->specification_name}}</td>
                                    <td class="text-center">{{$spec->description}}</td>
                                    
                                </tr>  
                                <?php
                                }
                                ?>
                            </tbody>
                        </table>
                    </div>
                </div>
                <!--/row-->
            </div>

        </div>
@include('layouts.footer')
</html>