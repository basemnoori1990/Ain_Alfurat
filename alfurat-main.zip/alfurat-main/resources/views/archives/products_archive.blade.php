@include('layouts.header')
@include('layouts.nav', [
    'breadcrumbs' => [
        ['title' => 'المنتجات',
        'route' => route('web.products.index'),
        'icon' => 'icon-grid',],
        ['title' => 'الأرشيف',
        'route' => '',
        'icon' => '',],
    ],
])
<div class="container-fluid">

    <div class="animated fadeIn">
        <div class="col-lg-12">
            <table class="table table-responsive table-striped">
                <thead>
                    <tr class="bg-navy disabled ">
                        <th class="text-center">تحكم</th>
                        <th class="text-center">الرقم</th>
                        <td class="text-center">الاسم</td>
                        <td class="text-center">الوصف</td>
                        <td class="text-center">الصورة</td>
                        <td class="text-center">مجموعة الوحدات</td>
                        <td class="text-center">سعر الجملة</td>
                        <td class="text-center">وحدة الجملة</td>
                        <td class="text-center">سعر المفرد</td>
                        <td class="text-center">وحدة المفرد</td>
                        <td class="text-center">سعر كبار التجار</td>
                        <td class="text-center">وحدة كبار التجار</td>
                        <td class="text-center">المجموعة</td>
                        <td class="text-center">الشركة</td>
                        <td class="text-center">الخصم</td>
                    </tr>
                </thead>
                <tbody>
                    <?php 
                                
                            $i = 1;
                            
                            foreach($products as $product)
                        {
                            ?>
                    <tr>
                        <td class="text-center"><a href="{{ route('products.restore_archive', $product->id) }}"
                            class="btn btn-info btn-icon control-buttons" title="restore "><i
                                class="fa fa-undo"></i></a>
                        
                    </td>
                        <td class="text-center">{{$product->id}}</td>
                        <td class="text-center">{{$product->product_name}}</td>
                        <td class="text-center">{{$product->description}}</td>
                        <td class="text-center">
                            <img src="{{ asset('storage/' . $product->image)}}" style="width:50px">
                        </td>
                        <td class="text-center">{{isset($product->unit_group) ? $product->unit_group->unit_group_name
                            :''}}</td>
                        <td class="text-center">{{number_format($product->whole_sale_price)}}</td>
                        <td class="text-center">{{isset($product->whole_unit) ? $product->whole_unit->unit_name:''}}
                        </td>
                        <td class="text-center">{{number_format($product->retail_price)}}</td>
                        <td class="text-center">{{isset($product->retail_unit) ? $product->retail_unit->unit_name:''}}
                        </td>
                        <td class="text-center">{{number_format($product->vip_price)}}</td>
                        <td class="text-center">{{isset($product->vip_unit) ? $product->vip_unit->unit_name:''}}</td>
                        <td class="text-center">{{isset($product->category) ? $product->category->category_name:''}}
                        </td>
                        <td class="text-center">{{isset($product->company) ? $product->company->company_name:''}}</td>
                        <td class="text-center">{{$product->discount}}</td>
                        <?php
                            }
                            ?>
                </tbody>
            </table>
        </div>
    </div>
    <!--/row-->
</div>
</div>
@include('layouts.footer')
<script>
    $(function()
    {
    
    $('#group_id').select2();
    
    $('#unit_group_id').select2();
    $('#whole_unit_id').select2();
    $('#vip_unit_id').select2();
    $('#retail_unit_id').select2();
    
    $('#unit_group_id').change(function() {
    
    var unit_group_id = $(this).val();
    
    // Clear existing options in the second select
    
    $('#whole_unit_id').empty().trigger('change');
    $('#vip_unit_id').empty().trigger('change');
    $('#retail_unit_id').empty().trigger('change');
    
    if (unit_group_id) {
    // Make an AJAX request to fetch the options
    $.ajax({
    url: "{{ route('units.get_units_by_unit_group') }}", // URL to the server-side script that returns the options
    type: 'post',
    data: { _token: "{{ csrf_token() }}",unit_group_id:unit_group_id },
    success: function(response) {
    // Populate the second select with the response data
    var newOptions = $.map(response, function(option) {
    return {
    id: option.id,
    text: option.unit_name
    };
    });
    
    console.log(newOptions)
    $('#whole_unit_id').empty().select2({
    data: newOptions
    })
    $('#vip_unit_id').empty().select2({
    data: newOptions
    })
    $('#retail_unit_id').empty().select2({
    data: newOptions
    })
    
    },
    error: function(xhr, status, error) {
    console.error('AJAX Error: ' + status + error);
    }
    });
    }
    });
        })



  $(document).ready(function () {

});
     
</script>

</html>