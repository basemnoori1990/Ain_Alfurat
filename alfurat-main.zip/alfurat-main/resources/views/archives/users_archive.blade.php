@include('layouts.header')
@include('layouts.nav', [
    'breadcrumbs' => [
        ['title' => 'العملاء',
        'route' => route('users.index'),
        'icon' => 'icon-people',],
        
        ['title' => 'الأرشيف',
        'route' => '',
        'icon' => '',]
    ],
])
<div class="container-fluid">

    <div class="animated fadeIn">
        <div class="row">
            <div class="col-lg-12">
                <table class="table table-responsive table-striped">
                    <thead>
                        <tr class="bg-navy disabled ">
                            <th class="text-center">تحكم</th>
                            <th class="text-center">الرقم</th>
                            <th class="text-center">اسم المالك</th>
                            <th class="text-center">اسم المتجر</th>
                            <th class="text-center">الهاتف</th>
                            <th class="text-center">البريد الإلكرتوني</th>
                            {{-- <th class="text-center">كود التفعيل</th> --}}
                            <th class="text-center">المحافظة</th>
                            <th class="text-center">العنوان</th>
                            <th class="text-center">هاتف المتجر</th>
                            <th class="text-center">الموقع الجغرافي</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                                $i = 1;
                                foreach($users as $user)
                            {
                                ?>
                        <tr>
                            <td class="text-center control">
                                <a href="{{ route('users.restore_archive', $user->id) }}"
                                    class="btn btn-info btn-icon control-buttons" title="restore "><i
                                        class="fa fa-undo"></i></a>
                            </td>
                            <td class="text-center">{{ $user->id }}</td>
                            <td class="text-center">{{ isset($user->store) ? $user->store->owner_name : '' }}</td>
                            <td class="text-center">{{ isset($user->store) ? $user->store->store_name : '' }}</td>
                            <td class="text-center">{{ $user->phone }}</td>
                            <td class="text-center">{{ $user->email }}</td>
                            {{-- <td class="text-center">{{$user->verification_code}}</td> --}}
                            <td class="text-center">{{ isset($user->store) ? $user->store->district : '' }}</td>
                            <td class="text-center">{{ isset($user->store) ? $user->store->address : '' }}</td>
                            <td class="text-center">{{ isset($user->store) ? $user->store->phone : '' }}</td>
                            <td class="text-center">
                                <a target="_blank"
                                    href="{{ isset($user->store) ? 'https://www.google.com/maps?q=' . $user->store->lat . ',' . $user->store->lng . '&z=17' : '' }}">الموقع
                                    الجغرافي</a>
                            </td>
                        </tr>
                        <?php
                                }
                                ?>
                    </tbody>
                </table>
            </div>
        </div>
        <!--/row-->
    </div>
</div>
@include('layouts.footer')

</html>
