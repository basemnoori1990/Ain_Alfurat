@include('layouts.header')
@include('layouts.nav', [
    'breadcrumbs' => [
        ['title' => 'الوحدات',
        'route' => route("units.index"),
        'icon' => 'icon-compass',],
        ['title' => 'الأرشيف',
        'route' => '',
        'icon' => '',],
    ],
])
<div class="container-fluid">

            <div class="animated fadeIn">
                <div class="row">
                    
                    <div class="col-lg-12">
                        <table class="table table-responsive table-striped">
                            <thead>
                                <tr class="bg-navy disabled ">
                                    <th class="text-center">تحكم</th>
                                    <th class="text-center">الرقم</th>
                                    <th class="text-center">الاسم</th>
                                    <th class="text-center">القيمة المقابلة</th>
                                    <th class="text-center">المجموعة</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php 
                                    
                                $i = 1;
                                
                                foreach($units as $unit)
                            {
                                ?>
                                <tr>
                                    <td class="text-center">
                                        <a href="{{ route('units.restore_archive', $unit->id) }}"
                                            class="btn btn-info btn-icon control-buttons" title="restore "><i
                                                class="fa fa-undo"></i></a>
                                    </td>
                                    <td class="text-center">{{$unit->id}}</td>
                                    <td class="text-center">{{$unit->unit_name}}</td>
                                    <td class="text-center">{{$unit->eq}}</td>
                                    <td class="text-center">{{$unit->unit_group->unit_group_name ?? ''}}</td>
                                    
                                </tr>  
                                <?php
                                }
                                ?>
                            </tbody>
                        </table>
                    </div>
                </div>
                <!--/row-->
            </div>
        </div>
        @include('layouts.footer')
        </html>