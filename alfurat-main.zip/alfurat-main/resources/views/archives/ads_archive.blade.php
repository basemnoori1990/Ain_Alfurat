@include('layouts.header')
@include('layouts.nav', [
    'breadcrumbs' => [
        ['title' => 'الإعلانات',
        'route' => route("web.ads.index"),
        'icon' => 'icon-screen-desktop',],
        ['title' => 'الأرشيف',
        'route' => '',
        'icon' => '',],
    ],
])
<div class="container-fluid">

            <div class="animated fadeIn">
                <div class="row">
                    <div class="col-lg-12">
                        <table class="table table-responsive table-striped">
                            <thead>
                                <tr class="bg-navy disabled ">
                                    <th class="text-center">تحكم</th>
                                    <th class="text-center">الرقم</th>
                                    <th class="text-center">العنوان</th>
                                    <th class="text-center">الوصف</th>
                                    <th class="text-center">المنتج</th>
                                    <th class="text-center">الصورة</th>
                                    <th class="text-center">نوع الاعلان</th>
                                    <th class="text-center">تاريخ الانتهاء</th>
                                    <th class="text-center">تاريخ الحذف</th>
                                </tr>
                            </thead>'
                            <tbody>
                                <?php 
                                    
                                $i = 1;
                                
                                foreach($ads as $ad)
                            {
                                ?>
                                <tr>
                                    <td class="text-center control">
                                        <a href="{{ route('ads.restore_archive', $ad->id) }}"
                                            class="btn btn-info btn-icon control-buttons" title="restore "><i
                                                class="fa fa-undo"></i></a>
                                    </td>
                                    <td class="text-center">{{$ad->id}}</td>
                                    <td class="text-center">{{$ad->title}}</td>
                                    <td class="text-center">{{$ad->description}}</td>
                                    <td class="text-center">{{ $ad->product->product_name ?? ''}}</td>
                                    <td class="text-center">
                                        <img src="
                                        {{ asset('storage/' . $ad->image)}}
                                        "
                                        style="width:50px">
                                    </td>
                                    <td class="text-center">{{$ad->ad_type}}</td>
                                    <td class="text-center">{{date('Y-m-d', strtotime($ad->expiration_time))}}</td>
                                    <td class="text-center">{{isset($ad->deleted_at)?date('Y-m-d', strtotime($ad->deleted_at)):''}}</td>
                                    
                                </tr>  
                                <?php
                                }
                                ?>
                            </tbody>
                        </table>
                    </div>
                </div>
                <!--/row-->
            </div>

        </div>
    @include('layouts.footer')
    <script>
        $(function(){
            $('#product_id').select2({
                placeholder: "اختر المنتج",
                allowClear: true,
            })
        })
        </script>
    </html>