@include('layouts.header')
@include('layouts.nav', [
    'breadcrumbs' => [
        ['title' => 'الطلبات',
        'route' => route('web.orders.index'),
        'icon' => 'icon-chart',],
        ['title' => 'الأرشيف',
        'route' => '',
        'icon' => '',],
    ],
])
<div class="container-fluid">

            <div class="animated fadeIn">
                <div class="row">
                    <div class="col-lg-12">
                        <table class="table table-responsive table-striped">
                            <thead>
                                <tr class="bg-navy disabled ">
                                    <th class="text-center"></th>
                                    <th class="text-center">الرقم</th>
                                    <th class="text-center">المستخدم</th>
                                    <th class="text-center">العنوان</th>
                                    <th class="text-center" width="20%">المندوب</th>
                                    <th class="text-center">الموقع الجغرافي</th>
                                    <th class="text-center">تاريخ الطلب</th>
                                    <th class="text-center">قيمة الطلب</th>
                                    <th class="text-center">الضريبة</th>
                                    <th class="text-center">التوصيل</th>
                                    <th class="text-center">التخفيض</th>
                                    <th class="text-center">المجموع</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php 
                                    
                                $i = 1;
                                
                                foreach($orders as $order)
                            {
                                ?>
                                <tr>
                                    <td class="text-center">
                                        <a href="{{ route('weborders.restore_archive', $order->id) }}"
                                            class="btn btn-info btn-icon control-buttons" title="restore "><i
                                                class="fa fa-undo"></i></a>
                                    </td>
                                    <td class="text-center">
                                        {{$order->id}}
                                    </td>
                                        <td class="text-center">
                                            {{isset($order->user->store->owner_name) ? $order->user->store->owner_name:''}}<br>
                                        {{isset($order->user->store->store_name) ? $order->user->store->store_name:''}}
                                    </td>
                                    <td class="text-center">
                                        {{$order->address}}
                                    </td>
                                    <td class="text-center">
                                       {{ $order->user->name }}
                                    </td>
                                    <td class="text-center">
                                        <a href="{{$order->location}}" target="_blank" ><span style="color:black !important">الموقع الجغرافي</span></a>
                                    </td>
                                    <td class="text-center">{{$order->order_date}}</td>
                                    <td class="text-center">{{number_format($order->sub_total)}}</td>
                                    <td class="text-center">{{number_format($order->tax)}}</td>
                                    <td class="text-center">{{number_format($order->delivery_fees)}}</td>
                                    <td class="text-center">{{number_format($order->discount)}}</td>
                                    <td class="text-center">{{number_format($order->total)}}</td>
                                    
                                </tr>  
                                <?php
                                }
                                ?>
                            </tbody>
                        </table>
                    </div>  
                <!--/row-->
            </div>
        </div>
        <div id="dialog-confirm" title="تنبيه">
            <p><span class="ui-icon ui-icon-alert" style="float:left; margin:12px 12px 20px 0;"></span>هل تود تعيين هذا المندوب</p>
          </div>
        @include('layouts.footer')
<script>    

function confirmed()
    {
      $('#dialog-confirm').dialog('close')
    }
    </script>