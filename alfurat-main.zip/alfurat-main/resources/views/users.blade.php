@include('layouts.header')
@include('layouts.nav', [
    'breadcrumbs' => [
        ['title' => 'العملاء',
        'route' => route("users.index"),
        'icon' => 'icon-people',],
    ],
])
<div class="container-fluid">

            <div class="animated fadeIn">
                <div class="row">
                    <div class="col-lg-12">
                        <a  href="{{ route('users.get_archive') }}" class="btn btn-info">الأرشيف</a>
                        <table class="table table-responsive table-striped">
                            <thead>
                                <tr class="bg-navy disabled ">
                                    <th class="text-center">تحكم</th>
                                    <th class="text-center">الرقم</th>
                                    <th class="text-center">اسم المالك</th>
                                    <th class="text-center">اسم المتجر</th>
                                    <th class="text-center">الهاتف</th>
                                    <th class="text-center">البريد الإلكرتوني</th>
                                    {{--<th class="text-center">كود التفعيل</th>--}}
                                    <th class="text-center">المحافظة</th>
                                    <th class="text-center">العنوان</th>
                                    <th class="text-center">هاتف المتجر</th>
                                    <th class="text-center">الموقع الجغرافي</th>
                                    <th class="text-center">الحالة</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php 
                                $i = 1;
                                foreach($users as $user)
                            {
                                ?>
                                <tr>
                                    <td class="text-center control">
                                        <span id="delete" data-id="{{$user->id}}" data-model="users" class="btn btn-danger btn-icon control-buttons delete" title="Delete"><i class="fa fa-trash-o"></i></span>
                                    </td>
                                    <td class="text-center">{{$user->id}}</td>
                                    <td class="text-center">{{isset($user->store)?$user->store->owner_name:'' }}</td>
                                    <td class="text-center">{{isset($user->store)?$user->store->store_name:'' }}</td>
                                    <td class="text-center">{{$user->phone}}</td>
                                    <td class="text-center">{{$user->email}}</td>
                                    {{-- <td class="text-center">{{$user->verification_code}}</td> --}}
                                    <td class="text-center">{{isset($user->store)?$user->store->district:'' }}</td>
                                    <td class="text-center">{{isset($user->store)?$user->store->address:'' }}</td>
                                    <td class="text-center">{{isset($user->store)?$user->store->phone:'' }}</td>
                                    <td class="text-center">
                                        <a target="_blank" href="{{isset($user->store)?"https://www.google.com/maps?q=".$user->store->lat.",".$user->store->lng."&z=17":''}}" >الموقع الجغرافي</a>
                                    </td>
                                    <td class="text-center"> 
                                        <label class="switch switch-text switch-info">
                                        <input type="checkbox" class="switch-input status" data-type="user" data-id="{{$user->id}}"
                                        @if ($user->status==1)
                                        checked
                                        @endif
                                        >
                                        <span class="switch-label" data-on="مفعل" data-off="معطل"></span>
                                        <span class="switch-handle"></span>
                                    </label>
                                </td>                                </tr>  
                                <?php
                                }
                                ?>
                            </tbody>
                        </table>
                    </div>
                </div>
                <!--/row-->
            </div>
        </div>
        @include('layouts.footer')
        </html>