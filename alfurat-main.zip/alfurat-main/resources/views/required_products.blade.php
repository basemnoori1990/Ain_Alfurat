@include('layouts.header')
@include('layouts.nav', [
    'breadcrumbs' => [
        ['title' => 'المنتجات',
        'route' => route('web.products.index'),
        'icon' => 'icon-grid',],
        ['title' => 'المنتجات المطلوبة',
        'route' => '',
        'icon' => '',],
    ]
])
<div class="container-fluid">
        <div class="animated fadeIn">
            <div class="row">
                <div class="col-lg-6">
                </div>
                @if (session()->has('message'))
                    <div class="alert alert-success">
                        {{ session()->get('message') }}
                    </div>
                @endif
            </div>
            <div class="row">
                <div class="col-lg-8">
                    {{ $product->product_name }}
                    <table class="table table-responsive table-striped">
                        <thead>
                            <tr class="bg-navy disabled ">
                                <th class="text-center">تحكم</th>
                                <th class="text-center">الرقم</th>
                                <th class="text-center">الاسم</th>
                                <th class="text-center">وحدة المنتج الاساس</th>
                                <th class="text-center">كمية المنتج الاساسي</th>
                                <th class="text-center">المنتج المفروض</th>
                                <th class="text-center">وحدة المنتج المفروض</th>
                                <th class="text-center">الكمية المفروضة</th>
                                <th class="text-center">الحالة</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php 
                                
                            $i = 1;
                            if (isset($product->required_products))
                        foreach($product->required_products as $required_product)
                        {
                   ?>
                            <tr>
                                <td class="text-center"><a href="" class="btn btn-info btn-icon control-buttons" title="Edit "><i class="fa fa-pencil-square-o fa-pencil"></i></span>
                                    <a href="#" id="delete" data-id="{{$required_product->id}}" data-model="orders" class="btn btn-danger btn-icon control-buttons" title="Delete"><i class="fa fa-trash-o"></i></a>
                                </td>
                                <td class="text-center">{{ $required_product->id }}</td>
                                <td class="text-center">{{ $required_product->product_name }}</td>
                                <td class="text-center">{{ isset($required_product->pivot->base_unit) ? $required_product->pivot->base_unit->unit_name:'' }}</td>
                                <td class="text-center">{{ $required_product->pivot->quantity }}</td>
                                <td class="text-center">{{ isset($required_product->pivot->required_product) ? $required_product->pivot->required_product->product_name:'' }}</td>
                                <td class="text-center">{{ isset($required_product->pivot->required_unit) ? $required_product->pivot->required_unit->unit_name:'' }}</td>
                                <td class="text-center">{{ $required_product->pivot->required_quantiy }}</td>
                                <td class="text-center"> 
                                    <label class="switch switch-text switch-info">
                                    <input type="checkbox" class="switch-input status" data-type="required_products" data-id="{{$product->id}}"
                                    @if ($product->status==1)
                                    checked
                                    @endif
                                    >
                                        <span class="switch-label" data-on="مفعل" data-off="معطل"></span>
                                        <span class="switch-handle"></span>
                                    </label>
                                </td>
                            </tr>
                            <?php
                            }
                            ?>
                        </tbody>
                    </table>
                </div>
                <div class='col-lg-4'>
                    <form method="POST" enctype="multipart/form-data"
                        action="{{ route('/products/add_required_product') }}">
                        @csrf
                        <div class="form-group">
                            <label for="product_name">المنتج الاساسي</label>
                            <input class="form-control" value="{{ $product->id }}" hidden="hidden" name='product_id'>
                            <input class="form-control" value="{{ $product->product_name }}" readonly name='product_name'>
                        </div>
                        <div class="form-group">
                            <label for="unit_id">وحدة المنتج الاساسي</label>
                            <select class="select form-control" name="unit_id">
                                <option value="{{ $product->whole_unit->id }}">{{ $product->whole_unit->unit_name }}
                                </option>
                                <option value="{{ $product->retail_unit->id }}">{{ $product->retail_unit->unit_name }}
                                </option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="quantity">كمية المنتج الاساسي</label>
                            <input class="form-control" type="number" step="0.00001" name='quantity'>
                        </div>
                        <div class="form-group">
                            <label for="required_product_id">المنتج المفروض</label>
                            <select class="select form-control" id="required_product_id" name="required_product_id">
                                @foreach ($products as $_product)
                                    <option value="{{ $_product->id }}">{{ $_product->product_name }}</option>
                                @endforeach
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="required_unit_id">وحدة المنتج المفروض</label>
                            <select class="select form-control" id="required_unit_id" name="required_unit_id">
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="required_quantiy">كمية المنتج المفروض</label>
                            <input class="form-control" type="number" step="0.00001" name='required_quantiy'>
                        </div>


                        <input type="submit" class="btn btn-success" value="حفظ">
                    </form>
                </div>
            </div>
            <!--/row-->
        </div>

    </div>
    
@include('layouts.footer')
<script>
    var appUrl = "{{ env('APP_URL') }}";
    $(document).ready(function() {
        $('#required_product_id').select2();

        var selectedValue = {{ $products[0]->id }};
        $.ajax({
            url: appUrl + '/public/index.php/products/get_product_units/' + selectedValue,
            method: 'GET',
            dataType: 'json', // Adjust the data type based on your server response
            success: function(data) {
                // Assuming data is an array of objects with 'value' and 'text' properties
                // You can adjust this based on your actual data structure
                var select = $('#required_unit_id');

                // Clear existing options, if any
                select.empty();

                // Add a default option
                // select.append($('<option>').val('').text('Select an option'));

                // Loop through the data and append options to the select element
                $.each(data, function(index, item) {
                    select.append($('<option>').val(item.whole_unit.id).text(item.whole_unit
                        .unit_name));
                    select.append($('<option>').val(item.retail_unit.id).text(item
                        .retail_unit.unit_name));
                });
            }
        })

        $.ajax({
            url: appUrl + '/public/index.php/products/get_products/{{ $product->id }}',
            method: 'GET',
            dataType: 'json', // Adjust the data type based on your server response
            success: function(data) {
                // Assuming data is an array of objects with 'value' and 'text' properties
                // You can adjust this based on your actual data structure
                var select = $('#required_product_id');
                // $('#required_product_id').empty().trigger('change');

                // Clear existing options, if any
                // select.empty();
                // console.log(data);
                // return
                // Add a default option
                // select.append($('<option>').val('').text('Select an option'));

                // Loop through the data and append options to the select element
                // $.each(data, function(index, item) {
                //     select.append($('<option>').val(item.whole_unit.id).text(item.whole_unit
                //         .unit_name));
                //     select.append($('<option>').val(item.retail_unit.id).text(item
                //         .retail_unit.unit_name));
                // });
            }
        })

        $('#required_product_id').on('change', function() {
            var selectedValue = $(this).val();
            $.ajax({
                url: appUrl + '/public/index.php/products/get_product_units/' + selectedValue,
                method: 'GET',
                dataType: 'json', // Adjust the data type based on your server response
                success: function(data) {
                    // Assuming data is an array of objects with 'value' and 'text' properties
                    // You can adjust this based on your actual data structure
                    var select = $('#required_unit_id');

                    // Clear existing options, if any
                    select.empty();

                    // Add a default option
                    // select.append($('<option>').val('').text(''));

                    // Loop through the data and append options to the select element
                    $.each(data, function(index, item) {
                        if (item !== null)
                    {
                        select.append($('<option>').val(item.whole_unit.id).text(
                            item.whole_unit.unit_name));
                        select.append($('<option>').val(item.retail_unit.id).text(
                            item.retail_unit.unit_name));
                        }
                    });
                },
                error: function(xhr, status, error) {
                    // Handle errors here
                    console.error('Error fetching data: ' + error);
                }
            });
        });

    })
</script>
</html>