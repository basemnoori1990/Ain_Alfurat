@include('layouts.header')
@include('layouts.nav', [
    'breadcrumbs' => [
        ['title' => 'الإعلانات',
        'route' => route("web.ads.index"),
        'icon' => 'icon-screen-desktop',],
        ['title' => 'تعديل',
        'route' => '',
        'icon' => '',],
    ],
])
        <div class="container-fluid">
            <div class="animated fadeIn">
                <div class="row">
                    <div class='col-lg-6'>
                        <form method="POST" enctype="multipart/form-data" action="{{route('web.ads.update',$ad->id)}}">
                            @csrf   
                            @method('PUT')
                            <div class="form-group">
                                <label for="title">العنوان</label>
                            <input required class="form-control" name='title' value="{{$ad->title}}" >
                            </div>
                            <div class="form-group">
                                <label for="description">الوصف</label>
                            <input required class="form-control" name='description' value="{{$ad->description}}">
                            </div>
                            <div class="form-group">
                                <label for="image">الصورة</label>
                            <input type="file" class="form-control" name='image' >
                            </div>
                            <div class="form-group">
                                <label for="product_id">المنتج</label>
                                <select required class="select form-control" name="product_id">
                                    @foreach ($products as $product)
                                        <option
                                        @if($product->id==$ad->product_id)
                                        selected
                                        @endif
                                        value="{{ $product->id }}">{{ $product->product_name }}</option>
                                    @endforeach
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="image">الصورة</label>
                           <img src="{{asset('storage/' . $ad->image)}}" style="width:200px"/>
                            </div>
                            <div class="form-group">
                                <label for="ad_type">نوع الاعلان</label>
                            <input required class="form-control" value="{{$ad->ad_type}}" name='ad_type' >
                            </div>
                            <div class="form-group">
                                <label for="expiration_time">تاريخ الانتهاء</label>
                            <input required type="date" class="form-control" value="{{date('Y-m-d',strtotime($ad->expiration_time))}}" name='expiration_time' >
                            </div>
                             <input type="submit" class="btn btn-success" value="حفظ">
                        </form>
                    </div>
                </div>
                <!--/row-->
            </div>
        </div>
        @include('layouts.footer')
        </html>