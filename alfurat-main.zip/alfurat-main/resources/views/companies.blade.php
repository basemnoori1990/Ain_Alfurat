@include('layouts.header')
@include('layouts.nav', [
    'breadcrumbs' => [
        ['title' => 'الشركات',
        'route' => route("web.companies.index"),
        'icon' => 'icon-folder-alt',]
    ],
])
        <div class="container-fluid">
            <div class="animated fadeIn">
                <div class="row">
                    <div class='col-lg-6'>
                        <form method="POST" enctype="multipart/form-data" action="{{route('web.companies.store')}}">
                            @csrf   
                            <div class="form-group">
                                <label for="company_name">اسم الشركة</label>
                            <input class="form-control" name='company_name' >
                            </div>
                            <div class="form-group">
                                <label for="description">الوصف</label>
                            <input class="form-control" name='description' >
                            </div>
                            <div class="form-group">
                                <label for="image">الشعار</label>
                            <input type="file" class="form-control" name='logo' >
                            </div>
                            <input type="submit" class="btn btn-success" value="حفظ">
                            <a href="{{ route('companies.get_archive') }}" class="btn btn-info">الأرشيف</a>
                        </form>
                    </div>
                    <div class="col-lg-6">
                        <table class="table table-responsive table-striped">
                            <thead>
                                <tr class="bg-navy disabled ">
                                <th class="text-center">تحكم</th>
                                <th class="text-center">الرقم</th>
                                    <th class="text-center">اسم الشركة</th>
                                    <th class="text-center">الوصف</th>
                                    <th class="text-center">الشعار</th>
                                    <th class="text-center">الحالة</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php 
                                    
                                $i = 1;
                                
                                foreach($companies as $company)
                            {
                                ?>
                                <tr>
                                    <td class="text-center"><a href="{{route('companies.edit',$company->id)}}" class="btn btn-info btn-icon control-buttons" title="Edit "><i class="fa fa-pencil-square-o fa-pencil"></i></a>
                                        <span id="delete" data-id="{{$company->id}}" data-model="companies" class="btn btn-danger btn-icon control-buttons delete" title="Delete"><i class="fa fa-trash-o"></i></span></td>
                                    <td class="text-center">{{$company->id}}</td>
                                    <td class="text-center">{{$company->company_name}}</td>
                                    <td class="text-center">{{$company->description}}</td>
                                    <td class="text-center">
                                        <img src="
                                        {{ asset('storage/' . $company->logo)}}
                                        "
                                        style="width:50px">
                                    </td>
                                    <td class="text-center"> 
                                        <label class="switch switch-text switch-info">
                                        <input type="checkbox" class="switch-input status" data-type="company" data-id="{{$company->id}}"
                                        @if ($company->status==1)
                                        checked
                                        @endif
                                        >
                                        <span class="switch-label" data-on="مفعل" data-off="معطل"></span>
                                        <span class="switch-handle"></span>
                                    </label>
                                </td>
                                </tr>  
                                <?php
                                }
                                ?>
                            </tbody>
                        </table>
                    </div>
                </div>
                <!--/row-->
            </div>
        </div>
    @include('layouts.footer')
    </html>