@include('layouts.header')
@include('layouts.nav', [
    'breadcrumbs' => [
        ['title' => 'الصلاحيات', 'route' => route('roles.index'), 'icon' => 'icon-people'],

        ['title' => 'تعديل', 'route' => '', 'icon' => ''],
    ],
])
<div class="container-fluid">
    <div class="animated fadeIn container-fluid">
        <div class="row">
            <div class='col-lg-12'>
                <form method="POST" action="{{ route('roles.update', $role->id) }}">
                    @csrf
                    @method('put')
                    @if (session()->has('success'))
                        <div class="alert alert-success">{{ session('success') }}</div>
                    @endif
                    <div class="form-group">
                        <label for="specification_name">الدور</label>
                        <input class="form-control" name='role' value="{{ $role->name }}" type="text" id="role">
                        @error('role')
                            <span class="text-danger" role="alert">{{ $message }}</span>
                        @enderror
                    </div>
                    <div class="form-group">
                        <div class="row">
                            @foreach ($permissions as $permission)
                                <div class="col-md-3">
                                    <input class="form-check-input" type="checkbox" value="{{ $permission->id }}"
                                        id="checkDefault{{ $permission->id }}" name="permissions[]" @checked(in_array($permission->id , $role->permissions->pluck('id')->toArray()))>
                                    <label class="form-check-label" for="checkDefault">
                                        {{ $permission->name }}
                                    </label>
                                </div>
                            @endforeach
                        </div>
                        @error('permissions')
                            <span class="text-danger" role="alert">{{ $message }}</span>
                        @enderror
                    </div>
                    <input type="submit" class="btn btn-success" value="حفظ">
                </form>
            </div>
        </div>
        <!--/row-->
    </div>
</div>

@include('layouts.footer')

</html>
