@include('layouts.header')
@include('layouts.nav', [
    'breadcrumbs' => [['title' => 'الصلاحيات', 'route' => route('roles.index'), 'icon' => 'icon-people']],
])
<div class="container-fluid">

    <div class="animated fadeIn container-fluid">
        <div class="row">
            <div class='col-lg-6'>
                <div class="row my-5">
                    <form method="POST" action="{{ route('roles.store') }}">
                        @csrf
                        @if (session()->has('success'))
                            <div class="alert alert-success">{{ session('success') }}</div>
                        @endif
                        @if (session()->has('error'))
                            <div class="alert alert-danger">{{ session('error') }}</div>
                        @endif
                        <div class="form-group">
                            <label for="specification_name">إنشاء دور</label>
                            <input class="form-control" name='role'>
                            @error('role')
                                <span class="text-danger" role="alert">{{ $message }}</span>
                            @enderror
                        </div>
                        <div class="form-group">
                            <div class="row">
                                @foreach ($permissions as $permission)
                                    <div class="col-md-4">
                                        <input class="form-check-input" type="checkbox" value="{{ $permission->id }}"
                                            id="checkDefault{{ $permission->id }}" name="permissions[]">
                                        <label class="form-check-label" for="checkDefault">
                                            {{ $permission->name }}
                                        </label>
                                    </div>
                                @endforeach
                            </div>
                            @error('permissions')
                                <span class="text-danger" role="alert">{{ $message }}</span>
                            @enderror
                        </div>

                        <input type="submit" class="btn btn-success mb-5" value="حفظ">
                    </form>
                </div>
                <br>
                <div class="row my-5">
                    <form method="POST" action="{{ route('permissions.store') }}">
                        @csrf

                        <div class="form-group">
                            <label for="specification_name">إنشاء صلاحية</label>
                            <input class="form-control" name='permission'>
                            @error('permission')
                                <span class="text-danger" role="alert">{{ $message }}</span>
                            @enderror
                        </div>

                        <input type="submit" class="btn btn-success" value="حفظ">
                    </form>
                </div>
            </div>
            <div class="col-lg-6">
                <table class="table table-responsive table-striped">
                    <thead>
                        <tr class="bg-navy disabled ">
                            <th class="text-center">العمليات</th>
                            <th class="text-center">الرقم</th>
                            <th class="text-center">الدور</th>
                            <th class="text-center">الصلاحيات</th>
                        </tr>
                    </thead>'
                    <tbody>
                        <?php 
                                    
                                $i = 1;
                                
                                foreach($roles as $role)
                            {
                                ?>
                        <tr>
                            <td class="text-center control">
                                <a href="{{ route('roles.edit', $role->id) }}"
                                    class="btn btn-info btn-icon control-buttons" title="Edit "><i
                                        class="fa fa-pencil-square-o fa-pencil"></i></a>
                                <form action="{{ route('roles.destroy', $role->id) }}" method="post">
                                    @csrf
                                    @method('DELETE')
                                    <button type="submit" class="btn btn-danger btn-icon control-buttons"><i
                                            class="fa fa-trash-o"></i></button>
                                    {{-- <span id="delete" data-id="{{$ad->id}}" data-model="admins" class="btn btn-danger btn-icon control-buttons delete" title="Delete"><i class="fa fa-trash-o"></i></span> --}}
                                </form>
                            </td>
                            <td class="text-center">{{ $role->id }}</td>
                            <td class="text-center">{{ $role->name }}</td>
                            <td class="text-center">
                                @foreach ($role->permissions as $permission)
                                    <span>{{ $permission->name }}،</span>
                                @endforeach
                            </td>

                        </tr>
                        <?php
                                }
                                ?>
                    </tbody>
                </table>
            </div>
        </div>
        </row>
    </div>

</div>
@include('layouts.footer')

</html>
