@include('layouts.header')
@include('layouts.nav', [
    'breadcrumbs' => [
        ['title' => 'المجموعات',
        'route' => route("web.categories.index"),
        'icon' => 'icon-organization',],
        ['title' => 'تعديل',
        'route' => '',
        'icon' => '',],
    ],
])
<div class="container-fluid">
    <div class="animated fadeIn">
        <div class="row">
            <div class='col-lg-6'>
                <form method="POST" enctype="multipart/form-data" action="{{ route('web.categories.update', $category->id) }}">
                    @csrf
                    @method('PUT')
                    <div class="form-group">
                        <label for="category_name">اسم المجموعة</label>
                        <input class="form-control" value="{{ $category->category_name }}" name='category_name'>
                    </div>
                    <div class="form-group">
                        <label for="description">الوصف</label>
                        <input class="form-control" value="{{ $category->description }}" name='description'>
                    </div>
                    <div class="form-group">
                        <label for="image">الصورة</label>
                        <input type="file" class="form-control" name='image'>
                    </div>
                    <div class="form-group">
                        <label for="image">الصورة</label>
                        <img src="{{ asset('storage/' . $category->image) }}" style="width:200px" />
                    </div>
                    <div class="form-group">
                        <label for="main_category_id">المجموعة الرئيسية</label>
                        <select class="select form-control" id="main_category_id" name="main_category_id">
                            <option value="-1">لا يوجد</option>
                            @foreach ($main_categories as $_category)
                                <option value="{{ $_category->id }}">{{ $_category->category_name }}</option>
                            @endforeach
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="category_specification_id">خواص المنتجات</label>
                        <select class="select form-control" name="category_specification_id">
                            <option value="-1">لا يوجد</option>
                            @foreach ($specifications as $spec)
                                @if ($category->category_specification_id == $spec->id)
                                    selected
                                @endif
                                <option value="{{ $spec->id }}">{{ $spec->specification_name }}</option>
                            @endforeach
                        </select>
                    </div>

                    <input type="submit" class="btn btn-success" value="حفظ">
                </form>
            </div>
        </div>
        <!--/row-->
    </div>
</div>
@include('layouts.footer')
<script>
    $(function() {
        $('#main_category_id').select2().on('change', function() {
            var main_category_id = $(this).val();
            var sub_category_id = $('#sub_category_id');

            // Clear existing options in the second select
            // sub_category_id.empty().trigger('change');

            // if (main_category_id) {
            // Make an AJAX request to fetch the options
            $.ajax({
                url: "{{ route('categories.get_sub_categories') }}", // URL to the server-side script that returns the options
                type: 'post',
                data: {
                    _token: "{{ csrf_token() }}",
                    id: $("#main_category_id").val(),
                    category_id:{{ $category->id }}
                },
                success: function(response) {
                    // Populate the second select with the response data
                    var newOptions = $.map(response.sub_categories, function(option) {
                        // console.log(option[0]);
                        return {
                            id: option.id,
                            text: option.category_name
                        };
                    });

                    sub_category_id.empty().select2({
                        data: newOptions
                    })
                    @if ($category->level == 2 && $category->parent_id!=null)
                        sub_category_id.val({{ $category->id }}).trigger("change");
                    @elseif ($category->level == 3&& $category->parent_id!=null)
                        sub_category_id.val({{ $category->parent_id }}).trigger("change");
                    @endif
                },
                error: function(xhr, status, error) {
                    console.error('AJAX Error: ' + status + error);
                }
            });
            // }
        });
        $('#sub_category_id').select2();
        @if ($category->level == 2&& $category->parent_id!=null)
            $("#main_category_id").val({{ $category->parent_id }})
            $("#main_category_id").trigger('change');
        @elseif ($category->level == 3&& $category->parent_id!=null)
            @php
                $sub_category = \App\Models\Category::find($category->parent_id);
                $main_category = \App\Models\Category::find($sub_category->parent_id);
            @endphp
            $("#main_category_id").val({{ isset($main_category->id)?$main_category->id:-1 }})
            $("#main_category_id").trigger('change');;
        @endif


    })
</script>

</html>
