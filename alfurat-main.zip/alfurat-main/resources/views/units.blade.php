@include('layouts.header')
@include('layouts.nav', [
    'breadcrumbs' => [
        ['title' => 'الوحدات',
        'route' => route("units.index"),
        'icon' => 'icon-compass',],
    ],
])
<div class="container-fluid">

            <div class="animated fadeIn">
                <div class="row">
                    <div class='col-lg-6'>
                        <form method="POST" action="{{route('units.store')}}">
                            @csrf   
                            <div class="form-group">
                                <label for="unit_name">اسم الوحدة</label>
                            <input class="form-control" name='unit_name' >
                            </div>
                            <div class="form-group">
                                <label for="unit_name">القيمة  المقابلة</label>
                            <input class="form-control" type="number" step="0.0001" name='eq' >
                            </div>
                            <div class="form-group">
                                <label for="unit_name">مجموعة الوحدات</label>
                                <select class="select form-control" name="unit_group_id">
                                    @foreach($unitgroups as $unitgroup)
                                    <option value="{{$unitgroup->id}}">{{$unitgroup->unit_group_name}}</option>
                                    @endforeach
                                </select>                            
                            </div>
        <input type="submit" class="btn btn-success" value="حفظ">
        <a  href="{{ route('units.get_archive') }}" class="btn btn-info">الأرشيف</a>
                        </form>
                    </div>
                    
                    <div class="col-lg-6">
                        <table class="table table-responsive table-striped">
                            <thead>
                                <tr class="bg-navy disabled ">
                                    <th class="text-center">تحكم</th>
                                    <th class="text-center">الرقم</th>
                                    <th class="text-center">الاسم</th>
                                    <th class="text-center">القيمة المقابلة</th>
                                    <th class="text-center">المجموعة</th>
                                    <th class="text-center">الحالة</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php 
                                    
                                $i = 1;
                                
                                foreach($units as $unit)
                            {
                                ?>
                                <tr>
                                    <td class="text-center"><div class="controls"><a href="{{route('units.edit',$unit->id)}}" class="btn btn-info btn-icon control-buttons" title="Edit "><i class="fa fa-pencil-square-o fa-pencil"></i></a>
                                        <span id="delete" data-id="{{$unit->id}}" data-model="units" class="btn btn-danger btn-icon control-buttons delete" title="Delete"><i class="fa fa-trash-o"></i></span>
                                    </div></td>
                                    <td class="text-center">{{$unit->id}}</td>
                                    <td class="text-center">{{$unit->unit_name}}</td>
                                    <td class="text-center">{{$unit->eq}}</td>
                                    <td class="text-center">{{$unit->unit_group->unit_group_name ?? ''}}</td>
                                    <td class="text-center"> 
                                        <label class="switch switch-text switch-info">
                                        <input type="checkbox" class="switch-input status" data-type="unit" data-id="{{$unit->id}}"
                                        @if ($unit->status==1)
                                        checked
                                        @endif
                                        >
                                        <span class="switch-label" data-on="مفعل" data-off="معطل"></span>
                                        <span class="switch-handle"></span>
                                    </label>
                                </td>
                                </tr>  
                                <?php
                                }
                                ?>
                            </tbody>
                        </table>
                    </div>
                </div>
                <!--/row-->
            </div>
        </div>
        @include('layouts.footer')
        </html>