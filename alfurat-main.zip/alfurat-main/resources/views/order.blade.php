<?php

//     $no = (!isset($_POST['no']) || $_POST['no']=="" ? "1953.23" : strip_tags($_POST['no']));
$gramer = !isset($_POST['gra']) || $_POST['gra'] == '' ? '1' : strip_tags($_POST['gra']);
$nsex = !isset($_POST['nse']) || $_POST['nse'] == '' ? '0' : strip_tags($_POST['nse']);
$nsingle = !isset($_POST['nsin']) || $_POST['nsin'] == '' ? 'دينار' : strip_tags($_POST['nsin']);
$nplural = !isset($_POST['nplu']) || $_POST['nplu'] == '' ? 'دينار' : strip_tags($_POST['nplu']);
$dsex = !isset($_POST['dse']) || $_POST['dse'] == '' ? '0' : strip_tags($_POST['dse']);
$dsingle = !isset($_POST['dsin']) || $_POST['dsin'] == '' ? 'فلس' : strip_tags($_POST['dsin']);
$dplural = !isset($_POST['dplu']) || $_POST['dplu'] == '' ? 'فلس' : strip_tags($_POST['dplu']);

$shkl = [1 => 'ٌ', 'ً', 'ٍ'];
$shkl1 = [1 => 'ُ', 'َ', 'ِ'];

if (!function_exists('number_to_words')) {
    function number_to_words($number, $gramer = 1, $n_sex = 0, $n_single = 'دينار', $n_plural = 'دينار', $d_sex = 0, $d_single = 'فلس', $d_plural = 'فلس')
    {
        if (!is_numeric($number)) {
            return 'يجب كتابة رقم.';
        }

        $shkl = [1 => 'ٌ', 'ً', 'ٍ'];
        $shkl1 = [1 => 'ُ', 'َ', 'ِ'];
        $temp = explode('.', $number);
        $num = strlen($temp[0]) > 18 ? substr($temp[0], -18, 18) : $temp[0];
        $dec = !empty($temp[1]) ? (strlen($temp[1]) > 3 ? substr($temp[1], 0, 3) : $temp[1]) : '';
        $nnn = [2 => 'ألف', 'مليون', 'مليار', 'تريليون', 'كدرليون'];
        $nnn1 = [2 => 'آلاف', 'ملايين', 'مليارات', 'تريليونات', 'كدرليونات'];
        if (strlen($num) > 3) {
            $c = ceil(strlen($num) / 3);
            $mas = strlen($num) % 3 > 0 ? n2t(substr($num, 0, strlen($num) % 3), $gramer, 0, $nnn[$c], $nnn1[$c]) : '';
            $f = floor(strlen($num) / 3);
            $a = $f;
            $t = 0;
            for ($t == 0; $t < $f; $t++) {
                $newnum = substr($num, (strlen($num) % 3) + $t * 3, 3);
                $mas .= ($newnum != 0 && (strlen($num) % 3 > 0 || $t > 0) ? ' و ' : '') . n2t($newnum, $gramer, $t == $f - 1 ? $n_sex : 0, $t == $f - 1 ? $n_single : $nnn[$a], $t == $f - 1 ? $n_plural : $nnn1[$a]);
                $a--;
            }
        } else {
            $mas = n2t($num, $gramer, $n_sex, $n_single, $n_plural);
        }
        $mas = trim($mas);
        $mas = substr($num, -3, 3) == '000' ? (mb_substr($mas, -3, 3) == 'انِ' || mb_substr($mas, -3, 3) == 'ينِ' ? mb_substr($mas, 0, mb_strlen($mas) - 2) . ' ' . $n_single . 'ٍ' : (mb_substr($mas, -2, 2) == 'ًا' ? mb_substr($mas, 0, mb_strlen($mas) - 2) . 'َ ' . $n_single . 'ٍ' : (mb_substr($mas, -1, 1) == 'ٍ' ? mb_substr($mas, 0, mb_strlen($mas) - 1) . 'ِ ' . $n_single . 'ٍ' : mb_substr($mas, 0, mb_strlen($mas) - 1) . 'ُ ' . $n_single . 'ٍ'))) : $mas;
        $mas .= !empty($dec) ? (empty($num) ? '' : ' و ') . n2t(strlen($dec) == 1 ? $dec . '0' : $dec, $gramer, $d_sex, $d_single, $d_plural) : ''; //تفقيط الكسر
        $mas = str_replace(['ُُ', 'ِِ', 'ََ'], ['ُ', 'ِ', 'َ'], $mas);
        return trim($mas);
    }

    function n2t($n, $gramer = 1, $sex = 1, $single = 'درجة', $plural = 'درجات')
    {
        $shkl = [1 => 'ٌ', 'ً', 'ٍ'];
        $shkl1 = [1 => 'ُ', 'َ', 'ِ'];
        $m = (int) ($n / 100); //مئات
        $h = (int) ($n / 10) - $m * 10; //عشرات
        $a = (int) ($n - ($m * 100 + $h * 10)); //آحاد
        $two = mb_substr($single, -1, 1) == 'ة' ? mb_substr($single, 0, mb_strlen($single) - 1) . ($gramer == 1 ? 'تانِ' : 'تينٍ') : (mb_substr($single, -1, 1) == 'ى' ? mb_substr($single, 0, mb_strlen($single) - 1) . ($gramer == 1 ? 'يانِ' : 'يينِ') : (mb_substr($single, -1, 1) == 'ا' ? mb_substr($single, 0, mb_strlen($single) - 1) . ($gramer == 1 ? 'وانِ' : 'وينٍ') : $single . ($gramer == 1 ? 'انِ' : 'ينِ')));
        $m3dod = $h == 0 && $a == 2 ? $two : (($h == 1 && $a == 0) || ($h == 0 && $a > 2) ? ' ' . $plural . 'ٍ' : ($m > 0 && ($h == 0) & ($a == 0) ? ' ' . $single . 'ٍ' : (($h == 0) & ($a == 1) && $gramer != 2 ? ' ' . $single . $shkl[$gramer] : ($n == 0 ? '' : ' ' . $single . (in_array(mb_substr($single, -1, 1), ['ة', 'ء', 'ى', 'أ']) ? 'ً' : 'ًا')))));
        $n2t =
            ($m == 2 && $h == 0 && $a == 0 ? num($m, 3, $gramer, 0, 1) : num($m, 3, $gramer)) .
            ($m == 1 && ($a > 0 || $h > 0) ? $shkl[$gramer] : ($m == 1 && $a == 0 && $h == 0 ? $shkl1[$gramer] : ($m > 2 && ($a > 0 || $h > 0) ? 'ٍ' : ($m > 2 && $a == 0 && $h == 0 ? 'ِ' : '')))) .
            ($m > 0 && ($a > 0 || $h > 0) ? ' و ' : '') .
            ($a == 1 && ($h == 1) & ($sex == 0) ? 'أحدَ' : ($a == 2 && $h == 1 ? num(2, 1, $gramer, $sex, 1) : ($a == 2 && $h == 0 ? '' : ($a == 1 && $h == 0 ? '' : num($a, 1, $gramer, $sex))))) .
            ($a == 8 && $sex == 0 && $m >= 0 && $h == 0 ? $shkl1[$gramer] : ($a != 8 && $a > 2 && $m >= 0 && $h == 0 ? $shkl1[$gramer] : ($a == 8 && $m >= 0 && $h <= 1 && $sex == 1 ? 'ِي' : ($a == 8 && $sex == 1 && $h > 1 && $gramer == 2 ? 'يًا' : (($a > 2 && $sex == 1 xor $a == 1 && $sex == 0) && $h > 1 && $gramer == 2 ? 'ًا' : ($a == 8 && $sex == 1 && $h > 1 ? 'ٍ' : ((($sex == 0 && $a == 1) || $a > 2) && $h > 1 ? $shkl[$gramer] : ($a > 2 && $h == 1 ? 'َ' : '')))))))) .
            ($a > 0 && $h > 1 ? ' و ' : ' ') .
            ($a == 0 && $h == 1 && $sex == 1 ? 'عشر' . $shkl1[$gramer] : ($a == 0 && $h == 1 && $sex == 0 ? 'عشرة' . $shkl1[$gramer] : num($h, 2, $gramer, $sex))) .
            ($h == 1 && $a > 0 ? 'َ' : ($h == 1 && $a == 0 ? $shkl1[$gramer] : '')) .
            $m3dod;
        return $n2t;
    }

    // function num($n1, $t, $gr = 1, $se = 1, $mdaf = 0)
    // {
    //     global $shkl1;
    //     $wn = ($gr == 1 ? "ونَ" : "ينَ");
    //     $mia = "مائة";
    //     $nn = array(0 => array(3 => "ثلاثة", "أربعة", "خمسة", "ستة", "سبعة", "ثمانية", "تسعة"), 1 => array(3 => "ثلاث", "أربع", "خمس", "ست", "سبع", "ثمان", "تسع"));
    //     switch ($n1) {
    //         case 0 :
    //             $num = "";
    //             break;
    //         case 1 :
    //             $num = ($t == 3 ? $mia : ($t == 2 ? ($se == 1 ? "عشرة" : "عشر") : ($se == 1 ? "إحدى" : "واحد")));
    //             break;
    //         case 2 :
    //             $num = ($t == 3 ? ($gr == 1 ? ($mdaf == 0 ? "مائتانِ" : "مائتا") : ($mdaf == 0 ? "مائتينِ" : "مائتي")) : ($t == 2 ? "عشر" . $wn : ($se == 1 ? ($gr == 1 ? ($mdaf == 0 ? "اثنتانِ" : "اثنتا") : ($mdaf == 0 ? "اثنتينِ" : "اثنتي")) : ($gr == 1 ? ($mdaf == 0 ? "اثنانِ" : "اثنا") : ($mdaf == 0 ? "اثنينِ" : "اثني")))));
    //             break;
    //         default :
    //             $num = ($t == 3 ? $nn[1][$n1] . ($n1 == 8 ? "ِ" : $shkl1[$gr]) . $mia : ($t == 2 ? $nn[1][$n1] . $wn : $nn[$se][$n1]));
    //             break;
    //     }
    //     return $num;
    // }

    function num($n1, $t, $gr = 1, $se = 1, $mdaf = 0)
    {
        $shkl1 = [1 => 'ُ', 2 => 'َ', 3 => 'ِ'];
        if (!isset($shkl1[$gr])) {
            $gr = 1;
        }

        $wn = $gr == 1 ? 'ونَ' : 'ينَ';
        $mia = 'مائة';

        $nn = [
            0 => [
                1 => 'واحد',
                2 => 'اثنان',
                3 => 'ثلاثة',
                4 => 'أربعة',
                5 => 'خمسة',
                6 => 'ستة',
                7 => 'سبعة',
                8 => 'ثمانية',
                9 => 'تسعة',
            ],
            1 => [
                1 => 'واحدة',
                2 => 'اثنتان',
                3 => 'ثلاث',
                4 => 'أربع',
                5 => 'خمس',
                6 => 'ست',
                7 => 'سبع',
                8 => 'ثمان',
                9 => 'تسع',
            ],
        ];

        switch ($n1) {
            case 0:
                $num = '';
                break;
            case 1:
                $num = $t == 3 ? $mia : ($t == 2 ? ($se == 1 ? 'عشرة' : 'عشر') : ($se == 1 ? 'إحدى' : 'واحد'));
                break;
            case 2:
                $num = $t == 3 ? ($gr == 1 ? ($mdaf == 0 ? 'مائتانِ' : 'مائتا') : ($mdaf == 0 ? 'مائتينِ' : 'مائتي')) : ($t == 2 ? 'عشر' . $wn : ($se == 1 ? ($gr == 1 ? ($mdaf == 0 ? 'اثنتانِ' : 'اثنتا') : ($mdaf == 0 ? 'اثنتينِ' : 'اثنتي')) : ($gr == 1 ? ($mdaf == 0 ? 'اثنانِ' : 'اثنا') : ($mdaf == 0 ? 'اثنينِ' : 'اثني'))));
                break;
            default:
                $num = $t == 3 ? $nn[1][$n1] . ($n1 == 8 ? 'ِ' : $shkl1[$gr]) . $mia : ($t == 2 ? $nn[1][$n1] . $wn : $nn[$se][$n1]);
                break;
        }

        return $num;
    }
}
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">

<head>
    <meta charset="UTF-8">
    <style>
        @import url(https://fonts.googleapis.com/css?family=Roboto:100,300,400,900,700,500,300,100);

        * {
            margin: 0;
            box-sizing: border-box;

        }

        body {
            background: #E0E0E0;
            font-family: 'Roboto', sans-serif;
            background-image: url('');
            background-repeat: repeat-y;
            background-size: 100%;
        }

        ::selection {
            background: #f31544;
            color: #FFF;
        }

        ::moz-selection {
            background: #f31544;
            color: #FFF;
        }

        h1 {
            font-size: 1.5em;
            color: #222;
        }

        h2 {
            font-size: 14px;
        }

        h3 {
            font-size: 14px;
            font-weight: 300;
            line-height: 2em;
        }

        p {
            font-size: .7em;
            color: #666;
            line-height: 1.2em;
        }

        #invoiceholder {
            width: 100%;
            hieght: 100%;
            padding-top: 0px;
        }

        #headerimage {
            z-index: -1;
            position: relative;
            top: -50px;
            height: 350px;

            /* -webkit-box-shadow:inset 0 2px 4px rgba(0,0,0,.15), inset 0 -2px 4px rgba(0,0,0,.15);
 -moz-box-shadow:inset 0 2px 4px rgba(0,0,0,.15), inset 0 -2px 4px rgba(0,0,0,.15);
 box-shadow:inset 0 2px 4px rgba(0,0,0,.15), inset 0 -2px 4px rgba(0,0,0,.15); */
            overflow: hidden;
            background-attachment: fixed;
            background-size: 1920px 80%;
            background-position: 50% -90%;
        }

        #invoice {
            position: relative;
            top: -350px;
            margin: 0 auto;
            width: 700px;
            background: #FFF;
        }

        [id*='invoice-'] {
            /* Targets all id with 'col-' */
            border-bottom: 1px solid #EEE;
            padding: 5px;
        }

        #invoice-top {
            min-height: 120px;
            display: flex;
            justify-content: space-between;
            column-gap: 60px;
            margin-top: -40px
        }

        #invoice-mid {
            min-height: 120px;
        }

        #invoice-bot {
            min-height: 250px;
        }

        #invoice-info {
            display: flex;
            justify-content: space-between;
        }

        .logo {
            float: left;
            height: 100px;
            width: 150px;
            /* background: url(http://michaeltruong.ca/images/logo1.png) no-repeat; */
            background-size: 60px 60px;
        }

        .qr {
            float: right;
            height: 120px;
            width: 120px;
            /* background: url(http://michaeltruong.ca/images/logo1.png) no-repeat; */
            background-size: 60px 60px;
        }

        .clientlogo {
            float: left;
            height: 60px;
            width: 60px;
            /* background: url(http://michaeltruong.ca/images/client.jpg) no-repeat; */
            background-size: 60px 60px;
            border-radius: 50px;
        }

        .info {
            display: block;
            float: left;
            margin-left: 20px;
        }

        .title {
            text-align: center;
            float: right;
        }

        .title p {
            text-align: right;
        }

        #project {
            margin-left: 52%;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        td {
            padding: 5px 0 5px 15px;
            border: 1px solid #EEE;
            font-size: 14px
        }

        .service td {
    border: 1px solid #000;
    padding: 2px
  }
        .tabletitle {
            padding: 5px;
            background: #EEE;
            border: #000 1px solid !important;
        }
        .tabletitle td {
            text-align: center;
            border: #000 1px solid !important;
        }

        .service {
            border: 1px solid #EEE;
        }

        .item {
            width: 50%;
        }

        .itemtext {
            font-size: .9em;
        }

        #legalcopy {
            margin-top: 30px;
        }

        form {
            float: right;
            margin-top: 30px;
            text-align: right;
        }


        .effect2 {
            position: relative;
        }

        .effect2:before,
        .effect2:after {
            z-index: -1;
            position: absolute;
            content: "";
            bottom: 15px;
            left: 10px;
            width: 50%;
            top: 80%;
            max-width: 300px;
            background: #777;
            -webkit-box-shadow: 0 15px 10px #777;
            -moz-box-shadow: 0 15px 10px #777;
            box-shadow: 0 15px 10px #777;
            -webkit-transform: rotate(-3deg);
            -moz-transform: rotate(-3deg);
            -o-transform: rotate(-3deg);
            -ms-transform: rotate(-3deg);
            transform: rotate(-3deg);
        }

        .effect2:after {
            -webkit-transform: rotate(3deg);
            -moz-transform: rotate(3deg);
            -o-transform: rotate(3deg);
            -ms-transform: rotate(3deg);
            transform: rotate(3deg);
            right: 10px;
            left: auto;
        }

        .column {
            display: flex;
            flex-direction: row;
            gap: 10px;
        }

        .box {
            width: 150px;
            justify-content: center;
            text-align: center;
            align-items: center;
            font-weight: bold;
            border-radius: 8px;
            align-self: center;
            height: 100%;
            /* border: 1px solid #000; */
        }

        .box-info {
            width: 150px;
            justify-content: center;
            text-align: right;
            align-items: center;
            font-weight: bold;
            border-radius: 3px;
            align-self: center;
            height: 100%;
            border: 1px solid #000;
            padding: 2px;
        }
    </style>
    <div id="invoiceholder">
        <div id="headerimage"></div>
        <div id="invoice" class="effect2">
            <div style="text-align: center;width:100%">
                <h1>تطبيق دينار للتجارة العامة</h2>
            </div>
            <div id="invoice-top">

                <div class="column">
                    <div class="box">
                        <img style="width:120px;" src="{{ asset('img/combined_qr.png') }}">

                        <h6>{{ date('h:i a', strtotime($order->order_date)) }}</h6>
                        <h6>#{{ str_pad($order->id, 9, '0', STR_PAD_LEFT) }}</h6>
                    </div><!--End Title-->
                </div>
                <div class="column">

                    <div class="box" style="display: inline-grid;align-self:flex-end">
                        <img style="width:150px;" src="{{ asset('img/logo.jpg') }}">
                        <h6 style="margin-buttom: 0">{{ date('d-m-Y', strtotime($order->order_date)) }}</h6>
                        <h6 style="margin-buttom: 0">طريقة الدفع: {{ $order->payment_method }} </h6>
                    </div>

                </div><!--End InvoiceTop-->
            </div>
            <hr style="width: 100%">
            <div id="invoice-info">

                <div class="column" style="gap:30px">
                    <div class="box-info">
                        <h6>العميل: {{ $order->user->store->owner_name }}</h6>
                        <h6>المتجر: {{ $order->user->store->store_name }}</h6>
                    </div>
                    <div class="box-info">
                        <h6>المحافظة: {{ $order->user->store->district }}</h6>
                        <h6>العنوان: {{ $order->user->store->address }}</h6>
                    </div>
                    <div class="box-info">
                        <h6>المستخدم: {{ auth()->user()->name }}</h6>
                        <h6>المندوب: {{ $order->agent_id ? $order->agent->name : 'لم يتم تحديد سائق' }}</h6>
                    </div>
                    <div class="box-info">
                        <h6>رقم الهاتف: {{ $order->user->store->phone }}</h6>
                    </div>
                    
                </div>


            </div>

            <div id="invoice-bot">

                <div id="table">
                    <table>
                        <tr class="tabletitle">
                            <td class="">
                                <h5>الرقم</h5>
                            </td>

                            <td class="item">
                                <h5>اسم المادة</h5>
                            </td>
                            <td class="">
                                <h5>الوحدة</h5>
                            </td>

                            <td class="Hours">
                                <h5>الكمية</h5>
                            </td>
                            <td class="Rate">
                                <h5>سعر الوحدة</h5>
                            </td>
                            <td class="subtotal">
                                <h5>المبلغ النهائي</h5>
                            </td>
                        </tr>

                        @php
                            $total = 0;
                            $total_qty = 0;
                        @endphp
                        @foreach ($order->order_details as $product)
                            <tr class="service">
                                <td>
                                    <h5>{{ $product->product_id }}</h5>
                                </td>
                                <td>
                                    <h5>{{ $product->products->product_name }}</h5>
                                </td>
                                <td>
                                    <h5>{{ $product->units->unit_name }}</h5>
                                </td>
                                <td>
                                    <h5>{{ number_format($product->qty) }}</h5>
                                </td>
                                <td>
                                    <h5>{{ number_format($product->price) }}</h5>
                                </td>
                                <td>
                                    <h5>{{ number_format($product->price * $product->qty) }}</h5>
                                </td>
                                @php
                                    $total += $product->price * $product->qty;
                                    $total_qty += $product->qty;
                                @endphp
                            </tr>
                        @endforeach
                        <tr>
                            <td colspan="5" class="Rate">
                                <h4>المجموع</h4>
                            </td>
                            <td class="payment">
                                <h4>{{ number_format($total) }}</h4>
                            </td>
                        </tr>
                        <tr>
                            <td colspan="5">
                                <h4>التوصيل</h4>
                            </td>
                            <td>
                                <h4>{{ number_format($order->delivery_fees) }}</h4>
                            </td>
                        </tr>
                        <tr>
                            <td colspan="5">
                                <h4>التخفيض<h4>
                            </td>
                            <td>
                                <h4>{{ number_format($order->discount) }}</h4>
                            </td>
                        </tr>
                        <tr>
                            <td colspan="5">المجموع الكلي</td>
                            <td>
                                <h4>{{ number_format($order->delivery_fees + $total + $order->tax - $order->discount) }}</h4>
                            </td>
                        </tr>
                        <tr>
                            <td colspan="6">فقط
                                {{ number_to_words($order->delivery_fees + $total + $order->tax - $order->discount) }}</td>
                        </tr>
                        <tr>
                            <td colspan="5">الملاحظات</td>
                            <td>
                                <h4>{{ $order->notes ?? '' }}</h4>
                            </td>
                        </tr>
                        </tbody>




                    </table>
                </div><!--End Table-->




                <div id="legalcopy">
                    <table>
                        <tr>
                            <td>اجمالي العدد {{ $total_qty }} </td>
                            <td>الشركة غير مسؤولة عن أي نقص او تلف في البضاعة بعد استلامها من قبل الزبون</td>
                        </tr>

                    </table>

                </div>

            </div><!--End InvoiceBot-->
        </div><!--End Invoice-->
    </div><!-- End Invoice Holder-->
