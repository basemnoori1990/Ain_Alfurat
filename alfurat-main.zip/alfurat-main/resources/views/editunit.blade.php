@include('layouts.header')
@include('layouts.nav', [
    'breadcrumbs' => [
        ['title' => 'الوحدات',
        'route' => route("units.index"),
        'icon' => 'icon-compass',],
        ['title' => 'تعديل',
        'route' => '',
        'icon' => '',],
    ],
])
<div class="container-fluid">

            <div class="animated fadeIn">
                <div class="row">
                    <div class='col-lg-6'>
                        <form method="POST" action="{{route('units.update',$unit->id)}}">
                            @csrf
                            @method('PUT')   
                            <div class="form-group">
                                <label for="unit_name">اسم الوحدة</label>
                            <input value="{{$unit->unit_name}}" class="form-control" name='unit_name' >
                            </div>
                            <div class="form-group">
                                <label for="eq">القيمة  المقابلة</label>
                            <input value="{{$unit->eq}}" class="form-control" type="number" step="0.0001" name='eq' >
                            </div>
                            <div class="form-group">
                                <label for="unit_name">مجموعة الوحدات</label>
                                <select class="select form-control" name="unit_group_id">
                                    @foreach($unitgroups as $unitgroup)
                                    <option 
                                    @if($unitgroup->id==$unit->unit_group_id)
                                    selected
                                    @endif
                                    value="{{$unitgroup->id}}">{{$unitgroup->unit_group_name}}</option>
                                    @endforeach
                                </select>                            
                            </div>
        <input type="submit" class="btn btn-success" value="حفظ">
                        </form>
                    </div>
                </div>
                <!--/row-->
            </div>

        </div>
        @include('layouts.footer')
        </html>