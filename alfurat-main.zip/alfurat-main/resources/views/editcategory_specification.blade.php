@include('layouts.header')
@include('layouts.nav', [
    'breadcrumbs' => [
        ['title' => 'خواص المنتجات',
        'route' => route("categoryspecifications.index"),
        'icon' => 'icon-cursor',],
        
        ['title' => 'تعديل',
        'route' => '',
        'icon' => '',]
    ],
])
<div class="container-fluid">
            <div class="animated fadeIn">
                <div class="row">
                    <div class='col-lg-6'>
                        <form method="POST" enctype="multipart/form-data" action="{{route('categoryspecifications.update',$specification->id)}}">
                            @csrf   
                            @method('PUT')
                            <div class="form-group">
                                <label for="specification_name">الخاصية</label>
                            <input class="form-control" value="{{$specification->specification_name}}" name='specification_name' >
                            </div>
                            <div class="form-group">
                                <label for="description">الوصف</label>
                            <input class="form-control" value="{{$specification->description}}" name='description' >
                            </div>
                            <input type="submit" class="btn btn-success" value="حفظ">
                        </form>
                    </div>
                </div>
                <!--/row-->
            </div>
        </div>
        
    @include('layouts.footer')
    </html>