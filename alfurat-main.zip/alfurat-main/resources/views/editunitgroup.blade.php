@include('layouts.header')
@include('layouts.nav', [
    'breadcrumbs' => [
        ['title' => 'مجموعات الوحدات',
        'route' => route("unitgroups.index"),
        'icon' => 'icon-drawer',],
        ['title' => 'تعديل',
        'route' => '',
        'icon' => '',],
    ],
])
        <div class="container-fluid">

            <div class="animated fadeIn">
                <div class="row">
                    <div class='col-lg-6'>
                        <form method="POST" action="{{route('unitgroups.update',$unitgroup->id)}}">
                            @csrf   
                            @method('PUT')
                            <div class="form-group">
                                <label for="unit_group_name">اسم مجموعة الوحدات</label>
                            <input class="form-control" value="{{$unitgroup->unit_group_name}}" name='unit_group_name' >
                            </div>
                            <div class="form-group">
                                <label for="description">الوصف</label>
                            <input value="{{$unitgroup->description}}" class="form-control"  name='description' >
                            </div>
                            <input type="submit" class="btn btn-success" value="حفظ">
                        </form>
                    </div>
                </div>
                <!--/row-->
            </div>
        </div>
        @include('layouts.footer')
        </html>