@include('layouts.header')
@include('layouts.nav', [
    'breadcrumbs' => [['title' => 'الطلبات', 'route' => route('web.orders.index'), 'icon' => 'icon-chart']],
])
<div class="container-fluid">

    <div class="animated fadeIn">
        <div class="row">
            <div class="col-lg-12">
                <div class="row">
                    <div class="col-md-4">
                        <a href="{{ route('weborders.get_archive') }}" class="btn btn-info">الأرشيف</a>

                    </div>
                </div>
                <table class="table table-responsive table-striped">
                    <thead>
                        <tr class="bg-navy disabled ">
                            <th class="text-center"></th>
                            <th class="text-center">الرقم</th>
                            <th class="text-center">المستخدم</th>
                            <th class="text-center">العنوان</th>
                            <th class="text-center" width="20%">المندوب</th>
                            <th class="text-center">الموقع الجغرافي</th>
                            <th class="text-center">تاريخ الطلب</th>
                            <th class="text-center">قيمة الطلب</th>
                            <th class="text-center">الضريبة</th>
                            <th class="text-center">التوصيل</th>
                            <th class="text-center">التخفيض</th>
                            <th class="text-center">المجموع</th>
                            <th class="text-center" width="20%">الحالة</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                                    
                                $i = 1;
                                
                                foreach($orders as $order)
                            {
                                ?>
                        <tr>
                            <td class="text-center"><a href="" class="btn btn-info btn-icon control-buttons"
                                    title="Edit "><i class="fa fa-pencil-square-o fa-pencil"></i></span>
                                    <span id="delete" data-id="{{ $order->id }}" data-model="weborders"
                                        class="btn btn-danger btn-icon control-buttons delete" title="Delete"><i
                                            class="fa fa-trash-o"></i></span>
                                    <a href="#"
                                        onclick="window.open('{{ route('orders.print_order', $order->id) }}','طباعة الطلب','height=600,width=400')"
                                        id="delete" data-id="{{ $order->id }}"
                                        class="btn btn-primary btn-icon control-buttons" title="Print"><i
                                            class="fa fa-print"></i></a>
                            </td>
                            <td class="text-center">
                                {{ $order->id }}
                            </td>
                            <td class="text-center">
                                {{ isset($order->user->store->owner_name) ? $order->user->store->owner_name : '' }}<br>
                                {{ isset($order->user->store->store_name) ? $order->user->store->store_name : '' }}
                            </td>
                            <td class="text-center">
                                {{ $order->address }}
                            </td>
                            <td class="text-center">
                                <select class="select form-control agent" data-id="{{ $order->id }}"
                                    data-agent_id="{{ $order->agent_id }}">
                                    <option value="-1">لم يتم التعيين</option>
                                    @foreach ($agents as $agent)
                                        <option value="{{ $agent->id }}"
                                            @if ($order->agent_id == $agent->id) selected @endif>{{ $agent->name }}

                                        </option>
                                    @endforeach
                                </select>
                            </td>
                            <td class="text-center">
                                <a href="{{ $order->location }}" target="_blank"><span
                                        style="color:black !important">الموقع الجغرافي</span></a>
                            </td>
                            <td class="text-center">{{ $order->order_date }}</td>
                            <td class="text-center">{{ number_format($order->sub_total) }}</td>
                            <td class="text-center">{{ number_format($order->tax) }}</td>
                            <td class="text-center">{{ number_format($order->delivery_fees) }}</td>
                            <td class="text-center">{{ number_format($order->discount) }}</td>
                            <td class="text-center">{{ number_format($order->total) }}</td>
                            <td class="text-center">
                                <select class="select form-control order_status" data-id="{{ $order->id }}">
                                    @foreach ($statuses as $status)
                                        <option value="{{ $status['id'] }}"
                                            @if ($order->status == $status['id']) selected @endif>
                                            {{ $status['status_name'] }}</option>
                                    @endforeach
                                </select>
                            </td>
                        </tr>
                        <?php
                                }
                                ?>
                    </tbody>
                </table>
            </div>
            <!--/row-->
        </div>
    </div>
    <div id="dialog-confirm" title="تنبيه">
        <p><span class="ui-icon ui-icon-alert" style="float:left; margin:12px 12px 20px 0;"></span>هل تود تعيين هذا
            المندوب</p>
    </div>
    @include('layouts.footer')
    <script>
        $(function() {
            $('.agent').select2({
                allowClear: true,
                placeholder: "لم يتم التعيين",
            });
            $('.agent').on('select2:select', function(e) {
                var id = $(this).data('id');
                var agent_id = $(this).val();
                $("#dialog-confirm").dialog({
                    resizable: false,
                    height: "auto",
                    width: 400,
                    modal: true,
                    buttons: {
                        "نعم": function() {
                            confirmed()

                            $.ajax({
                                url: "{{ route('orders.change_agent') }}",
                                type: "POST",
                                data: {
                                    id: id,
                                    agent_id: agent_id,
                                    _token: "{{ csrf_token() }}"
                                },
                                success: function(data) {
                                    alert('تم التعيين')
                                }
                            });
                        },
                        "لا": function() {
                            $(this).dialog("close");
                        }
                    }
                });

            })
        })

        function confirmed() {
            $('#dialog-confirm').dialog('close')
        }
    </script>
