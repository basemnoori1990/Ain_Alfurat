@include('layouts.header')
@include('layouts.nav', [
    'breadcrumbs' => [
        ['title' => 'المجموعات',
        'route' => route("web.categories.index"),
        'icon' => 'icon-organization',],
    ],
])
        <div class="container-fluid">

            <div class="animated fadeIn">
                <div class="row">
                    <div class='col-lg-6'>
                        <form method="POST" enctype="multipart/form-data" action="{{route('web.categories.store')}}">
                            @csrf   
                            <div class="form-group">
                                <label for="category_name">اسم المجموعة</label>
                            <input class="form-control" name='category_name' >
                            </div>
                            <div class="form-group">
                                <label for="description">الوصف</label>
                            <input class="form-control" name='description' >
                            </div>
                            <div class="form-group">
                                <label for="image">الصورة</label>
                            <input type="file" class="form-control" name='image' >
                            </div>
                            <div class="form-group">
                                <label for="main_category_id">المجموعة الرئيسية</label>
                                <select class="select  form-control" name="main_category_id" id="main_category_id">
                                    <option value="-1">لا يوجد</option>
                                    @foreach($main_categories as $category)    
                                    <option value="{{$category->id}}">{{$category->category_name}}</option>
                                    @endforeach
                                </select>                       
                            </div>
                            <div class="form-group">
                                <label for="category_specification_id">خواص المنتجات</label>
                                <select class="select  form-control" name="category_specification_id" >
                                    <option value="-1">لا يوجد</option>
                                    @foreach($specifications as $spec)
                                    <option value="{{$spec->id}}">{{$spec->specification_name}}</option>
                                    @endforeach
                                </select>                       
                            </div>
                            <input type="submit" class="btn btn-success" value="حفظ">
                            <a href="{{ route('categories.get_archive') }}" class="btn btn-info">الأرشيف</a>
                        </form>
                    </div>
                    <div class="col-lg-6">
                        <table class="table table-responsive table-striped">
                            <thead>
                                <tr class="bg-navy disabled ">
                                    <th class="text-center">تحكم</th>
                                    <th class="text-center">الرقم</th>
                                    <th class="text-center">الاسم</th>
                                    <th class="text-center">الوصف</th>
                                    <th class="text-center">الصورة</th>
                                    <th class="text-center">تندرج تحت</th>
                                    <th class="text-center">الخاصية</th>
                                    <th class="text-center">الحالة</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php 
                                    
                                $i = 1;
                                
                                foreach($categories as $category)
                            {
                                ?>
                                <tr>
                                    <td class="text-center control">
                                        <a href="{{route('categories.edit',$category->id)}}" class="btn btn-info btn-icon control-buttons" title="Edit "><i class="fa fa-pencil-square-o fa-pencil"></i></a>
                                        <span id="delete" data-id="{{$category->id}}" data-model="categories" class="btn btn-danger btn-icon control-buttons delete" title="Delete"><i class="fa fa-trash-o"></i></span>
                                    </td>   
                                    <td class="text-center">{{$category->id}}</td>
                                    <td class="text-center">{{$category->category_name}}</td>
                                    <td class="text-center">{{$category->description}}</td>
                                    <td class="text-center">
                                        <img src="
                                        {{ asset('storage/' . $category->image)}}
                                        "
                                        style="width:50px">
                                    </td>
                                    <td class="text-center">
                                        @if($category->parent!=null)
                                        {{'('.$category->parent_id.') - '.$category->parent->category_name}}
                                        @endif
                                    </td>
                                    <td class="text-center">
                                        @if($category->category_specification!=null)
                                        {{$category->category_specification->specification_name}}
                                        @endif
                                    </td>
                                    
                                    <td class="text-center"> 
                                        <label class="switch switch-text switch-info">
                                        <input type="checkbox" class="switch-input status" data-type="category" data-id="{{$category->id}}"
                                        @if ($category->status==1)
                                        checked
                                        @endif
                                        >
                                        <span class="switch-label" data-on="مفعل" data-off="معطل"></span>
                                        <span class="switch-handle"></span>
                                    </label>
                                </td>
                                </tr>  
                                <?php
                                }
                                ?>
                            </tbody>
                        </table>
                    </div>
                </div>
                <!--/row-->
            </div>
        </div>
        @include('layouts.footer')
        <script>
            $(function(){
            $('#main_category_id').select2();
        $('#sub_category_id').select2();

        $('#main_category_id').change(function() {
    var main_category_id = $(this).val();
    var sub_category_id = $('#sub_category_id');

    // Clear existing options in the second select
    sub_category_id.empty().trigger('change');

    if (main_category_id) {
        // Make an AJAX request to fetch the options
        $.ajax({
            url: "{{ route('categories.get_sub_categories') }}", // URL to the server-side script that returns the options
            type: 'post',
            data: { _token: "{{ csrf_token() }}",id:$("#main_category_id").val() },
            success: function(response) {
                // Populate the second select with the response data
                var newOptions = $.map(response, function(option) {
                    // console.log(option[0]);
                    return {
                        id: option[0].id,
                        text: option[0].category_name
                    };
                });

                sub_category_id.empty().select2({
data: newOptions
})
            },
            error: function(xhr, status, error) {
                console.error('AJAX Error: ' + status + error);
            }
        });
    }
});
            })
        </script>
        </html>