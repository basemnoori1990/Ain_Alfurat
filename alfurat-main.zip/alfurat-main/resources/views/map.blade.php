<script src="{{ asset('js/libs/jquery.min.js') }}"></script>

<script src="https://code.jquery.com/ui/1.14.0/jquery-ui.js"></script>
<!-- jQuery -->
 
<script src='https://api.mapbox.com/mapbox-gl-js/v1.4.1/mapbox-gl.js'></script>
<link href='https://api.mapbox.com/mapbox-gl-js/v1.4.1/mapbox-gl.css' rel='stylesheet' />

<div id='map' style='height: 500px;' class="col-md-12"></div>
<span id="info">

</span>
<script>
mapboxgl.accessToken = 'pk.eyJ1IjoibXVzdGFmYWlicmFoaW0iLCJhIjoiY2sxeHV3MjhnMGYwcjNlcXRnc2phbnllcCJ9.FtUFiPwZdJ7o_sh9vXHx2g';
mapboxgl.setRTLTextPlugin('https://api.mapbox.com/mapbox-gl-js/plugins/mapbox-gl-rtl-text/v0.2.3/mapbox-gl-rtl-text.js');
var map = new mapboxgl.Map({
container: 'map',
style: 'mapbox://styles/mapbox/streets-v11',
zoom: 15,
center: [42.92394960,33.55460410],


});
map.addControl(new mapboxgl.NavigationControl());
map.addControl(new mapboxgl.FullscreenControl());

map.on('click', function (e) {

document.getElementById('info').innerHTML =
// e.point is the x, y coordinates of the mousemove event relative
// to the top-left corner of the map
JSON.stringify(e.point) + '<br />' +
// e.lngLat is the longitude, latitude geographical position of the event
JSON.stringify(e.lngLat.wrap());
if (!($('.mapboxgl-marker')[0]))
{
var el = document.createElement('div');
el.className = 'marker';
el.style.backgroundImage = 'url(\'img/mark.png\')';
el.style.width = '60px';
el.style.height = '60px';

var marker = new mapboxgl.Marker({
draggable: true
})
.setLngLat(e.lngLat.wrap())
.addTo(map);

localStorage.setItem('lng', e.lngLat.lng);
localStorage.setItem('lat', e.lngLat.lat);
}
function onDragEnd() {
var lngLat = marker.getLngLat();
//coordinates.style.display = 'block';
//coordinates.innerHTML = 'Longitude: ' + lngLat.lng + '<br />Latitude: ' + lngLat.lat;
localStorage.setItem('lng', lngLat.lng);
localStorage.setItem('lat', lngLat.lat);
}
 
marker.on('dragend', onDragEnd);
// add marker to map
});
</script>