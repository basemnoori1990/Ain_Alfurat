@include('layouts.header')
@include('layouts.nav', [
    'breadcrumbs' => [
        ['title' => 'الإعلانات',
        'route' => route("web.ads.index"),
        'icon' => 'icon-screen-desktop',]
    ],
])

<div class="container-fluid">

    <div class="animated fadeIn">
        <div class="row">
            <div class='col-lg-6'>
                <form method="POST" enctype="multipart/form-data" action="{{ route('web.ads.store') }}">
                    @csrf
                    <div class="form-group">
                        <label for="title">العنوان</label>
                        <input required class="form-control" required name='title'>
                    </div>
                    <div class="form-group">
                        <label for="description">الوصف</label>
                        <input required class="form-control" name='description'>
                    </div>
                    <div class="form-group">
                        <label for="product_id">المنتج</label><br>
                        <select class="select form-control" id="product_id" name="product_id">
                            <option value="">اختر المنتج</option>
                            @foreach ($products as $product)
                                <option value="{{ $product->id }}">{{ $product->product_name }}</option>
                            @endforeach
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="image">الصورة</label>
                        <input required type="file" class="form-control" name='image'>
                    </div>
                    <div class="form-group">
                        <label for="ad_type">نوع الاعلان</label>
                        <input required class="form-control" name='ad_type'>
                    </div>
                    <div class="form-group">
                        <label for="expiration_time">تاريخ الانتهاء</label>
                        <input required type="date" class="form-control" name='expiration_time'>
                    </div>
                    <input type="submit" class="btn btn-success" value="حفظ">
                    <a href="{{ route('ads.get_archive') }}" class="btn btn-info">الأرشيف</a>
                </form>
            </div>
            <div class="col-lg-6">
                <table class="table table-responsive table-striped">
                    <thead>
                        <tr class="bg-navy disabled ">
                            <th class="text-center">تحكم</th>
                            <th class="text-center">الرقم</th>
                            <th class="text-center">العنوان</th>
                            <th class="text-center">الوصف</th>
                            <th class="text-center">المنتج</th>
                            <th class="text-center">الصورة</th>
                            <th class="text-center">نوع الاعلان</th>
                            <th class="text-center">تاريخ الانتهاء</th>
                            <th class="text-center">تاريخ الحذف</th>
                            <th class="text-center">الحالة</th>
                        </tr>
                    </thead>'
                    <tbody>
                        <?php 
                                    
                                $i = 1;
                                
                                foreach($ads as $ad)
                            {
                                ?>
                        <tr>
                            <td class="text-center control">
                                @if ($ad->deleted_at == null)
                                    <a href="{{ route('ads.edit', $ad->id) }}"
                                        class="btn btn-info btn-icon control-buttons" title="Edit "><i
                                            class="fa fa-pencil-square-o fa-pencil"></i></a>
                                @endif
                                <span id="delete" data-id="{{ $ad->id }}" data-model="ads"
                                    class="btn btn-danger btn-icon control-buttons delete" title="Delete"><i
                                        class="fa fa-trash-o"></i></span>
                            </td>
                            <td class="text-center">{{ $ad->id }}</td>
                            <td class="text-center">{{ $ad->title }}</td>
                            <td class="text-center">{{ $ad->description }}</td>
                            <td class="text-center">{{ isset($ad->product) ? $ad->product->product_name : '' }}</td>
                            <td class="text-center">
                                <img src="
                                        {{ asset('storage/' . $ad->image) }}
                                        "
                                    style="width:50px">
                            </td>
                            <td class="text-center">{{ $ad->ad_type }}</td>
                            <td class="text-center">{{ date('Y-m-d', strtotime($ad->expiration_time)) }}</td>
                            <td class="text-center">
                                {{ isset($ad->deleted_at) ? date('Y-m-d', strtotime($ad->deleted_at)) : '' }}</td>
                            <td class="text-center">
                                <label class="switch switch-text switch-info">
                                    <input type="checkbox" class="switch-input status" data-type="ads"
                                        data-id="{{ $ad->id }}" @if ($ad->status == 1) checked @endif>
                                    <span class="switch-label" data-on="مفعل" data-off="معطل"></span>
                                    <span class="switch-handle"></span>
                            </td>
                        </tr>
                        <?php
                                }
                                ?>
                    </tbody>
                </table>
            </div>
        </div>
        <!--/row-->
    </div>

</div>
@include('layouts.footer')
<script>
    $(function() {
        $('#product_id').select2({
            placeholder: "اختر المنتج",
            allowClear: true,
        })
    })
</script>

</html>
