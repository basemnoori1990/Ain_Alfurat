<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <style>
        body {
            font-family: 'dejavusans', sans-serif;
            direction: rtl;
            text-align: right;
        }
        .container {
    display: flex;
    justify-content: space-between;
    margin-top: 50px;
}

.box {
    width: 200px;
    height: 50px;
    padding: 10px;
    margin: 0 20px;
    text-align: center;
}
.box-center {
    text-align: center;
    width: 200px;
    height: 50px;
    padding: 10px;
    font-size: 20px;
    margin: 0 20px;
    text-align: center;
}
img {
    width: 200px;
}
        table {
            width: 100%;
            border-collapse: collapse;
        }
        th, td {
            /* border: 1px solid black; */
            padding: 10px;
        }
        .header, .footer {
            text-align: center;
        }
        .details {
            text-align: center;
            margin: 50px 0 0 0;
        }
        @font-face {
  font-family: 'Code39';
  src: url('{{ asset('fonts/Code39r.ttf') }}') format('truetype');
}
        .barcode {
  font-family: 'Code39';
  font-size: 40px; /* Adjust size as needed */
}
    </style>
</head>
<body>
    <div class="container">
        <div class="box"><div class="barcode">{{ str_pad($order->id, 9, '0', STR_PAD_LEFT)}}</div>
        <div class="barcode-number">
            {{ str_pad($order->id, 9, '0', STR_PAD_LEFT) }}
        </div></div>
        <div class="box-center">
            
            تطبيق دينار للتجارة العامة
                </div>
        <div class="box"><img src="{{ asset('img/logo.jpg') }}" alt="logo"></div>
        
    </div>
    <div class="details">
        المتجر: 
        {{ $order->user->store->store_name}}
        المحافظة: 
        {{ $order->user->store->district}}
        تاريخ الفاتورة: 
        {{ $order->order_date }}
        
        اسم الزبون:
         {{ $order->user->store->owner_name}} | 
          رقم الفاتورة:
            {{ $order->id }}
        العنوان:  
        {{ $order->user->store->address}}
        الهاتف: 
         {{ $order->user->store->phone}}
         اسم المستخدم:
         {{ auth()->user()->name }}
         السائق
         {{ $order->agent_id ? $order->agent->name: 'لم يتم تحديد سائق' }}          
      
            
    </div>
    <h3>تفاصيل الطلب</h3>
<table>
        <thead>
            <tr>
                <th>رقم المنتج</th>
                <th>المنتج</th>
                <th>الوحدة</th>
                <th>الكمية</th>
                <th>السعر</th>
                <th>المجموع</th>
            </tr>
        </thead>
        <tbody>
            @php
                $total = 0;
                $total_qty = 0;
            @endphp
            @foreach($order->order_details as $product)
            <tr>
                <td>{{ $product->product_id }}</td>
                <td>{{ $product->products->product_name }}</td>
                <td>{{ $product->units->unit_name }}</td>
                <td>{{ number_format($product->qty) }}</td>
                <td>{{ number_format($product->price) }}</td>
                <td>{{ number_format($product->price * $product->qty) }}</td>
                @php
                 $total += $product->price * $product->qty;
                 $total_qty += $product->qty;   
                @endphp
            </tr>
            @endforeach
            <tr>
                <td colspan="5">المجموع</td>
                <td>{{ number_format($total) }}</td>
            </tr>
            <tr>
                <td colspan="5">التوصيل</td>
                <td>{{ number_format($order->delivery_fees) }}</td>
            </tr>
            {{-- <tr> --}}
                {{-- <td colspan="5">الضريبة</td> --}}
                {{-- <td>{{ number_format($order->tax) }}</td> --}}
            {{-- </tr> --}}
            <tr>
                <td colspan="5">التخفيض</td>
                <td>{{ number_format($order->discount) }}</td>
            </tr>
            <tr>
                <td colspan="5">المجموع الكلي</td>
                <td>{{ number_format($order->delivery_fees+$total+$order->tax-$order->discount) }}</td>
            </tr>
        </tbody>
    </table>
    <div class="footer">
        <p>اجمال المطلوب : {{ number_format($order->delivery_fees+$total+$order->tax-$order->discount) }}</p>
       حالة الدفع: {{$order->payment_method}} | اجمالي العدد : {{ $total_qty }} 
    </div>
</body>
</html>

