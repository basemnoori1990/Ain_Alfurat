<?php

namespace App\Notifications;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Notifications\Messages\MailMessage;
use Illuminate\Notifications\Notification;
use Kawankoding\Fcm\FcmMessage;

class UserNotification extends Notification implements ShouldQueue
{
    use Queueable;

    // take params according to your requiremnt.
    public function __construct(
        public ?string $title = null,
        public ?string $body = null,
        public $data = null,
    ) {
    }

    public function via()
    {
        return ['fcm'];
    }

    // optional: you can use according to your requirement.
    public function toFCM()
    {
        return [
            'title' => $this->title,
            'body' => $this->body,
        ];
    }

    // optional: you can use according to your requirement.
    public function toAPS()
    {
        return [
            //
        ];
    }
    
    // optional: you can use according to your requirement.
    public function toAndroid()
    {
        return [
            //
        ];
    }

    // optional: you can use according to your requirement.
    public function toWeb()
    {
        return [
            //
        ];
    }

    // optional: you can use according to your requirement.
    public function toData() {
        return $this->data;
    }
}
