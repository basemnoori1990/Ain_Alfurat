<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\CategorySpecification;

class Category_specificationsController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
    $specifications = CategorySpecification::all();
   
    return view('category_specifications' ,['specifications' => $specifications]);
   }
   /**
    * Show the form for creating a new resource.
    *
    * @return \Illuminate\Http\Response
    */
   public function create()
   {
       //
   }
   /**
    * Store a newly created resource in storage.
    *
    * @param  \Illuminate\Http\Request  $request
    * @return \Illuminate\Http\Response
    */
   public function store(Request $request)
   {
    try {
        $category=new CategorySpecification();

        $category->specification_name=  $request->specification_name;
        $category->description =$request->description;
        $category->save();

        $specifications = CategorySpecification::all();
   
    return view('category_specifications' ,['specifications' => $specifications]);
    } catch(\Exception $exception) {
        // throw new HttpException(400, "Invalid data - {$exception->getMessage}");
        $specifications = CategorySpecification::all();
   
        return view('category_specifications' ,['specifications' => $specifications]);
   }
}
   /**
    * Display the specified resource.
    *
    * @param  int  $id
    * @return \Illuminate\Http\Response
    */
   public function show($id)
   {
    if(is_numeric($id))
    {
        $specifications = CategorySpecification::find($id);
        return view('category_specifications' ,['specifications' => $specifications]);
    }
    else
    {
        $specifications = CategorySpecification::all();
   
        return view('category_specifications' ,['specifications' => $specifications]);
    }  
   }
   /**
    * Show the form for editing the specified resource.
    *
    * @param  int  $id
    * @return \Illuminate\Http\Response
    */
   public function edit($id)
   {
    try {
        $specification=CategorySpecification::find($id);
    return view('editcategory_specification' ,['specification' => $specification]);
    } catch(\Exception $exception) {
        // throw new HttpException(400, "Invalid data - {$exception->getMessage}");
        $specifications = CategorySpecification::all();
   
        return view('category_specifications' ,['specifications' => $specifications]);
   }
   }
   /**
    * Update the specified resource in storage.
    *
    * @param  \Illuminate\Http\Request  $request
    * @param  int  $id
    * @return \Illuminate\Http\Response
    */
   public function update(Request $request, $id)
   {
    try {
        $category=CategorySpecification::find($id);

        $category->specification_name=  $request->specification_name;
        $category->description =$request->description;
        $category->save();

        $specifications = CategorySpecification::all();
        return view('category_specifications' ,['specifications' => $specifications]);
    } catch(\Exception $exception) {
        // throw new HttpException(400, "Invalid data - {$exception->getMessage}");
        $specifications = CategorySpecification::all();
        return view('category_specifications' ,['specifications' => $specifications]);
   }
   }
   /**
    * Remove the specified resource from storage.
    *
    * @param  int  $id
    * @return \Illuminate\Http\Response
    */
   public function destroy($id)
   {
    $spec = CategorySpecification::findOrFail($id);
    $spec->delete();
    return response()->json(['تمت العملية بنجاح'], 200);
   }


   public function change_status(Request $request)
   {
    $id = $request->id;
    $category_specitication = CategorySpecification::findOrFail($id);
    $category_specitication->status=$request->status;
    $category_specitication->save();
    return response()->json(['تمت العملية بنجاح'], 200);
   }

   public function get_archive()
    {
        $specifications = CategorySpecification::onlyTrashed()->get();
        return view('archives.category_specifications_archive', ['specifications'=>$specifications] );
    }

    public function restore_archive($id)
    {
        $specification = CategorySpecification::onlyTrashed()->find($id);
        if(!$specification){
            return redirect()->back()->with('error', 'لا يوجد وصف بهذا الرقم');
        }
        $specification->restore();
        return redirect()->back()->with('success', 'تمت العملية بنجاح');
    }
}
