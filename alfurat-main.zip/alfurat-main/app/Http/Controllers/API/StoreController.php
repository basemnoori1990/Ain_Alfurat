<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Store;

class StoreController extends Controller
{
    public function index()
    {
        $stores = Store::with('user')->get();
        return response()->json(['stores'=>$stores], 200);
    }

    /**
     * @OA\Get(
     *      path="/stores",
     *      operationId="show_store",
     *      tags={"Store"},
     *      summary="Get list of stores",
     *      description="Returns list of stores",
     *      @OA\Response(
     *          response=200,
     *          description="Successful operation",
     *       ),
     *      @OA\Response(
     *          response=401,
     *          description="Unauthenticated",
     *      ),
     *      @OA\Response(
     *          response=403,
     *          description="Forbidden"
     *      )
     *     )
     */
    
     public function show($id)
    {
        $stores = Store::find($id);
        return response()->json(['stores'=>$stores], 200);
    }

    /**
     * @OA\Post(
     *      path="/store",
     *      operationId="user_store",
     *      tags={"Store"},
     *      summary="User Store",
     *      description="user store",
     *     @OA\Parameter(
     *          name="owner_name",
     *          description="Owner Name",
     *          required=true,
     *          in="path",
     *          @OA\Schema(
     *              type="text"
     *          )
     *      ),
     *     @OA\Parameter(
     *          name="store_name",
     *          description="Store Name",
     *          required=true,
     *          in="path",
     *          @OA\Schema(
     *              type="text"
     *          )
     *      ),
     *     @OA\Parameter(
     *          name="district",
     *          description="District",
     *          required=true,
     *          in="path",
     *          @OA\Schema(
     *              type="text"
     *          )
     *      ),
     *      @OA\Parameter(
     *          name="address",
     *          description="Address",
     *          required=true,
     *          in="path",
     *          @OA\Schema(
     *              type="text"
     *          )
     *      ),
     *      @OA\Parameter(
     *          name="phone",
     *          description="Phone",
     *          required=true,
     *          in="path",
     *          @OA\Schema(
     *              type="text"
     *          )
     *      ),
     *      @OA\Parameter(
     *          name="lng",
     *          description="Longitude",
     *          required=true,
     *          in="path",
     *          @OA\Schema(
     *              type="decimal(18,8)"
     *          )
     *      ),
     *      @OA\Parameter(
     *          name="lat",
     *          description="Latitude",
     *          required=true,
     *          in="path",
     *          @OA\Schema(
     *              type="decimal(18,8)"
     *          )
     *      ),
     *      @OA\Response(
     *          response=200,
     *          description="Successful operation",
     *       ),
     *      @OA\Response(
     *          response=401,
     *          description="Unauthenticated",
     *      ),
     *      @OA\Response(
     *          response=403,
     *          description="Forbidden"
     *      )
     *     )
     */
    public function store(Request $request)
    {
        try {
            $store=new Store;
            $store->owner_name=$request->owner_name;
            $store->store_name=$request->store_name;
            $store->district=$request->district;
            $store->address=$request->address;
            $store->phone=$request->phone;
            $store->lng=$request->lng;
            $store->lat=$request->lat;
            $store->user_id = auth()->user()->id;
            $store->save();
            return response()->json(['store'=>$store], 200);

        } catch(\Exception $exception) {
            // throw new HttpException(400, "Invalid data - {$exception->getMessage}");
            return response()->json(["يوجد خطأ - {$exception->getMessage()}"], 400);

        }
    }

    /**
     * @OA\Put(
     *      path="/store/{id}",
     *      operationId="update_store",
     *      tags={"Store"},
     *      summary="User Store",
     *      description="update store",
     *     @OA\Parameter(
     *          name="owner_name",
     *          description="Owner Name",
     *          required=true,
     *          in="path",
     *          @OA\Schema(
     *              type="text"
     *          )
     *      ),
     *     @OA\Parameter(
     *          name="store_name",
     *          description="Store Name",
     *          required=true,
     *          in="path",
     *          @OA\Schema(
     *              type="text"
     *          )
     *      ),
     *     @OA\Parameter(
     *          name="district",
     *          description="District",
     *          required=true,
     *          in="path",
     *          @OA\Schema(
     *              type="text"
     *          )
     *      ),
     *      @OA\Parameter(
     *          name="address",
     *          description="Address",
     *          required=true,
     *          in="path",
     *          @OA\Schema(
     *              type="text"
     *          )
     *      ),
     *      @OA\Parameter(
     *          name="phone",
     *          description="Phone",
     *          required=true,
     *          in="path",
     *          @OA\Schema(
     *              type="text"
     *          )
     *      ),
     *      @OA\Parameter(
     *          name="lng",
     *          description="Longitude",
     *          required=true,
     *          in="path",
     *          @OA\Schema(
     *              type="decimal(18,8)"
     *          )
     *      ),
     *      @OA\Parameter(
     *          name="lat",
     *          description="Latitude",
     *          required=true,
     *          in="path",
     *          @OA\Schema(
     *              type="decimal(18,8)"
     *          )
     *      ),
     *      @OA\Response(
     *          response=200,
     *          description="Successful operation",
     *       ),
     *      @OA\Response(
     *          response=401,
     *          description="Unauthenticated",
     *      ),
     *      @OA\Response(
     *          response=403,
     *          description="Forbidden"
     *      )
     *     )
     */
    public function update(Request $request, $id)
    {
        try {
            $store=Store::find($id);
            $store->owner_name=$request->owner_name;
            $store->store_name=$request->store_name;
            $store->district=$request->district;
            $store->address=$request->address;
            $store->phone=$request->phone;
            $store->lng=$request->lng;
            $store->lat=$request->lat;
            // $store->user_id = auth()->user()->id;
            $store->save();
            return response()->json(['store'=>$store], 200);

        } catch(\Exception $exception) {
            // throw new HttpException(400, "Invalid data - {$exception->getMessage}");
            return response()->json(["يوجد خطأ - {$exception->getMessage()}"], 400);

        }
    }

    public function destroy($id)
    {
        // Logic to delete a specific record by ID from the database and return a JSON response indicating success or failure.
    }
}
