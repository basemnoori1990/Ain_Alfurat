<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Category;
use Illuminate\Http\Request;
use App\Models\Product;

class ProductController extends Controller
{
    /**
     * @OA\get(
     *      path="/products",
     *      operationId="get_products",
     *      tags={"Order"},
     *      summary="Get list of all products",
     *      description="get all products",
     *      @OA\Response(
     *          response=200,
     *          description="Successful operation",
     *       ),
     *      @OA\Response(
     *          response=401,
     *          description="Unauthenticated",
     *      ),
     *      @OA\Response(
     *          response=403,
     *          description="Forbidden"
     *      )
     *     )
     */
    public function index()
    {
        $products = Product::with('whole_unit')->with('unit_group')->with('category')->with('company')->with('whole_unit')->with('retail_unit')->with('vip_unit')->with('required_products', function ($q) {
            $q->with('whole_unit')->with('retail_unit')->get();
        })->where('status', 1)->get();
        return response()->json(['products' => $products], 200);
    }

    /**
     * @OA\Get(
     *      path="/products/id}",
     *      operationId="show_product",
     *      tags={"Product"},
     *      summary="Get product info",
     *      description="Returns product",
     *      @OA\Response(
     *          response=200,
     *          description="Successful operation",
     *       ),
     *      @OA\Response(
     *          response=401,
     *          description="Unauthenticated",
     *      ),
     *      @OA\Response(
     *          response=403,
     *          description="Forbidden"
     *      )
     *     )
     */
    public function show($id)
    {
        $products = Product::where('id', $id)->with('whole_unit')->with('unit_group')->with('category')->with('company')->with('whole_unit')->with('retail_unit')->with('vip_unit')->with('required_products', function ($q) {
            $q->with('whole_unit')->with('retail_unit')->get();
        })->first();
        return response()->json(['products' => $products], 200);
    }

    /**
     * @OA\Get(
     *      path="/products/show_by_category/{category_id}",
     *      operationId="show_by_category",
     *      tags={"Product"},
     *      summary="Get list of products related to category",
     *      description="Returns list of products",
     *      @OA\Parameter(
     *          name="category_id",
     *          description="Category Id",
     *          required=true,
     *          in="path",
     *          @OA\Schema(
     *              type="integer"
     *          ) 
     *      ),
     *      @OA\Response(
     *          response=200,
     *          description="Successful operation",
     *       ),
     *      @OA\Response(
     *          response=401,
     *          description="Unauthenticated",
     *      ),
     *      @OA\Response(
     *          response=403,
     *          description="Forbidden"
     *      )
     *     )
     */

    public function show_by_category($category_id)
    {
        $category = Category::where('id', $category_id)->with('category_specification')->first();
        $products = Product::where('category_id', $category_id)->with('whole_unit')->with('unit_group')->with('category')->with('company')->with('whole_unit')->with('retail_unit')->with('vip_unit')->with('required_products', function ($q) {
            $q->with('whole_unit')->with('retail_unit')->get();
        })->where('status', 1)->get();;
        return response()->json(['category' => $category, 'products' => $products], 200);
    }

    /**
     * @OA\Get(
     *      path="/product/show_by_company/{company_id}",
     *      operationId="show_by_company",
     *      tags={"Product"},
     *      summary="Get list of products related to company",
     *      description="Returns list of company",
     *      @OA\Parameter(
     *          name="company_id",
     *          description="Company Id",
     *          required=true,
     *          in="path",
     *          @OA\Schema(
     *              type="integer"
     *          ) 
     *      ),
     *      @OA\Response(
     *          response=200,
     *          description="Successful operation",
     *       ),
     *      @OA\Response(
     *          response=401,
     *          description="Unauthenticated",
     *      ),
     *      @OA\Response(
     *          response=403,
     *          description="Forbidden"
     *      )
     *     )
     */

    public function show_by_company($company_id)
    {
        $products = Product::where('company_id', $company_id)->with('whole_unit')->with('unit_group')->with('category')->with('company')->with('whole_unit')->with('retail_unit')->with('vip_unit')->with('required_products', function ($q) {
            $q->with('whole_unit')->with('retail_unit')->get();
        })->where('status', 1)->get();
        return response()->json(['products' => $products], 200);
    }


    public function require_products($product_id) {}
    public function store(Request $request)
    {
        try {
            $product = new Product;
            $product = Product::create($request->all());

            return response()->json(['product' => $product], 200);
        } catch (\Exception $exception) {
            // throw new HttpException(400, "Invalid data - {$exception->getMessage}");
            return response()->json(["Invalid data - {$exception->getMessage()}"], 400);
        }
    }


    public function update(Request $request, $id)
    {
        // Logic to update a specific record by ID in the database based on the data in the $request and return the updated record as JSON response.
    }

    public function destroy($id)
    {
        // Logic to delete a specific record by ID from the database and return a JSON response indicating success or failure.
    }
}
