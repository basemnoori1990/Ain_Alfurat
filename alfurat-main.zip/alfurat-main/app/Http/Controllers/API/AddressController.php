<?php

namespace App\Http\Controllers\Api;

use Exception;
use App\Models\Address;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Validator;

class AddressController extends Controller
{
    /**
     * @OA\get(
     *      path="/address",
     *      operationId="get_all_addresses",
     *      tags={"Address"},
     *      summary="Get list of addressess",
     *      description="show address",
     *      security={{"bearer_token":{}}},
     *      @OA\Response(
     *          response=200,
     *          description="Successful operation"
     *       ),
     *      @OA\Response(
     *          response=401,
     *          description="Unauthenticated",
     *      ),
     *      @OA\Response(
     *          response=403,
     *          description="Forbidden"
     *      )
     *     )
     */

    public function index()
    {
        $address = Address::where('status',1)->orderBy('id', 'desc')->get();
        return response()->json(['address' => $address], 200);
    }

    /**
     * @OA\Get(
     *      path="/addresses/id}",
     *      operationId="show_address",
     *      tags={"Address"},
     *      summary="Get address info",
     *      description="Returns Address",
     *      @OA\Response(
     *          response=200,
     *          description="Successful operation",
     *       ),
     *      @OA\Response(
     *          response=401,
     *          description="Unauthenticated",
     *      ),
     *      @OA\Response(
     *          response=403,
     *          description="Forbidden"
     *      )
     *     )
     */
    public function show($id)
    {
        $address = Address::findOrFail($id);
        return response()->json(['address' => $address]);
    }
     /**
     * @OA\Post(
     *      path="/address",
     *      operationId="store_address",
     *      tags={"Address"},
     *      summary="store address",
     *      description="store address",
     *     @OA\Parameter(
     *          name="user_id",
     *          description="User Id",
     *          required=true,
     *          in="path",
     *          @OA\Schema(
     *              type="integer"
     *          ) ),
     *     @OA\Parameter(
     *          name="city",
     *          description="city",
     *          required=true,
     *          in="path",
     *          @OA\Schema(
     *              type="text"
     *          ) ),
     *     @OA\Parameter(
     *          name="country",
     *          description="country",
     *          required=true,
     *          in="path",
     *          @OA\Schema(
     *              type="text"
     *          ) ),
     *     @OA\Parameter(
     *          name="postcode",
     *          description="postcode",
     *          required=true,
     *          in="path",
     *          @OA\Schema(
     *              type="text"
     *          )
     *      ),
     *     @OA\Parameter(
     *          name="street",
     *          description="street",
     *          required=true,
     *          in="path",
     *          @OA\Schema(
     *              type="text"
     *          )
     *      ),
     *     @OA\Parameter(
     *          name="building",
     *          description="building",
     *          required=true,
     *          in="path",
     *          @OA\Schema(
     *              type="text"
     *          )
     *      ),
     *     @OA\Parameter(
     *          name="floor",
     *          description="floor",
     *          required=true,
     *          in="path",
     *          @OA\Schema(
     *              type="integer"
     *          )
     *      ),
     * @OA\Parameter(
     *          name="phone",
     *          description="phone",
     *          required=true,
     *          in="path",
     *          @OA\Schema(
     *              type="text"
     *          )
     *      ),
     *     @OA\Parameter(
     *          name="notes",
     *          description="notes",
     *          required=false,
     *          in="path",
     *          @OA\Schema(
     *              type="text"
     *          )
     *      ),
     *          @OA\Parameter(
     *          name="lat",
     *          description="lat",
     *          required=false,
     *          in="path",
     *          @OA\Schema(
     *              type="text"
     *          )
     *      ),
     *     @OA\Parameter(
     *          name="lng",
     *          description="lng",
     *          required=false,
     *          in="path",
     *          @OA\Schema(
     *              type="text"
     *          )
     *      ),
     *      @OA\Response(
     *          response=200,
     *          description="Successful operation",
     *       ),
     *      @OA\Response(
     *          response=401,
     *          description="Unauthenticated",
     *      ),
     *      @OA\Response(
     *          response=403,
     *          description="Forbidden"
     *      )
     *     )
     */

    public function store(Request $request)
    {
        try {
            $validation = Validator::make($request->all(),[
                'city' => ['required'],
                'country' => ['nullable'],
                'postcode' => ['required'],
                'street' => ['required'],
                'building' => ['required'],
                'floor' => ['nullable'],
                'phone' => ['required'],
                'notes' => ['nullable'],
                'lat' => ['required'],
                'lng'=> ['required'],
            ]);

            if($validation -> fails()){
                return response()->json(['error' => $validation->errors()->all()]);
            }else{
            $address = address::create([
                'user_id' => auth()->user()->id,
                'city' => $request->city,
                'country' => $request->country,
                'postcode' => $request->postcode,
                'street' => $request->street,
                'building' => $request->building,
                'floor' => $request->floor,
                'phone' => $request->phone,
                'notes' => $request->notes,
                'lat' => $request->lat,
                'lng' => $request->lng,
            ]);
            return response()->json(['address' => $address], 200);
            }
        } catch (Exception $e) {
            return response()->json(["Invalid data - {$e->getMessage()}"], 400);
        }
    }

    /**
     * @OA\put(
     *      path="/address/{id}",
     *      operationId="update_address",
     *      tags={"Address"},
     *      summary="update address",
     *      description="update address",
     *     @OA\Parameter(
     *          name="user_id",
     *          description="User Id",
     *          required=true,
     *          in="path",
     *          @OA\Schema(
     *              type="integer"
     *          ) ),
     *     @OA\Parameter(
     *          name="city",
     *          description="city",
     *          required=true,
     *          in="path",
     *          @OA\Schema(
     *              type="text"
     *          ) ),
     *     @OA\Parameter(
     *          name="country",
     *          description="country",
     *          required=true,
     *          in="path",
     *          @OA\Schema(
     *              type="text"
     *          ) ),
     *     @OA\Parameter(
     *          name="postcode",
     *          description="postcode",
     *          required=true,
     *          in="path",
     *          @OA\Schema(
     *              type="text"
     *          )
     *      ),
     *     @OA\Parameter(
     *          name="street",
     *          description="street",
     *          required=true,
     *          in="path",
     *          @OA\Schema(
     *              type="text"
     *          )
     *      ),
     *     @OA\Parameter(
     *          name="building",
     *          description="building",
     *          required=true,
     *          in="path",
     *          @OA\Schema(
     *              type="text"
     *          )
     *      ),
     *     @OA\Parameter(
     *          name="floor",
     *          description="floor",
     *          required=true,
     *          in="path",
     *          @OA\Schema(
     *              type="integer"
     *          )
     *      ),
     *     @OA\Parameter(
     *          name="notes",
     *          description="notes",
     *          required=false,
     *          in="path",
     *          @OA\Schema(
     *              type="text"
     *          )
     *      ),
     *     @OA\Parameter(
     *          name="lat",
     *          description="lat",
     *          required=false,
     *          in="path",
     *          @OA\Schema(
     *              type="text"
     *          )
     *      ),
     *     @OA\Parameter(
     *          name="lng",
     *          description="lng",
     *          required=false,
     *          in="path",
     *          @OA\Schema(
     *              type="text"
     *          )
     *      ),
     *      @OA\Response(
     *          response=200,
     *          description="Successful operation",
     *       ),
     *      @OA\Response(
     *          response=401,
     *          description="Unauthenticated",
     *      ),
     *      @OA\Response(
     *          response=403,
     *          description="Forbidden"
     *      )
     *     )
     */

    public function update(Request $request, $id)
    {
        try {
            $address = Address::findOrFail($id);

            $validation = Validator::make($request->all(),[
                'city' => ['required'],
                'country' => ['nullable'],
                'postcode' => ['nullable'],
                'street' => ['required'],
                'building' => ['required'],
                'floor' => ['required'],
                'phone' => ['required'],
                'notes' => ['nullable'],
                'lat' => ['nullable'],
                'lng' => ['nullable'],
            ]);

            if($validation -> fails()){
                return response()->json(['error' => $validation->errors()->all()]);
            }else{
            $address->user_id = auth()->user()->id;
            $address->city = $request->city;
            $address->country = $request->country;
            $address->postcode = $request->postcode;
            $address->street = $request->street;
            $address->building = $request->building;
            $address->floor = $request->floor;
            $address->notes = $request->notes;
            $address->lat = $request->lat;
            $address->lng = $request->lng;

            $address->save();

            return response()->json(['تم اضافة العنوان بنجاح'], 200);
            }
        } catch (Exception $e) {
            return response()->json(["خطأ في المعلومات - {$e->getMessage()}"], 400);
        }
    }

    /**
     * @OA\delete(
     *      path="/address/{id}",
     *      operationId="delete_address",
     *      tags={"Address"},
     *      summary="delete address",
     *      description="delete address",
     *      @OA\Parameter(
     *          name="id",
     *          description="address id",
     *          required=true,
     *          in="path",
     *          @OA\Schema(
     *              type="integer"
     *          )
     *      ),
     *      @OA\Response(
     *          response=200,
     *          description="Successful operation",
     *       ),
     *      @OA\Response(
     *          response=401,
     *          description="Unauthenticated",
     *      ),
     *      @OA\Response(
     *          response=403,
     *          description="Forbidden"
     *      )
     *     )
     */

    public function destroy($id){
        $address = Address::findOrFail($id);
        $address->delete();
        return response()->json(['تم حذف العنوان بنجاح'], 200);
    }
}