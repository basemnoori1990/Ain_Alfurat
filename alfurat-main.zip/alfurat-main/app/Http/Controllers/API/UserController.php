<?php 
namespace App\Http\Controllers\Api;
 
use App\Http\Controllers\Controller;
 
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use App\Models\User;
use Carbon\Carbon;
use Validator;
use App\Models\Store;
use Illuminate\Support\Facades\Auth;

class UserController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth:api');
    }
    public function delete_account(Request $request)
    {
        // dd(auth()->user()->id);
        $result_store = Store::where('user_id',auth()->user()->id)->delete();
        $result_user = User::where('id',auth()->user()->id)->delete();
        return response()->json(['message' => 'تم حذف الحساب بنجاح']);
    }
}