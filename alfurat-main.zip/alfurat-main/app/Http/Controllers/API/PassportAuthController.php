<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;

use Illuminate\Http\Request;
use Illuminate\Support\Str;
use App\Models\User;
use Carbon\Carbon;
use Validator;
use Auth;
use App\Models\Store;
use Illuminate\Validation\Rule;

class PassportAuthController extends Controller
{

    public function __construct()
    {
        $this->middleware('auth:api', ['except' => ['login', 'register', 'verify', 'send_verification_code']]);
    }
    public function login(Request $request)
    {
        $data = [
            'phone' => $request->phone,
            'password' => $request->password
        ];

        if (auth()->attempt($data)) {
            $token = auth()->user()->createToken('Laravel8PassportAuth')->accessToken;
            return response()->json(['token' => $token], 200);
        } else {
            return response()->json(['error' => 'Unauthorised'], 401);
        }
    }

    public function send_verification_code($country_code, $phone, $verificationCode)
    {
        $params = array(
            'token' => env('ULTRAMSG_TOKEN'),
            'to' => $country_code . $phone,
            'body' => 'رمز التحقق هو : ' . $verificationCode
        );
        $curl = curl_init();
        curl_setopt_array($curl, array(
            CURLOPT_URL => "https://api.ultramsg.com/" . env('ULTRAMSG_INSTANCE') . "/messages/chat",
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => "",
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 30,
            CURLOPT_SSL_VERIFYHOST => 0,
            CURLOPT_SSL_VERIFYPEER => 0,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => "POST",
            CURLOPT_POSTFIELDS => http_build_query($params),
            CURLOPT_HTTPHEADER => array(
                "content-type: application/x-www-form-urlencoded"
            ),
        ));

        $response = curl_exec($curl);
        $err = curl_error($curl);
        curl_close($curl);
    }
    public function userInfo()
    {

        $user = User::where(['id' => auth()->user()->id])->with('store')->get();

        return response()->json(['user' => $user], 200);
    }
    /**
     * @OA\Post(
     *      path="/register",
     *      operationId="register",
     *      tags={"Auth"},
     *      summary="register or login",
     *      description="Register or Login",
     *      @OA\Parameter(
     *          name="country_code",
     *          description="Country Code",
     *          required=true,
     *          in="path",
     *          @OA\Schema(
     *              type="text"
     *          ) 
     *      ),
     *      @OA\Parameter(
     *          name="phone",
     *          description="Phone",
     *          required=true,
     *          in="path",
     *          @OA\Schema(
     *              type="text"
     *          ) 
     *      ),
     *      @OA\Response(
     *          response=200,
     *          description="Successful operation",
     *       ),
     *      @OA\Response(
     *          response=401,
     *          description="Unauthenticated",
     *      ),
     *      @OA\Response(
     *          response=403,
     *          description="Forbidden"
     *      )
     *     )
     */
    public function register(Request $request)
    {

        $validator = Validator::make($request->all(), [
            'phone' => [
                'required'
            ],
            'country_code' => 'required',
        ]);

        if ($validator->fails()) {
            return response()->json(['message' => $validator->errors()], 422);
        }

        if ($request->phone == '2345678910' && $request->country_code == '+1') {
            $verificationCode = 999999;
        } else {
            $verificationCode = rand(100000, 999999);
        }
        $user = User::where('phone', $request->phone)->first();

        //   $DELETED_USER=User::where('phone',$request->phone)->first();
        //   if($DELETED_USER)
        //   {
        //     $DELETED_USER->restore();
        //     $DELETED_USER->update([
        //         'phone' => $request->phone,
        //         'country_code' => $request->country_code,
        //         'verification_code' => $verificationCode,
        //         'expire_at' => Carbon::now()->addMinutes(5),
        //     ]);

        //     $this->send_verification_code($request->country_code,$request->phone,$verificationCode);

        //     if ($err) {
        //       echo "cURL Error #:" . $err;
        //     } else {
        //       echo $response;
        //     }

        //     return response()->json(['message' => 'تم ارسال الكود بنجاح']);

        //   }
        if ($user) {
            if ($request->phone == '2345678910' && $request->country_code == '+1') {
                $user->update([
                    'phone' => $request->phone,
                    'country_code' => $request->country_code,
                    'verification_code' => $verificationCode,
                    'expire_at' => Carbon::now()->addYears(100),

                ]);
            } else {
                $user->update([
                    'phone' => $request->phone,
                    'country_code' => $request->country_code,
                    'verification_code' => $verificationCode,
                    'expire_at' => Carbon::now()->addMinutes(5),

                ]);
                $this->send_verification_code($request->country_code, $request->phone, $verificationCode);
            }
            return response()->json(['message' => 'تم ارسال كود التفعيل بنجاح']);
        } else {
            try {
                if ($request->phone == '2345678910' && $request->country_code == '+1') {
                    $user = User::create([
                        'phone' => $request->phone,
                        'country_code' => $request->country_code,
                        'verification_code' => $verificationCode,
                        'expire_at' => Carbon::now()->addYears(100),
                    ]);
                } else {
                    $user = User::create([
                        'phone' => $request->phone,
                        'country_code' => $request->country_code,
                        'verification_code' => $verificationCode,
                        'expire_at' => Carbon::now()->addMinutes(5),
                    ]);
                    $this->send_verification_code($request->country_code, $request->phone, $verificationCode);
                }
                return response()->json(['message' => 'تم ارسال كود التفعيل بنجاح', 'verificationCode' => $verificationCode]);
            } catch (\Throwable $e) {
                return response()->json(['error' => $e->getMessage(), 'message' => 'لم يتم ارسال كود التفعيل'], 500);
            }
        }
    }

    /**
     * @OA\Post(
     *      path="/verify",
     *      operationId="verify",
     *      tags={"Auth"},
     *      summary="verify by verification code",
     *      description="Verify by Verification Code",
     *      @OA\Parameter(
     *          name="verification_code",
     *          description="Verification Code",
     *          required=true,
     *          in="path",
     *          @OA\Schema(
     *              type="text"
     *          ) 
     *      ),
     *      @OA\Response(
     *          response=200,
     *          description="Successful operation",
     *       ),
     *      @OA\Response(
     *          response=401,
     *          description="Unauthenticated",
     *      ),
     *      @OA\Response(
     *          response=403,
     *          description="Forbidden"
     *      )
     *     )
     */
    public function verify(Request $request)
    {
        $validator = Validator::make($request->all(), [
            //    'token_device' => 'required',
            'verification_code' => 'required',
        ]);
        $deviceIdentifier = Str::uuid()->toString();

        if ($validator->fails()) {
            return response()->json(['error' => $validator->errors()], 422);
        }

        $now = Carbon::now();
        $user = User::where('verification_code', $request->verification_code)->with('store')->first();
        $currentToken = $user->token;

        if (!$user || $user->verification_code != $request->verification_code) {
            return response()->json(['error' => 'كود التفعيل خاطيء'], 401);
        }

        if ($user && $now->isAfter($user->expire_at)) {
            return response()->json(['error' => 'انتهى زمن كود التفعيل'], 401);
        }

        // if ($currentToken) {
        //     $jwtToken = new Token($currentToken);
        //     JWTAuth::setToken($jwtToken)->invalidate();
        // }
        // $user->update([
        //     'token_device' => $request->token_device ?? null,
        //     'phone_verified' => 1,
        //     'current_device_id' => $deviceIdentifier,
        // ]);

        Auth::login($user);

        $token = auth()->user()->createToken('Laravel8PassportAuth')->accessToken;
        $user->update([
            'token_device' => $request->token_device ?? null,
            'phone_verified' => 1,
            'current_device_id' => $deviceIdentifier,
            'token' => $token,
            'fcm_token' => $request->fcm
        ]);
        return response()->json(['token' => $token, 'user' => $user]);
    }

    public function delete_account(Request $request)
    {
        $result_store = Store::where('user_id', auth()->user()->id)->delete();
        $result_user = User::where('id', auth()->user()->id)->delete();
        return response()->json(['message' => 'تم حذف الحساب بنجاح']);
    }
}
