<?php

namespace App\Http\Controllers\Api;

use Exception;
use App\Models\Unit;
use App\Models\User;
use App\Models\Order;
use App\Models\Address;
use App\Models\Product;
use Illuminate\Http\Request;
use App\Models\Order_details;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\DB;

class OrderOrderDetailsController extends Controller
{


}
