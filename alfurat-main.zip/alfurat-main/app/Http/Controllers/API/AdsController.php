<?php

namespace App\Http\Controllers\Api;

use Exception;
use App\Models\Ads;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Validator;

class AdsController extends Controller
{
    /**
     * @OA\get(
     *      path="/ads",
     *      operationId="get_all_ads",
     *      tags={"Ads"},
     *      summary="Get list of advertisements",
     *      description="show advertisements",
     *      @OA\Response(
     *          response=200,
     *          description="Successful operation",
     *       ),
     *      @OA\Response(
     *          response=401,
     *          description="Unauthenticated",
     *      ),
     *      @OA\Response(
     *          response=403,
     *          description="Forbidden"
     *      )
     *     )
     */
    public function index()
    {
        $ads = Ads::where('status',1)->where('expiration_time','>=',date('Y-m-d'))->with('product')->orderBy('id', 'desc')->get();
        return response()->json(['ads' => $ads], 200);
    }

    public function show($id)
    {
        $address = Address::findOrFail($id);
        return response()->json(['address' => $address]);
    }
        

    public function store(Request $request)
    {
       
    }

   

    public function update(Request $request, $id)
    {
        
    }


    

    public function destroy($id){
       
    }

}
