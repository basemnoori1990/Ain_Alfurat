<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Category;

class CategoryController extends Controller
{
    /**
     * @OA\Get(
     *      path="/categories",
     *      operationId="get_main_categories",
     *      tags={"Category"},
     *      summary="Get list of main categories",
     *      description="show main categories",
     *      @OA\Response(
     *          response=200,
     *          description="Successful operation",
     *       ),
     *      @OA\Response(
     *          response=401,
     *          description="Unauthenticated",
     *      ),
     *      @OA\Response(
     *          response=403,
     *          description="Forbidden"
     *      )
     *     )
     */
    public function index()
    {
        $categories = Category::where('parent_id', null)->with('sub_categories')->where('status', 1)->get();
        return response()->json(['categories' => $categories], 200);
    }

    /**
     * @OA\Get(
     *      path="/categories/show/{id}",
     *      operationId="show_category",
     *      tags={"Category"},
     *      summary="Get list of categories",
     *      description="Returns list of categories",
     * @OA\RequestBody(
     *           @OA\JsonContent(
     *              
     *              
     *          )
     *     ),
     *      @OA\Parameter(
     *          name="$id",
     *          description="Category Id",
     *          required=false,
     *          in="path",
     *          @OA\Schema(
     *              type="integer"
     *          ) 
     *      ),
     *      @OA\Response(
     *          response=200,
     *          description="Successful operation",
     *       ),
     *      @OA\Response(
     *          response=401,
     *          description="Unauthenticated",
     *      ),
     *      @OA\Response(
     *          response=403,
     *          description="Forbidden"
     *      )
     *     )
     */
    public function show($id = '')
    {
        if (is_numeric($id))
            $categories = Category::where('status', 1)->where('id', $id)->with('sub_categories')->first();
        else
            $categories = Category::where('status', 1)->get();
        return response()->json(['categories' => $categories], 200);
    }

    /**
     * @OA\Get(
     *      path="/categories/show_by_parent/{category_parent_id}",
     *      operationId="show_by_parent",
     *      tags={"Category"},
     *      summary="Get list of sub categories by parent id",
     *      description="Get list of sub categories by parent id",
     * @OA\RequestBody(
     *           @OA\JsonContent(
     *              
     *              
     *          )
     *     ),
     *      @OA\Parameter(
     *          name="parent_id",
     *          description="Parent Id",
     *          required=true,
     *          in="path",
     *          @OA\Schema(
     *              type="integer"
     *          ) 
     *      ),
     *      @OA\Response(
     *          response=200,
     *          description="Successful operation",
     *       ),
     *      @OA\Response(
     *          response=401,
     *          description="Unauthenticated",
     *      ),
     *      @OA\Response(
     *          response=403,
     *          description="Forbidden"
     *      )
     *     )
     */
    public function show_by_parent($parent_id)
    {
        $categories = Category::where('parent_id', $parent_id)->where('status', 1)->get();
        return response()->json(['categories' => $categories], 200);
    }


    public function store(Request $request)
    {
        try {
            $Category = new Category();

            $Category = Category::create($request->all());

            return response()->json(['Category' => $Category], 200);
        } catch (\Exception $exception) {
            // throw new HttpException(400, "Invalid data - {$exception->getMessage}");
            return response()->json(["Invalid data - {$exception->getMessage()}"], 400);
        }
    }

    public function update(Request $request, $id)
    {
        // Logic to update a specific record by ID in the database based on the data in the $request and return the updated record as JSON response.
    }

    public function destroy($id)
    {
        // Logic to delete a specific record by ID from the database and return a JSON response indicating success or failure.
    }
}
