<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Company;

class CompanyController extends Controller
{
    public function index()
    {
        $companies = Company::where('status',1)->get();
        return response()->json(['companies'=>$companies], 200);

    }

    /**
     * @OA\Get(
     *      path="/companies",
     *      operationId="show_company",
     *      tags={"Company"},
     *      summary="Get list of companies",
     *      description="Returns list of companies",
     *      @OA\Response(
     *          response=200,
     *          description="Successful operation",
     *       ),
     *      @OA\Response(
     *          response=401,
     *          description="Unauthenticated",
     *      ),
     *      @OA\Response(
     *          response=403,
     *          description="Forbidden"
     *      )
     *     )
     */
    
     public function show($id)
    {
        $companies = Company::find($id);
        return response()->json(['companies'=>$companies], 200);
    }

    
    public function store(Request $request)
    {
        try {
            $company = new Company;
            $Company=Company::create($request->all());

            return response()->json(['company'=>$company], 200);

        } catch(\Exception $exception) {
            // throw new HttpException(400, "Invalid data - {$exception->getMessage}");
            return response()->json(["Invalid data - {$exception->getMessage()}"], 400);

        }}

    public function update(Request $request, $id)
    {
        // Logic to update a specific record by ID in the database based on the data in the $request and return the updated record as JSON response.
    }

    public function destroy($id)
    {
        // Logic to delete a specific record by ID from the database and return a JSON response indicating success or failure.
    }
}
