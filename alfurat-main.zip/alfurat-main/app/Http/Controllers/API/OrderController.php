<?php

namespace App\Http\Controllers\Api;

use Exception;
use App\Models\Unit;
use App\Models\User;
use App\Models\Order;
use App\Models\Address;
use App\Models\Product;
use App\Models\Cart;

use Illuminate\Http\Request;
use App\Models\Order_details;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\DB;
use App\Notifications\UserNotification;
use Google_Client;


class OrderController extends Controller
{
    
 /**
     * @OA\get(
     *      path="/orders",
     *      operationId="get_all_orders",
     *      tags={"Order"},
     *      summary="Get list of orders",
     *      description="show orders",
     *      @OA\Response(
     *          response=200,
     *          description="Successful operation",
     *       ),
     *      @OA\Response(
     *          response=401,
     *          description="Unauthenticated",
     *      ),
     *      @OA\Response(
     *          response=403,
     *          description="Forbidden"
     *      )
     *     )
     */
    public function index()
    {
         $current_orders = Order::whereIn('status',[1,2,3])->where('user_id',auth()->user()->id)->with('user')->with('order_details.products', 'order_details.units')->orderBy('created_at', 'DESC')->get();
        $old_orders = Order::whereIn('status',[4,5,6])->where('user_id',auth()->user()->id)->with('user')->with('order_details.products', 'order_details.units')->orderBy('created_at', 'DESC')->get();
        return response()->json(['current_orders' => $current_orders,'old_orders' => $old_orders], 200);
    }

    /**
     * @OA\Get(
     *      path="/orders/{id}",
     *      operationId="show_order",
     *      tags={"Order"},
     *      summary="Get order info",
     *      description="Returns order",
     *      @OA\Response(
     *          response=200,
     *          description="Successful operation",
     *       ),
     *      @OA\Response(
     *          response=401,
     *          description="Unauthenticated",
     *      ),
     *      @OA\Response(
     *          response=403,
     *          description="Forbidden"
     *      )
     *     )
     */
    public function show($id)
    {
        $order = Order::findOrFail($id)->with('order_details.products', 'order_details.units')->get();
        return response()->json(['order' => $order]);
    }

    /**
     * @OA\Post(
     *      path="/orders",
     *      operationId="store_order",
     *      tags={"Order"},
     *      summary="store order",
     *      description="store order",
     *     @OA\Parameter(
     *          name="address",
     *          description="Address",
     *          required=true,
     *          in="path",
     *          @OA\Schema(
     *              type="int"
     *          )
     *      ),
     *     @OA\Parameter(
     *          name="discount",
     *          description="Discount (%)",
     *          required=true,
     *          in="path",
     *          @OA\Schema(
     *              type="decimal(24,6)"
     *          )
     *      ),
     * 
     *     @OA\Parameter(
     *          name="delivery_fee",
     *          description="Delivery Fee",
     *          required=true,
     *          in="path",
     *          @OA\Schema(
     *              type="decimal(18,2)"
     *          )
     *      ),
     *     @OA\Parameter(
     *          name="payment_method",
     *          description="Payment Method",
     *          required=true,
     *          in="path",
     *          @OA\Schema(
     *              type="string"
     *          )
     *      ),
     *     @OA\Parameter(
     *          name="location",
     *          description="Location",
     *          required=true,
     *          in="path",
     *          @OA\Schema(
     *              type="string"
     *          )
     *      ),
     *     @OA\Parameter(
     *          name="delivery_time",
     *          description="Delivery time Ex. (2024-03-20 01:50:24)",
     *          required=true,
     *          in="path",
     *          @OA\Schema(
     *              type="DateTime"
     *          )
     *      ),
     *     @OA\Parameter(
     *          name="tax",
     *          description="tax (%)",
     *          required=true,
     *          in="path",
     *          @OA\Schema(
     *              type="decimal(24,6)"
     *          )
     *      ),
     *     @OA\Parameter(
     *     name="order_details.*.product_id",
     *     description="For example: 'order{'order_details':[{'product_id':1}]}'",
     *     required=true,
     *     in="path",
     *     @OA\Schema(
     *         type="integer"
     *     )
     *      ),
     *     @OA\Parameter(
     *          name="order_details.*.unit_id",
     *          description="order_details.*.unit_id",
     *          required=true,
     *          in="path",
     *          @OA\Schema(
     *              type="integer"
     *          )
     *      ),
     *     @OA\Parameter(
     *          name="order_details.*.qty",
     *          description="order_details.*.qty",
     *          required=true,
     *          in="path",
     *          @OA\Schema(
     *              type="integer"
     *          )
     *      ),
     *     @OA\Parameter(
     *          name="order_details.*.price",
     *          description="order_details.*.price",
     *          required=true,
     *          in="path",
     *          @OA\Schema(
     *              type="decimal(24,6)"
     *          )
     *      ),
     *      @OA\Response(
     *          response=200,
     *          description="Successful operation",
     *       ),
     *      @OA\Response(
     *          response=401,
     *          description="Unauthenticated",
     *      ),
     *      @OA\Response(
     *          response=403,
     *          description="Forbidden"
     *      )
     *     )
     */
    public function store(Request $request)
    {
        try {
            $validation = Validator::make($request->all(), [
                'tax' => 'required|numeric',
                'delivery_fees' => 'required|numeric',
                'discount' => 'required|numeric',
                'notes' => 'nullable|string',
                'order_details' => 'required|array|min:1',
                'order_details.*.product_id' => 'required|exists:products,id',
                'order_details.*.unit_id' => 'required|exists:units,id',
                'order_details.*.qty' => 'required|integer|min:1',
                'order_details.*.price' => 'required|numeric',
                'order_details.*.unit_type' => 'required|in:whole,retail,vip',
            ]);

            if ($validation->fails()) {
                return response()->json(['error' => $validation->errors()->all()]);
            } else {
    DB::beginTransaction();
                $order = Order::create([
                    'user_id' => auth()->user()->id,
                    'address' => $request->address,
                    'order_date' => now(),
                    'status' => 1,
                    'tax' => $request->tax,
                    'discount' => $request->discount,
                    'payment_method' => $request->payment_method,
                    'location' => $request->location,
                    'delivery_fees' => $request->delivery_fees,
                    'delivery_time' => $request->delivery_time,
                    'sub_total' => 0,
                    'total' => 0,
                    'notes' => $request->notes ?? '',
                ]);
                $total=0;
                $sub_total=0;
                
                foreach ($request->order_details as $detail) {

                    $sub_total += $detail['price'];

                    Order_details::create([
                        'order_id' => $order->id,
                        'product_id' => $detail['product_id'],
                        'unit_id' => $detail['unit_id'],
                        'qty' => $detail['qty'],
                        'price' => $detail['price']/$detail['qty'],
                        'sub_total' => $detail['price'],
                        'unit_type' => $request->unit_type,
                    ]);
                 }
                $total += $sub_total +$request->delivery_fees + ($sub_total * ($request->tax / 100)) - ($sub_total * ($request->discount / 100));


                $order->update([
                    'delivery_fees' => $request->delivery_fees,
                    'sub_total' => $sub_total,
                    'total' => $total,
                ]);
                Cart::where('user_id',auth()->user()->id)->delete();
                DB::commit();
               $orders = Order::orderBy('id', 'desc')->with('order_details.products', 'order_details.units')->get();
               
                return response()->json(['orders' => $orders,], 200);
            }
        } catch (Exception $e) {
            DB::rollback();
            return response()->json(["Invalid data - {$e->getMessage()}"], 400);
        }
    }

   
    // public function update(Request $request, $id)
    // {
    // //     try {
    //         $order = Order::findOrFail($id);

    //         if (!$order) {
    //             return response()->json(['error' => 'Order not found'], 404);
    //         }

    //         $validation = Validator::make($request->all(), [
    //             'status' => 'required',
    //             'tax' => 'required|numeric',
    //             'discount' => 'required|numeric',
    //             'order_details' => 'required|array',
    //             'order_details.*.product_id' => 'required|exists:products,id',
    //             'order_details.*.unit_id' => 'required|exists:units,id',
    //             'order_details.*.qty' => 'required|integer|min:1',
    //             'order_details.*.price' => 'required|numeric',
    //         ]);

    //         if ($validation->fails()) {
    //             return response()->json(['error' => $validation->errors()->all()]);
    //         } else {

    //             $order->update([
    //                 'status' => $request->status,
    //                 'tax' => $request->tax,
    //                 'discount' => $request->discount,
    //             ]);

    //             $orderDetails = $request->order_details;

    //             foreach ($orderDetails as $Data) {

    //                 $order_details = Order_details::where('order_id', $order->id)->first();

    //                 if ($order_details) {

    //                     $order_details->update([
    //                         'order_id' => $order->id,
    //                         'sub_total' => $order->sub_total,
    //                         'product_id' => $Data['product_id'],
    //                         'unit_id' => $Data['unit_id'],
    //                         'qty' => $Data['qty'],
    //                         'price' => $Data['price'],
    //                     ]);
    //                 }
    //             }

    //             return response()->json(['Order updated successfully'], 200);
    //         }
    //     } catch (Exception $e) {
    //         return response()->json(["Invalid data - {$e->getMessage()}"], 400);
    //     }
    // }

     
    public function destroy($id)
    {
        try{
            $order = Order::find($id);
            if (!$order) {
                return response()->json(['error' => 'Order not found'], 404);
            }
            $order->orderDetails()->delete();
            $order->delete();
            return response()->json([ 'Order deleted successfully'], 200);
        }catch(Exception $e){
            return response()->json(["Invalid data - {$e->getMessage()}"], 400);
        }
    }

    /**
     * @OA\get(
     *      path="/orders/get_agent_orders",
     *      operationId="get_all_agent_orders",
     *      tags={"Order"},
     *      summary="Get list of agent orders",
     *      description="show agent orders",
     *      @OA\Response(
     *          response=200,
     *          description="Successful operation",
     *       ),
     *      @OA\Response(
     *          response=401,
     *          description="Unauthenticated",
     *      ),
     *      @OA\Response(
     *          response=403,
     *          description="Forbidden"
     *      )
     *     )
     */
    public function get_agent_orders()
    {
        $current_orders = Order::whereIn('status',[3])->where('agent_id',auth()->user()->id)->with('user')->with('order_details.products', 'order_details.units')->orderBy('created_at', 'DESC')->get();
        $old_orders = Order::whereIn('status',[4,5,6])->where('agent_id',auth()->user()->id)->with('user')->with('order_details.products', 'order_details.units')->orderBy('created_at', 'DESC')->get();
        return response()->json(['current_orders' => $current_orders,'old_orders' => $old_orders], 200);
    }
    public function change_status(Request $request)
    {
        $id = $request->id;
        $order = Order::findOrFail($id);
        $order->status = $request->status;
        $order->save();

        $user = User::find($order->user_id);
        $recipients = [$user];
        $status = $order->statuses($request->status);
        // $data=['تم تغيير الحالة', 'تم تغيير حالة الطلب إلى '.$status['status_name']];

        // $title = 'تم تغيير حالة الطلب';
        $title = 'رقم الطلب:' . $order->id;
        $body = 'تم تغيير حالة الطلب إلى ' . $status['status_name'];

        $fcm_token = $user->fcm_token;

        // $fcm = new FCM;
        $client = new Google_Client();
        $client->setAuthConfig(base_path('config/' . env('GOOGLE_SERVICE_ACCOUNT')));
        $client->addScope('https://www.googleapis.com/auth/firebase.messaging');
        $client->refreshTokenWithAssertion();
        $token = $client->getAccessToken();
        $apiKey = $token['access_token'];
        $result = $this->sendFCM($fcm_token, $title, $body, $apiKey);
        // $notification = $fcm->sendMessage($result, $title, $body, $data = null);   // $user->notify(new UserNotification('تم تغيير الحالة', 'تم تغيير حالة الطلب إلى '.$status['status_name']));

        return response()->json(['تمت العملية بنجاح'], 200);
    }

    function sendFCM($token, $title, $body, $apiKey)
    {
        // FCM endpoint for HTTP v1 API
        $url = 'https://fcm.googleapis.com/v1/projects/dinar-store/messages:send';

        // Payload to send to FCM
        $notification = [
            'message' => [
                'token' => $token,
                'notification' => [
                    'title' => $title,
                    'body' => $body,
                ],
            ],
        ];

        // Initialize cURL
        $ch = curl_init();

        // Set cURL options
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, ['Authorization: Bearer ' . $apiKey, 'Content-Type: application/json']);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($notification));

        // Execute cURL request
        $response = curl_exec($ch);

        // Check for errors
        if ($response === false) {
            $error = curl_error($ch);
            curl_close($ch);
            return 'Curl error: ' . $error;
        }

        // Close cURL
        curl_close($ch);

        // Return response
        return $response;
    }
 }
 