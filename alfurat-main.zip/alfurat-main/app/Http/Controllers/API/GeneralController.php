<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Company;
use App\Models\Category;
use App\Models\Product;

class GeneralController extends Controller
{

    public function __construct() {}

    /**
     * @OA\Post(
     *      path="/search",
     *      operationId="search",
     *      tags={"General"},
     *      summary="Search",
     *      description="Search for company, category & product",
     *     @OA\Parameter(
     *          name="keyword",
     *          description="Keyword",
     *          required=true,
     *          in="path",
     *          @OA\Schema(
     *              type="text"
     *          )
     *      ),
     *      @OA\Response(
     *          response=200,
     *          description="Successful operation",
     *       ),
     *      @OA\Response(
     *          response=401,
     *          description="Unauthenticated",
     *      ),
     *      @OA\Response(
     *          response=403,
     *          description="Forbidden"
     *      )
     *     )
     */

    public function search(Request $request)
    {
        $keyword = $request->keyword;
        $companies = Company::where('company_name', 'like', "%$keyword%")->where('status', 1)->get();
        $categories = Category::where('category_name', 'like', "%$keyword%")->where('status', 1)->get();
        $product = Product::where('product_name', 'like', "%$keyword%")->where('status', 1)->get();
        return response()->json([
            'companies' => $companies,
            'categories' => $categories,
            'products' => $product
        ]);
    }
}
