<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Cart;
use App\Models\Product;
use App\Models\Settings;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class CartController extends Controller
{
    public function index()
    {
        $cart = Cart::with(['product', 'unit'])
            ->where('user_id', auth()->user()->id)
            ->whereHas('product', function ($query) {
                $query->whereNull('deleted_at');
            })
            ->whereHas('unit', function ($query) {
                $query->whereNull('deleted_at');
            })->get();        // $price_per_kilometer = '200';
        $delivery_fees =Settings::where('key','price_per_kilometer')->first();
        $min_order = Settings::where('key', 'min_order')->first();
        return response()->json(['cart'=>$cart,'delivery_fees'=>$delivery_fees->value,'min_order'=>$min_order->value], 200);
    }

    /**
     * @OA\Get(
     *      path="/cart",
     *      operationId="show_cart",
     *      tags={"Cart"},
     *      summary="Get list of Cart items",
     *      description="Returns list of cart items",
     *
     *      @OA\Response(
     *          response=200,
     *          description="Successful operation",
     *       ),
     *      @OA\Response(
     *          response=401,
     *          description="Unauthenticated",
     *      ),
     *      @OA\Response(
     *          response=403,
     *          description="Forbidden"
     *      )
     *     )
     */
    public function show($id)
    {
        $cart = Cart::find($id);

        return response()->json(['cart' => $cart], 200);
    }

    /**
     * @OA\Post(
     *      path="/cart",
     *      operationId="store_cart_item",
     *      tags={"Cart"},
     *      summary="Store Cart item",
     *      description="Store Cart item",
     *
     *     @OA\Parameter(
     *          name="product_id",
     *          description="product id",
     *          required=true,
     *          in="path",
     *
     *          @OA\Schema(
     *              type="integer"
     *          )
     *      ),
     *
     *     @OA\Parameter(
     *          name="quantity",
     *          description="Quantiy",
     *          required=true,
     *          in="path",
     *
     *          @OA\Schema(
     *              type="decimal(24,6)"
     *          )
     *      ),
     *
     * @OA\Parameter(
     *          name="unit_id",
     *          description="Unit Id",
     *          required=true,
     *          in="path",
     *
     *          @OA\Schema(
     *              type="integer"
     *          )
     *      ),
     *
     *     @OA\Parameter(
     *          name="price",
     *          description="Unit price",
     *          required=true,
     *          in="path",
     *
     *          @OA\Schema(
     *              type="text"
     *          )
     *      ),
     *
     * @OA\Parameter(
     *          name="is_required",
     *          description="Is item required",
     *          required=true,
     *          in="path",
     *
     *          @OA\Schema(
     *              type="boolean"
     *          )
     *      ),@OA\Parameter(
     *          name="ref_ref_cart_id",
     *          description="Ref cart id",
     *          required=true,
     *          in="path",
     *          @OA\Schema(
     *              type="integer"
     *          )
     *      ),
     *
     *      @OA\Response(
     *          response=200,
     *          description="Successful operation",
     *       ),
     *      @OA\Response(
     *          response=401,
     *          description="Unauthenticated",
     *      ),
     *      @OA\Response(
     *          response=403,
     *          description="Forbidden"
     *      )
     *     )
     */
    public function store(Request $request)
    {
        try {
            $cart = new Cart;
            $cart->product_id = $request->product_id;
            $cart->user_id = auth()->user()->id;
            $cart->unit_id = $request->unit_id;
            $cart->quantity = $request->quantity;
            $cart->price = $request->price;
            $cart->is_required = $request->is_required;
            $cart->ref_cart_id = $request->ref_cart_id;
            $cart->unit_type = $request->unit_type;

            $result = $cart->save();
            $cart_items = Cart::with('product')->with('unit')->where('user_id', auth()->user()->id)->get();

            return response()->json(['cart' => $cart_items, 'inserted_item' => $cart->id], 200);
        } catch (\Exception $exception) {
            // throw new HttpException(400, "Invalid data - {$exception->getMessage}");
            return response()->json(["Invalid data - {$exception->getMessage()}"], 400);
        }
    }

    /**
     * @OA\Put(
     *      path="/cart/{id}",
     *      operationId="update_cart_item",
     *      tags={"Cart"},
     *      summary="Update Cart item",
     *      description="Update Cart item",
     *
     *     @OA\Parameter(
     *          name="quantity",
     *          description="Quantiy",
     *          required=true,
     *          in="path",
     *
     *          @OA\Schema(
     *              type="decimal(24,6)"
     *          )
     *      ),
     *
     *      @OA\Response(
     *          response=200,
     *          description="Successful operation",
     *       ),
     *      @OA\Response(
     *          response=401,
     *          description="Unauthenticated",
     *      ),
     *      @OA\Response(
     *          response=403,
     *          description="Forbidden"
     *      )
     *     )
     */
    public function update($id, Request $request)
    {
        try {
            $cart = Cart::find($id);
            $cart->quantity = $request->quantity;
            $result = $cart->save();

            $required_products = Cart::where('ref_cart_id', $id)->get();

            //bring cart info
            //take required products from products
            //take unit and id compair with cart item
            //if equal ((int)cartitem qty / product qty)*required product qty
            //update cart item quantity
            foreach ($required_products as $required_product) {
                $product_id = $cart->product_id;
                $master_product = DB::table('required_products')->where('product_id', $cart->product_id)->where('unit_id', $cart->unit_id)->where('required_product_id', $required_product->product_id)->where('required_unit_id', $required_product->unit_id)->first();
                if ($master_product) {

                    $required_product->quantity = ((int) ($cart->quantity / $master_product->quantity)) * $master_product->required_quantiy;
                    $required_product->save();
                }
            }
            $cart_items = Cart::with('product')->with('unit')->where('user_id', auth()->user()->id)->get();

            return response()->json(['cart' => $cart_items], 200);
        } catch (\Exception $exception) {
            return response()->json(["خطأ في البيانات - {$exception->getMessage()}"], 400);
        }
    }

    /**
     * @OA\Delete(
     *      path="/cart/{id}",
     *      operationId="delete_cart_item",
     *      tags={"Cart"},
     *      summary="Delete Cart item",
     *      description="Delete Cart item",
     *
     *      @OA\Parameter(
     *          name="id",
     *          description="Cart item id",
     *          required=true,
     *          in="path",
     *
     *          @OA\Schema(
     *              type="integer"
     *          )
     *      ),
     *
     *      @OA\Response(
     *          response=200,
     *          description="Successful operation",
     *       ),
     *      @OA\Response(
     *          response=401,
     *          description="Unauthenticated",
     *      ),
     *      @OA\Response(
     *          response=403,
     *          description="Forbidden"
     *      )
     *     )
     */
    public function destroy($id)
    {
        try {
            cart::destroy($id);
            cart::where('ref_cart_id', $id)->delete();
            $cart = Cart::with('product')->with('unit')->where('user_id', auth()->user()->id)->get();

            return response()->json(['cart' => $cart], 200);
        } catch (\Exception $exception) {
            // throw new HttpException(400, "Invalid data - {$exception->getMessage}");
            return response()->json(["يوجد خطأ - {$exception->getMessage()}"], 400);
        }
    }
}
