<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Category;
use App\Models\CategorySpecification;


class CategoryController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
    $categories = Category::with('parent')->get();
    $main_categories =Category::where('parent_id',null)->get();
    // $sub_categories =Category::where('level',2)->get();
    $specifications =CategorySpecification::all();

    return view('categories' ,['categories' => $categories,    
    'main_categories'=>$main_categories,
    // 'sub_categories'=>$sub_categories,
    'specifications'=>$specifications]);
   }
   /**
    * Show the form for creating a new resource.
    *
    * @return \Illuminate\Http\Response
    */
   public function create()
   {
       //
   }
   /**
    * Store a newly created resource in storage.
    *
    * @param  \Illuminate\Http\Request  $request
    * @return \Illuminate\Http\Response
    */
   public function store(Request $request)
   {
       
    try {
        $category=new Category;

        $category->category_name = $request->category_name;  
        $category->description = $request->description;  
        if ($request->hasfile('image'))
        {
        $imagePath = $request->file('image')->store('images', 'public');
        $category->image = $imagePath;
        }
         if (($request->main_category_id !=-1&&$request->main_category_id!=null) && ($request->sub_category_id==-1||$request->sub_category_id==null))
        {
        // $category->level = 2;
        $category->parent_id = $request->main_category_id;
        }
        // else if (($request->main_category_id !="-1"&&$request->main_category_id!=null) && ($request->sub_category_id!="-1"||$request->sub_category_id!=null))
        // {
        //     $category->level = 3;
        //     $category->parent_id = $request->sub_category_id;
        //     $category->category_specification_id = $request->category_specification_id;  
        // }
        // else
        // {
        //     $category->level = 1;
        // }

        $category->save();

        $categories = Category::with('parent')->get();
        $main_categories =Category::where('parent_id',null)->get();
        // $sub_categories =Category::where('level',2)->get();
        $specifications =CategorySpecification::all();

    return view('categories' ,['categories' => $categories,    
    'main_categories'=>$main_categories,
    'specifications'=>$specifications]);
    } catch(\Exception $exception) {
        // throw new HttpException(400, "Invalid data - {$exception->getMessage}");
        $categories = Category::with('parent')->get();
        $main_categories =Category::where('level',1)->get();
        $sub_categories =Category::where('level',2)->get();
        $specifications =CategorySpecification::all();

        return view('categories' ,['categories' => $categories,    
        'main_categories'=>$main_categories,
        'specifications'=>$specifications]);
        }
   }
   /**
    * Display the specified resource.
    *
    * @param  int  $id
    * @return \Illuminate\Http\Response
    */
   public function show($id)
   {
    if(is_numeric($id))
    {
        $category = Category::find($id);
        return view('category' ,['category' => $category]);
    }
    else
    {
        $categories = Category::with('parent')->get();
        $main_categories =Category::where('parent_id',null)->get();
    $specifications =CategorySpecification::all();

    return view('categories' ,['categories' => $categories,    
    'main_categories'=>$main_categories,
    'specifications'=>$specifications]);
        }  
   }
   /**
    * Show the form for editing the specified resource.
    *
    * @param  int  $id
    * @return \Illuminate\Http\Response
    */
   public function edit($id)
   {
    $category = Category::find($id);
    $main_categories =Category::where('parent_id',null)->get();
    $specifications =CategorySpecification::all();


    return view('editcategory' ,['category' => $category,   
    'main_categories'=>$main_categories,
    'specifications'=>$specifications]);
   }
   /**
    * Update the specified resource in storage.
    *
    * @param  \Illuminate\Http\Request  $request
    * @param  int  $id
    * @return \Illuminate\Http\Response
    */
   public function update(Request $request, $id)
   {
    //   dd([$request->sub_category_id,($request->main_category_id !=-1||$request->main_category_id!=null),($request->sub_category_id==-1||$request->sub_category_id==null)]);
       try {
        $category= Category::find($id);

        $category->category_name = $request->category_name;  
        $category->description = $request->description;  

        if ($request->hasfile('image'))
        {
        $imagePath = $request->file('image')->store('images', 'public');
        $category->image = $imagePath; 
        }
        if (($request->main_category_id !=-1&&$request->main_category_id!=null) && ($request->sub_category_id==-1||$request->sub_category_id==null))
        {
        $category->parent_id = $request->main_category_id;
        }
        $category->save();

        $categories = Category::with('parent')->get();
        $main_categories =Category::where('parent_id',null)->get();
        $specifications =CategorySpecification::all();

    return view('categories' ,['categories' => $categories,    
    'main_categories'=>$main_categories,
    'specifications'=>$specifications]);
    } catch(\Exception $exception) {
        // throw new HttpException(400, "Invalid data - {$exception->getMessage}");
        $categories = Category::with('parent')->get();
        $main_categories =Category::where('parent_id',null)->get();
        $specifications =CategorySpecification::all();

        return view('categories' ,['categories' => $categories,    
        'main_categories'=>$main_categories,
        'specifications'=>$specifications]);
        }
   }
   /**
    * Remove the specified resource from storage.
    *
    * @param  int  $id
    * @return \Illuminate\Http\Response
    */
   public function destroy($id)
   {
    
    $category = Category::findOrFail($id);
    $category->delete();
    return response()->json(['تمت العملية بنجاح'], 200);
   }
   public function change_status(Request $request)
   {
    $id = $request->id;
    $category = Category::findOrFail($id);
    $category->status=$request->status;
    $category->save();
    return response()->json(['تمت العملية بنجاح'], 200);
   }
   
    public function get_sub_categories(Request $request)
    {
        $sub_categories = Category::where('parent_id',$request->id)->where('id','<>',$request->category_id)->where('status',1)->get();
        return response()->json(['sub_categories'=>$sub_categories], 200);
    }

    public function get_archive()
    {
        $categories = Category::onlyTrashed()->get();
        return view('archives.categories_archive', ['categories'=>$categories] );
    }

    public function restore_archive($id)
    {
        $category = Category::onlyTrashed()->find($id);
        if(!$category){
            return redirect()->back()->with('error', 'لا يوجد مجموعة بهذا الرقم');
        }
        $category->restore();
        return redirect()->back()->with('success', 'تمت العملية بنجاح');
    }
}
