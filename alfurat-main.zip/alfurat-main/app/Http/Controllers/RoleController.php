<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Spatie\Permission\Models\Permission;
use Spatie\Permission\Models\Role;

class RoleController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
        $permissions = Permission::all();
        $roles = Role::all();
        return view('roles.index', compact(['permissions', 'roles']));
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        //
        $request->validate([
            'role' => 'required|string|max:255|unique:roles,name',
            'permissions' => 'required|array',
            'permissions.*' => 'exists:permissions,id',
        ]);
        try {


            $role = Role::firstOrCreate(['name' => $request->role]);

            foreach ($request->permissions as $permission) {
                $permission = Permission::find($permission);
                $role->givePermissionTo($permission);
            }

            return redirect()->route('roles.index')->with('success', 'تم إنشاء الدور بنجاح');
        } catch (\Exception $e) {
            return $e->getMessage();
        }
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        //
        $role = Role::find($id);
        if (!$role) {
            return redirect()->route('roles.index')->with('error', 'الدور غير موجود');
        }
        $permissions = Permission::all();
        return view('roles.edit', compact(['role', 'permissions']));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        //
        $request->validate([
            'role' => 'required|string|max:255',
            'permissions' => 'required|array',
            'permissions.*' => 'exists:permissions,id',
        ]);


        $role = Role::find($id);
        if (!$role) {
            return redirect()->route('roles.index')->with('error', 'الدور غير موجود');
        }
        $permissions = Permission::whereIn('id', $request->permissions)->get();
        $role->name = $request->role;
        $role->save();
        $role->syncPermissions($permissions);

        return redirect()->route('roles.index')->with('success', 'تم تعديل الدور بنجاح');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        //
        $role = Role::find($id);
        if (!$role) {
            return redirect()->route('roles.index')->with('error', 'الدور غير موجود');
        }
        $role->delete();
        return redirect()->route('roles.index')->with('success', 'تم حذف الدور بنجاح');
    }
}
