<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use Validator;

use Illuminate\Http\Request;
use Illuminate\Validation\Rule;

use App\Models\User;

class UserController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $users = User::where('role', 0)->get();
        return view('users', ['users' => $users]);
    }

    public function agents()
    {
        $agents = User::where('role', 1)->get();
        return view('agents', ['agents' => $agents]);
    }

    public function add_agent(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'phone' => [
                'required',
                Rule::unique('users')->where(function ($query) use ($request) {
                    return $query->where('country_code', $request->country_code);
                }),
            ],
            'country_code' => 'required',
        ]);

        if ($validator->fails()) {
            return redirect()->back()->with('error', $validator->errors()->first());
            return response()->json(['message' => $validator->errors()], 422);
        }
        try {
            $user = User::create([
                'name' => $request->name,
                'phone' => $request->phone,
                'country_code' => $request->country_code,
                'role' => 1,
            ]);
            $agents = User::where('role', 1)->get();
            return view('agents', ['agents' => $agents]);
        } catch (\Exception $exception) {
            $agents = User::where('role', 1)->get();
            return view('agents', ['agents' => $agents]);
        }
    }


    public function edit_agent($id)
    {
        $agent = User::find($id);
        return view('agent', ['agent' => $agent]);
    }

    public function update_agent(Request $request, $id)
    {
        $user = User::find($id);
        $user->name = $request->name;
        $user->phone = $request->phone;
        $user->country_code = $request->country_code;
        $user->status = isset($request->status) ? 1 : 0;
        $user->save();

        return redirect('/agents');
    }
    /**
     * Registration Req
     */
    public function register(Request $request)
    {
        $this->validate($request, [
            'name' => 'required|min:4',
            'email' => 'required|email',
            'password' => 'required|min:8',
        ]);
        $user = User::create([
            'name' => $request->name,
            'email' => $request->email,
            'phone' => $request->phone,
            'password' => bcrypt($request->password),
        ]);

        $token = $user->createToken('Laravel8PassportAuth')->accessToken;

        return response()->json(['token' => $token], 200);
    }

    /**
     * Login Req
     */
    public function login(Request $request)
    {
        $data = [
            'phone' => $request->phone,
            'password' => $request->password,
        ];

        if (auth()->attempt($data)) {
            $token = auth()->user()->createToken('Laravel8PassportAuth')->accessToken;
            return response()->json(['token' => $token], 200);
        } else {
            return response()->json(['error' => 'Unauthorised'], 401);
        }
    }

    public function userInfo()
    {
        $user = auth()->user();
        return response()->json(['user' => $user], 200);
    }

    public function show($id = '')
    {
        if (is_numeric($id)) {
            $user = User::find($id);
            return view('user', ['user' => $user]);
        } else {
            $users = User::all();
            return view('users', ['users' => $users]);
        }
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        $user = User::findOrFail($id);
        $user->delete();
        return response()->json(['تمت العملية بنجاح'], 200);
    }
    /**
     * Change the status of a unit group.
     *
     * @param int $id The ID of the unit group.
     * @param string $status The new status of the unit group.
     * @throws \Illuminate\Database\Eloquent\ModelNotFoundException if the unit group with the given ID is not found.
     * @return \Illuminate\Http\JsonResponse The JSON response indicating the success of the operation.
     */
    public function change_status(Request $request)
    {
        $id = $request->id;
        $user = User::findOrFail($id);
        $user->status = $request->status;
        $user->save();
        return response()->json(['تمت العملية بنجاح'], 200);
    }

    public function get_archive()
    {
        $users = User::onlyTrashed()->get();
        return view('archives.users_archive', ['users' => $users]);
    }

    public function agents_get_archive()
    {
        $agents = User::onlyTrashed()->where('role', 1)->get();
        return view('archives.agents_archive', ['agents' => $agents]);
    }

    public function restore_archive($id)
    {
        $agent = User::onlyTrashed()->find($id);
        if (!$agent) {
            return redirect()->back()->with('error', 'لا يوجد مندوب بهذا الرقم');
        }
        $agent->restore();
        return redirect()->back()->with('success', 'تمت العملية بنجاح');
    }
}
