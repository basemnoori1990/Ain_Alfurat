<?php

namespace App\Http\Controllers;

use App\Models\Admin;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;
use Spatie\Permission\Models\Role;

class AdminController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
        $admins = Admin::where('id', '!=', auth()->user()->id)->get();
        $roles = Role::all();
        return view('admins.index', compact(['admins', 'roles']));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        //
        $request->validate([
            'name' => 'required',
            'email' => 'required|email|unique:admins',
            'phone' => 'required',
            'password' => 'required|confirmed',
            'role' => 'required|exists:roles,id'
        ]);

        $admin = Admin::create([
            'name' => $request->name,
            'email' => $request->email,
            'phone' => $request->phone,
            'password' => bcrypt($request->password),
            'status' => 1,
        ]);

        $role = Role::find($request->role);
        $admin->assignRole($role);
        session()->flash('success', 'تم إضافة المسئول بنجاح');
        return redirect()->route('admins.index');
    }
    public function edit(string $id)
    {
        //
        $admin = Admin::find($id);
        $roles = Role::all();
        return view('admins.edit', compact(['admin' , 'roles']));
    }

    public function update(Request $request, string $id)
    {
        //
        try {

            $request->validate([
                'name' => 'required',
                'email' => 'required|email|unique:admins,email,' . $id,
                'phone' => 'required',
                'password' => 'confirmed',
                'role' => 'required|exists:roles,id'
            ]);
            $admin = Admin::find($id);
            
            if (!$admin) {
                session()->flash('error', 'لا يوجد مسئول بهذا الاسم');
                return redirect()->route('admins.index');
            }

            $admin->name = $request->name;
            $admin->email = $request->email;
            $admin->phone = $request->phone;
            if ($request->password) {
                $admin->password = bcrypt($request->password);
            }
            $admin->status =  $request->status == 'on' ? 1 : 0;
            $role = Role::find($request->role);
            $admin->syncRoles([$role]);
            $admin->save();

            session()->flash('success', 'تم تعديل بيانات المسئول بنجاح');
            return redirect()->route('admins.index');
        } catch (\Exception $e) {
            session()->flash('error', 'شئ ما خطأ, حاول مرة أخرى');
            return redirect()->route('admins.index');
        }
    }

    public function destroy(string $id)
    {
        //
        $admin = Admin::find($id);
        $admin->delete();
        return redirect()->back()->with('success', 'تم إضافة مسئول جديد بنجاح');
    }

    public function change_status($id)
    {
        $admin = Admin::find($id);
        $admin->status = $admin->status == 1 ? 0 : 1;
        $admin->save();
        return redirect()->back()->with('success', 'تم تغير الحالة بنجاح');
    }

    public function get_archive()
    {
        $admins = Admin::onlyTrashed()->get();
        return view('admins.archive', ['admins' => $admins]);
    }

    public function restore_archive($id)
    {
        $admin = Admin::onlyTrashed()->find($id);
        if (!$admin) {
            return redirect()->back()->with('error', 'لا يوجد مسئول بهذا الرقم');
        }
        $admin->restore();
        return redirect()->back()->with('success', 'تمت العملية بنجاح');
    }
}
