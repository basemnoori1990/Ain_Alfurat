<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Company;

class CompanyController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $companies = Company::get();
        return view('companies', ['companies' => $companies]);
    }
    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }
    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        try {
            $company = new Company;
            $company->company_name = $request->company_name;
            $company->description = $request->description;
            if ($request->hasfile('logo')) {
                $imagePath = $request->file('logo')->store('images', 'public');
                $company->logo = $imagePath;
            }
            $company->save();
            $companies = Company::all();
            return view('companies', ['companies' => $companies]);
        } catch (\Exception $exception) {
            // throw new HttpException(400, "Invalid data - {$exception->getMessage}");
            $companies = Company::all();
            return view('companies', ['companies' => $companies]);
        }
    }
    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        if (is_numeric($id)) {
            $company = Company::find($id);
            return view('company', ['company' => $company]);
        } else {
            $companies = Company::all();
            return view('companies', ['companies' => $companies]);
        }
    }
    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $company = Company::find($id);
        return view('editcompany', ['company' => $company]);
    }
    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $company = Company::find($id);
        $company->company_name = $request->company_name;
        $company->description = $request->description;
        if ($request->hasfile('logo')) {
            $imagePath = $request->file('logo')->store('images', 'public');
            $company->logo = $imagePath;
        }
        $company->save();
        $companies = Company::all();
        return view('companies', ['companies' => $companies]);
    }
    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $company = Company::findOrFail($id);
        $company->delete();
        return response()->json(['تمت العملية بنجاح'], 200);
    }
    public function change_status(Request $request)
    {
        $id = $request->id;
        $company = Company::findOrFail($id);
        $company->status = $request->status;
        $company->save();
        return response()->json(['تمت العملية بنجاح'], 200);
    }

    public function get_archive()
    {
        $companies = Company::onlyTrashed()->get();
        return view('archives.companies_archive', ['companies'=>$companies] );
    }

    public function restore_archive($id)
    {
        $company = Company::onlyTrashed()->find($id);
        if(!$company){
            return redirect()->back()->with('error', 'لا يوجد شركة بهذا الرقم');
        }
        $company->restore();
        return redirect()->back()->with('success', 'تمت العملية بنجاح');
    }
}
