<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Ads;
use App\Models\Product;
class AdsController extends Controller
{
   
    public function index()
    {
    $ads = Ads::with('product')->get();
    $products = Product::all();
     return view('ads' ,['ads' => $ads, 'products' => $products]);
   }
   /**
    * Show the form for creating a new resource.
    *
    * @return \Illuminate\Http\Response
    */
   public function create()
   {
       //
   }
   /**
    * Store a newly created resource in storage.
    *
    * @param  \Illuminate\Http\Request  $request
    * @return \Illuminate\Http\Response
    */
   public function store(Request $request)
   {
    try {
        $ad=new Ads;
        $imagePath = $request->file('image')->store('images', 'public');

        $ad->title=$request->title;
        $ad->description=$request->description;
        $ad->image=$imagePath;
        $ad->ad_type=$request->ad_type;
        $ad->product_id=$request->product_id;
        $ad->expiration_time=$request->expiration_time;
        $ad->save();
        
        $ads = Ads::all();
        $products = Product::all();

    return view('ads' ,['ads' => $ads, 'products' => $products]);
    } catch(\Exception $exception) {
        $ads = Ads::all();
        // throw new HttpException(400, "Invalid data - {$exception->getMessage}");
        }
   }
   
   public function show($id)
   {
    if(is_numeric($id))
    {
        $ad = Ads::find($id);
        return view('ads' ,['ad' => $ad]);
    }
    else
    {
        $categories = Category::with('parent')->get();
        $main_categories =Category::where('level',1)->get();
    $sub_categories =Category::where('level',2)->get();
    return view('categories' ,['categories' => $categories,    
    'main_categories'=>$main_categories,
    'sub_categories'=>$sub_categories]);
        }  
   }
   /**
    * Show the form for editing the specified resource.
    *
    * @param  int  $id
    * @return \Illuminate\Http\Response
    */
   public function edit($id)
   {
    $ad = Ads::find($id);
    $products = Product::all();
    return view('editad' ,['ad' => $ad, 'products' => $products]);
   }
   /**
    * Update the specified resource in storage.
    *
    * @param  \Illuminate\Http\Request  $request
    * @param  int  $id
    * @return \Illuminate\Http\Response
    */
   public function update(Request $request, $id)
   {
    try {
        $ad=Ads::find($id);
        if ($request->hasfile('image'))
        {
        $imagePath = $request->file('image')->store('images', 'public');
        $ad->image=$imagePath;
        }
        $ad->title=$request->title;
        $ad->description=$request->description;
        $ad->product_id=$request->product_id;
        $ad->ad_type=$request->ad_type;
        $ad->expiration_time=$request->expiration_time;
        $ad->save();
        $products = Product::all();

        $ads = Ads::all();
    return view('ads' ,['ads' => $ads, 'products' => $products]);
    } catch(\Exception $exception) {
        $ads = Ads::all();
        $products = Product::all();

    return view('ads' ,['ads' => $ads, 'products' => $products]);
        // throw new HttpException(400, "Invalid data - {$exception->getMessage}");
        }
   }
   /**
    * Remove the specified resource from storage.
    *
    * @param  int  $id
    * @return \Illuminate\Http\Response
    */
   public function destroy($id)
   {
    $ad = Ads::findOrFail($id);
    $ad->delete();
    return response()->json(['تمت العملية بنجاح'], 200);
   }

   public function change_status(Request $request)
   {
    $id = $request->id;
    $ad = Ads::findOrFail($id);
    $ad->status=$request->status;
    $ad->save();
    return response()->json(['تمت العملية بنجاح'], 200);
   }

   public function get_archive()
    {
        $ads = Ads::onlyTrashed()->with('product')->get();
        return view('archives.ads_archive', ['ads'=>$ads] );
    }

    public function restore_archive($id)
    {
        $ad = Ads::onlyTrashed()->find($id);
        if(!$ad){
            return redirect()->back()->with('error', 'لا يوجد وحدة بهذا الرقم');
        }
        $ad->restore();
        return redirect()->back()->with('success', 'تمت العملية بنجاح');
    }
}