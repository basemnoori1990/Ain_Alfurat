<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;

use Illuminate\Http\Request;
use App\Notifications\UserNotification;
use App\Models\Order;
use App\Models\User;
use LaravelFCM\Services\FCM;
use Google\Client as Google_Client;
use Google\Auth\ApplicationDefaultCredentials;
use Google\Cloud\Core\ServiceBuilder;
class OrderController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $statuses = (new Order())->statuses();
        $orders = Order::with('order_details')->with('user')->with('agent')->get();
        $agents = User::where('role', 1)->where('status', 1)->get();
        return view('orders', ['orders' => $orders, 'statuses' => $statuses, 'agents' => $agents]);
    }
    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }
    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        try {
        } catch (\Exception $exception) {
            // throw new HttpException(400, "Invalid data - {$exception->getMessage}");
        }
    }
    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
    }
    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }
    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }
    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $Order = Order::findOrFail($id);
        $Order->delete();
        return response()->json(['تمت العملية بنجاح'], 200);
    }

    public function change_status(Request $request)
    {
        $id = $request->id;
        $order = Order::findOrFail($id);
        $order->status = $request->status;
        $order->save();

        $user = User::find($order->user_id);
        $recipients = [$user];
        $status = $order->statuses($request->status);
        // $data=['تم تغيير الحالة', 'تم تغيير حالة الطلب إلى '.$status['status_name']];

        // $title = 'تم تغيير حالة الطلب';
        $title = 'رقم الطلب:' . $order->id;
        $body = 'تم تغيير حالة الطلب إلى ' . $status['status_name'];

        $fcm_token = $user->fcm_token;

        // $fcm = new FCM;
        $client = new Google_Client();
        $client->setAuthConfig(base_path('config/' . env('GOOGLE_SERVICE_ACCOUNT')));
        $client->addScope('https://www.googleapis.com/auth/firebase.messaging');
        $client->refreshTokenWithAssertion();
        $token = $client->getAccessToken();
        $apiKey = $token['access_token'];
        $result = $this->sendFCM($fcm_token, $title, $body, $apiKey);
        // $notification = $fcm->sendMessage($result, $title, $body, $data = null);   // $user->notify(new UserNotification('تم تغيير الحالة', 'تم تغيير حالة الطلب إلى '.$status['status_name']));

        return response()->json(['تمت العملية بنجاح'], 200);
    }
    
    public function change_agent(Request $request)
    {
        $id = $request->id;
        $order = Order::findOrFail($id);
        $order->agent_id = $request->agent_id;
        $order->save();
        return response()->json(['تمت العملية بنجاح'], 200);
    }
    //$client->fetchAccessTokenWithAssertion()['access_token'];

    // echo 'OAuth2 Token: ' . $token;
    // Usage example

    function sendFCM($token, $title, $body, $apiKey)
    {
        // FCM endpoint for HTTP v1 API
        $url = 'https://fcm.googleapis.com/v1/projects/dinar-store/messages:send';

        // Payload to send to FCM
        $notification = [
            'message' => [
                'token' => $token,
                'notification' => [
                    'title' => $title,
                    'body' => $body,
                ],
            ],
        ];

        // Initialize cURL
        $ch = curl_init();

        // Set cURL options
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, ['Authorization: Bearer ' . $apiKey, 'Content-Type: application/json']);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($notification));

        // Execute cURL request
        $response = curl_exec($ch);

        // Check for errors
        if ($response === false) {
            $error = curl_error($ch);
            curl_close($ch);
            return 'Curl error: ' . $error;
        }

        // Close cURL
        curl_close($ch);

        // Return response
        return $response;
    }

    public function print_order($id)
    {
        $order = Order::where('id', $id)->with('order_details.products', 'order_details.units')->first();
        return view('order', ['order' => $order]);
    }
}
