<?php

namespace App\Http\Controllers;

use App\Models\Settings;
use App\Http\Requests\StoreSettingsRequest;
use App\Http\Requests\UpdateSettingsRequest;
use Illuminate\Http\Request;
class SettingsController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $settings = Settings::all();
        return view('settings', ['settings' => $settings]);
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $lng = explode(',',$request->location)[0];
        $lat = explode(',',$request->location)[1];
        $price_per_kilometer =$request->price_per_kilometer;
        $min_order = $request->min_order;
        Settings::where('key','lat')->update(['value'=>$lat]);
        Settings::where('key','lng')->update(['value'=>$lng]);
        Settings::where('key','price_per_kilometer')->update(['value'=>$price_per_kilometer]);
        Settings::where('key','min_order')->update(['value'=>$min_order]);
        return redirect()->route('settings.index');
        
    }

    /**
     * Display the specified resource.
     */
    public function show(Settings $settings)
    {
        
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Settings $settings)
    {
        $settings = Settings::all();
        return view('settings', ['settings' => $settings]);
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(UpdateSettingsRequest $request, Settings $settings)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Settings $settings)
    {
        //
    }
}
