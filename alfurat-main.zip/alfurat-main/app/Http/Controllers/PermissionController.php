<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Spatie\Permission\Models\Permission;

class PermissionController extends Controller
{
    public function store(Request $request)
    {
        //
        $request->validate([
            'permission' => 'required|string|max:255|unique:permissions,name',
        ]);
        try {

            Permission::create(['name' => $request->permission]);
            return redirect()->back()->with('success', 'تم إضافة الصلاحية بنجاح');
        } catch (\Exception $e) {
            return redirect()->back()->with('error', $e->getMessage());
        }
    }
}
