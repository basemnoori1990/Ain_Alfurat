<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Product;
use App\Models\Category;
use App\Models\Company;
use App\Models\Unitgroup;
use App\Models\Unit;
use Exception;

class ProductController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $products = Product::with('company')->with('company')->with('category')->with('unit_group')->with('whole_unit')->with('retail_unit')->with('vip_unit')->with('cart_items')->get();
        $categories = Category::where('parent_id', '<>', null)->get();
        $companies = Company::all();
        $unitgroups = Unitgroup::all();
        $units = Unit::all();
        return view('products', [
            'products' => $products,
            'categories' => $categories,
            'companies' => $companies,
            'unitgroups' => $unitgroups,
            'units' => $units
        ]);
    }
    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }
    public function required_products($product_id)
    {
        $products = Product::where('id', '<>', $product_id)->get();
        $product = Product::where('id', $product_id)->with('required_products')->first();
        return view('required_products', [
            'product' => $product,
            'products' => $products,
            'required_products' => $products
        ]);
    }

    public function get_product_units($product_id)
    {
        $product = Product::where('id', $product_id)->with('whole_unit')->with('retail_unit')->first(['whole_unit_id', 'retail_unit_id']);
        // dd($product);
        return response()->json(['product' => $product]);
    }

    public function get_products($product_id)
    {
        $products = Product::where('id', '!=', $product_id)->get();
        // dd($product);
        return response()->json(['products' => $products]);
    }
    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {

        try {
            // $product = new Product;
            // $product=Product::create($request->all()); 
            $product = new Product;
            $imagePath = $request->file('image')->store('images', 'public');

            $product->product_name = $request->product_name;
            $product->description = $request->description;
            $product->image = $imagePath;
            $product->whole_sale_price = $request->whole_sale_price;
            $product->retail_price = $request->retail_price;
            $product->vip_price = $request->vip_price;
            $product->category_id = $request->category_id;
            $product->company_id = $request->company_id;
            $product->unit_group_id = $request->unit_group_id;
            $product->whole_unit_id = $request->whole_unit_id;
            $product->retail_unit_id = $request->retail_unit_id;
            $product->vip_unit_id = $request->vip_unit_id;
            $product->discount = $request->discount;
            $product->min_whole_quantity = $request->min_whole_quantity;
            $product->min_retail_quantity = $request->min_retail_quantity;
            $product->min_vip_quantity = $request->min_vip_quantity;
            $product->max_whole_quantity = $request->max_whole_quantity;
            $product->max_retail_quantity = $request->max_retail_quantity;
            $product->save();

            $products = Product::with('company')->with('company')->with('category')->with('unit_group')->with('whole_unit')->with('retail_unit')->with('vip_unit')->with('cart_items')->get();
            $categories = Category::where('parent_id', '<>', null)->get();
            $companies = Company::all();
            $unitgroups = Unitgroup::all();
            $units = Unit::all();
            return view('products', [
                'products' => $products,
                'categories' => $categories,
                'companies' => $companies,
                'unitgroups' => $unitgroups,
                'units' => $units
            ]);
        } catch (\Exception $exception) {
            // throw new HttpException(400, "Invalid data - {$exception->getMessage}");
            $products = Product::with('company')->with('company')->with('category')->with('unit_group')->with('whole_unit')->with('retail_unit')->with('vip_unit')->with('cart_items')->get();
            $categories = Category::where('parent_id', '<>', null)->get();
            $companies = Company::all();
            $unitgroups = Unitgroup::all();
            $units = Unit::all();
            return view('products', [
                'products' => $products,
                'categories' => $categories,
                'companies' => $companies,
                'unitgroups' => $unitgroups,
                'units' => $units
            ]);
        }
    }
    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        if (is_numeric($id)) {
            $product = Product::find($id);
            return view('product', ['product' => $product]);
        } else {
            $products = Product::with('company')->with('company')->with('category')->with('unit_group')->with('whole_unit')->with('retail_unit')->with('vip_unit')->with('cart_items')->get();
            $categories = Category::where('parent_id', '<>', null)->get();
            $companies = Company::all();
            $unitgroups = Unitgroup::all();
            $units = Unit::all();
            return view('products', [
                'products' => $products,
                'categories' => $categories,
                'companies' => $companies,
                'unitgroups' => $unitgroups,
                'units' => $units
            ]);
        }
    }
    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $product = Product::find($id);
        $categories = Category::where('parent_id', '<>', null)->get();
        $companies = Company::all();
        $unitgroups = Unitgroup::all();
        $units = Unit::all();
        return view('editproduct', [
            'product' => $product,
            'categories' => $categories,
            'companies' => $companies,
            'unitgroups' => $unitgroups,
            'units' => $units
        ]);
    }
    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function add_required_product(Request $request)
    {
        try {
            $product = Product::find($request->product_id);
            $result = $product->required_products()->attach(
                $request->product_id,
                [
                    'unit_id' => $request->unit_id,
                    'quantity' => $request->quantity,
                    'required_product_id' => $request->required_product_id,
                    'required_unit_id' => $request->required_unit_id,
                    'required_quantiy' => $request->required_quantiy
                ]
            );
            return redirect()->back()->with('message', "تم الحفظ بنجاح");
        } catch (Exception $ex) {
            return redirect()->back()->with('message', "يوجد خطأ - " . $ex->getMessage());
        }
    }
    public function update(Request $request, $id)
    {
         try {
    $product = Product::find($id);

    if (!$product) {
        return redirect()->back()->with('error', '❌ المنتج غير موجود.');
    }

    // حفظ الأسعار القديمة قبل التعديل
    $old_whole_price  = $product->whole_sale_price;
    $old_retail_price = $product->retail_price;
    $old_vip_price    = $product->vip_price;

    // تحديث الصورة إذا وُجدت
    if ($request->hasFile('image')) {
        $imagePath = $request->file('image')->store('images', 'public');
        $product->image = $imagePath;
    }

    // تحديث بيانات المنتج
    $product->product_name = $request->product_name;
    $product->description = $request->description;
    $product->whole_sale_price = $request->whole_sale_price;
    $product->retail_price = $request->retail_price;
    $product->vip_price = $request->vip_price;
    $product->category_id = $request->category_id;
    $product->company_id = $request->company_id;
    $product->unit_group_id = $request->unit_group_id;
    $product->whole_unit_id = $request->whole_unit_id;
    $product->retail_unit_id = $request->retail_unit_id;
    $product->vip_unit_id = $request->vip_unit_id;
    $product->discount = $request->discount;
    $product->min_whole_quantity = $request->min_whole_quantity;
    $product->min_retail_quantity = $request->min_retail_quantity;
    $product->min_vip_quantity = $request->min_vip_quantity;
    $product->max_whole_quantity = $request->max_whole_quantity;
    $product->max_retail_quantity = $request->max_retail_quantity;
    $product->save();

    // ✅ تحديث الأسعار في جدول cart إذا تغيّر السعر
    if (
        $old_whole_price != $product->whole_sale_price ||
        $old_retail_price != $product->retail_price ||
        $old_vip_price != $product->vip_price
    ) {
        $cartItems = \App\Models\Cart::where('product_id', $product->id)->get();

        foreach ($cartItems as $cartItem) {
            switch ($cartItem->unit_type) {
                case 'whole':
                    if ($cartItem->unit_id == $product->whole_unit_id) {
                        $cartItem->price = $product->whole_sale_price* $cartItem->quantity;
                    }
                    break;

                case 'retail':
                    if ($cartItem->unit_id == $product->retail_unit_id) {
                        $cartItem->price = $product->retail_price* $cartItem->quantity;
                    }
                    break;

                case 'vip':
                    if ($cartItem->unit_id == $product->vip_unit_id ) {
                        
                        $cartItem->price = $product->vip_price* $cartItem->quantity;
                        
                    }
                    break;
            }

            // تحديث الإجمالي إن وُجدت الكمية
            //if (isset($cartItem->quantity)) {
              //  $cartItem->total = $cartItem->price * $cartItem->quantity;
            //}

            $cartItem->save();
        }
    }

    // إعادة تحميل البيانات للعرض
    $products = Product::with([
        'company',
        'category',
        'unit_group',
        'whole_unit',
        'retail_unit',
        'vip_unit'
    ])->get();

    $categories = Category::whereNotNull('parent_id')->get();
    $companies  = Company::all();
    $unitgroups = Unitgroup::all();
    $units      = Unit::all();

    return view('products', compact('products', 'categories', 'companies', 'unitgroups', 'units'))
        ->with('success', '✅ تم تحديث المنتج وتعديل أسعار السلة تلقائيًا.');
}
catch (\Exception $exception) {
    \Log::error('خطأ أثناء تحديث المنتج: ' . $exception->getMessage());

    $products = Product::with([
        'company',
        'category',
        'unit_group',
        'whole_unit',
        'retail_unit',
        'vip_unit'
    ])->get();

    $categories = Category::whereNotNull('parent_id')->get();
    $companies  = Company::all();
    $unitgroups = Unitgroup::all();
    $units      = Unit::all();

    return view('products', compact('products', 'categories', 'companies', 'unitgroups', 'units'))
        ->with('error', 'حدث خطأ أثناء التحديث.');
}

    }
    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $product = Product::findOrFail($id);
        $product->delete();
        return response()->json(['تمت العملية بنجاح'], 200);
    }

    public function updateStatus(Request $request)
    {
        $product = Product::findOrFail($request->id);
        $product->status = $request->status;
        $product->save();

        return response()->json(['success' => true, 'message' => 'تمت العملية بنجاح']);
    }

    
   public function change_status(Request $request)
   {
    $id = $request->id;
    $product = Product::findOrFail($id);
    $product->status=$request->status;
    $product->save();
    return response()->json(['تمت العملية بنجاح'], 200);
   }

   public function get_archive()
    {
        $products = Product::onlyTrashed()->get();
        return view('archives.products_archive', ['products'=>$products] );
    }

    public function restore_archive($id)
    {
        $product = Product::onlyTrashed()->find($id);
        if(!$product){
            return redirect()->back()->with('error', 'لا يوجد منتج بهذا الرقم');
        }
        $product->restore();
        return redirect()->back()->with('success', 'تمت العملية بنجاح');
    }
}
