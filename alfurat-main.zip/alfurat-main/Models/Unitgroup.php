<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;


class Unitgroup extends Model
{
    use HasFactory;
    use SoftDeletes;

    protected $dates = ['deleted_at']; 

    protected $table ='unit_groups';
    protected $fillable = [
        'unit_group_name',
        'description',
        'status'
    ];

    protected $casts = ['status'=>'integer'];

}