<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;


class Store extends Model
{
    use HasFactory;
    use SoftDeletes;
    
    protected $dates = ['deleted_at']; 

    protected $fillable = [
        'id',
        'owner_name',
        'store_name',
        'district',
        'address',
        'phone',
        'lng',
        'lat',
        'status',
    ];

    protected $casts = ['lat'=>'float','lng'=>'float','status'=>'integer'];


    public function user()
    {
        return $this->belongsTo(User::class,'user_id','id');
    }

}
