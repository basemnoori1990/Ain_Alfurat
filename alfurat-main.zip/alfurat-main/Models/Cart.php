<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use App\Models\User;
use App\Models\Product;
use App\Models\Unit;
use Illuminate\Database\Eloquent\SoftDeletes;

class Cart extends Model
{
    use HasFactory;
    use SoftDeletes;
    protected $dates = ['deleted_at']; 

protected $table = 'cart';
    protected $fillable = [
    'id',
    'product_id',
    'user_id',
    'quantity',
    'price',
    'unit_id',
    'ref_cart_id',
    'is_required',
    'unit_type',
    'status'
    ];

    protected $casts = ['product_id'=>'integer',
    'user_id'=>'integer',
    'quantity'=>'float',
    'price'=>'float',
    'unit_id'=>'integer',
    'ref_cart_id'=>'integer',
    'is_required'=>'integer',
    'status'=>'integer'
    ];

    public function user()
    {
        return $this->belongsTo(User::class,'user_id');
    }

public function unit()
    {
        return $this->belongsTo(Unit::class,'unit_id');
    }
    public function product()
    {
        return $this->belongsTo(Product::class,"product_id");
    }
}
