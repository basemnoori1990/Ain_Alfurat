<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;


class Address extends Model
{
    use HasFactory;
    use SoftDeletes;
    protected $dates = ['deleted_at']; 

    protected $fillable = [
        'user_id',
        'city',
        'country',
        'postcode',
        'street',
        'building',
        'floor',
        'phone',
        'notes',
        'lat',
        'lng'
    ];

    protected $casts = ['user_id'=>'integer','lat'=>'float','lng'=>'float'];

    protected $hidden = ['created_at','updated_at','deleted_at','token'];
    
    public function users(){
        return $this->belongsTo(User::class, 'user_id');
    }

}
