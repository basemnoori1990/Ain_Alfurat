<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;


class Unit extends Model
{
    use HasFactory;
    use SoftDeletes;
    
    protected $dates = ['deleted_at']; 

    protected $fillable = [
        'unit_name',
        'eq',
        'unit_group_id',
        'status'
    ];

    protected $casts = ['unit_group_id'=>'integer','status'=>'integer','eq'=>'float'];

    public function unit_group()
    {
        return $this->belongsTo(Unitgroup::class,'unit_group_id','id');
    }

}
