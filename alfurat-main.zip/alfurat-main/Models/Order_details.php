<?php

namespace App\Models;

use App\Models\Order;
use App\Models\Product;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\SoftDeletes;

class Order_details extends Model
{
    use HasFactory;
    use SoftDeletes;

    protected $dates = ['deleted_at']; 


    protected $fillable = [
        'order_id',
        'product_id',
        'unit_id',
        'qty',
        'price',
        'sub_total',
    ];
    protected $casts = ['product_id'=>'integer',
                        'unit_id'=>'integer',
                        'qty'=>'float',
                        'price'=>'float',
                        'sub_total'=>'float'];


    public function orders(){
        return $this->belongsTo(Order::class, 'order_id');
    }

    public function products(){
        return $this->belongsTo(Product::class, 'product_id');
    }


    public function units(){
        return $this->belongsTo(Unit::class, 'unit_id');
    }
}
