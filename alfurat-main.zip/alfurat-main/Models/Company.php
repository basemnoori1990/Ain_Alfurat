<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use App\Models\Product;
use Illuminate\Database\Eloquent\SoftDeletes;

class Company extends Model
{
    use HasFactory;
    use SoftDeletes;
    protected $dates = ['deleted_at']; 

    protected $fillable = [
        'company_name',
        'description',
        'logo',
        'status',
    ];
    protected $casts = ['status'=>'integer'];


    /**
     * The attributes that should be hidden for serialization.
     *
     * @var array<int, string>
     */
    protected $hidden = [
       
    ];
    public function Products()
    {
        return $this->hasMany(Product::class,'company_id','id');
    }

}
