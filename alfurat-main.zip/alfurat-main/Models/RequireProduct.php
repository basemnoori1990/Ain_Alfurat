<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\Pivot;

class RequireProduct extends Pivot
{
    protected $table = 'required_products';

    protected $fillable = [
        'product_id',
        'required_product_id',
        'unit_id',
        'quantity',
        'required_unit_id',
        'required_quantiy',
        'status'
    ];

    public function base_product()
    {
        return $this->belongsTo(Product::class, 'product_id');
    }

    public function required_product()
    {
        return $this->belongsTo(Product::class, 'required_product_id');
    }

    public function base_unit()
    {
        return $this->belongsTo(Unit::class, 'unit_id');
    }

    public function required_unit()
    {
        return $this->belongsTo(Unit::class, 'required_unit_id');
    }
    protected $casts = ['product_id' => 'integer', 'required_product_id' => 'integer', 'unit_id' => 'integer', 'required_unit_id' => 'integer', 'quantity' => 'float', 'required_quantity' => 'float', 'status' => 'integer'];
}
