<?php

namespace App\Models;

use App\Models\User;
use App\Models\Order_details;
use App\Models\Address;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\SoftDeletes;


class Order extends Model
{
    use HasFactory;
    use SoftDeletes;

    protected $dates = ['deleted_at']; 

    protected $fillable = [
        'user_id',
        'address',
        'order_date',
        'status',
        'sub_total',
        'tax',
        'discount',
        'total',
        'payment_method',
        'location',
        'delivery_fees',
        'delivery_time',
        'status'
    ];

    public function user(){
        return $this->belongsTo(User::class, 'user_id');
    }

    public function order_details(){
        return $this->hasMany(Order_details::class);
    }

    public function statuses($status_id='')
    {
        $statuses = [
        ['id'=>1,'status_name'=>'طلبك قيد المراجعة'],
        ['id'=>2,'status_name'=>'قيد التحضير'],
        ['id'=>3,'status_name'=>'قيد التوصيل'],
        ['id'=>4,'status_name'=>'تم التوصيل'],
        ['id'=>5,'status_name'=>'تم الغاء الطلب'],
        ['id'=>6,'status_name'=>'تم الارجاع']
        ];
        if (is_numeric($status_id))
        {
            $index = array_search($status_id, array_column($statuses, 'id'));
            return $statuses[$index];
        }
        return $statuses;
    }

}
