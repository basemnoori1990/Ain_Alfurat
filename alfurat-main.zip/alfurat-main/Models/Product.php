<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use App\Models\Company;
use App\Models\Category;
use App\Models\Unit;
use App\Models\Cart;
use App\Models\Unitgroup;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;


class Product extends Model
{
    use HasFactory;
    use SoftDeletes;

    protected $dates = ['deleted_at']; 

    protected $fillable = [
        'product_name',
        'description',
        'image',
        'whole_sale_price',
        'retail_price',
        'vip_price',
        'category_id',
        'company_id',
        'unit_group_id',
        'whole_unit_id',
        'retail_unit_id',
        'vip_unit_id',
        "min_whole_quantity",
        "min_retail_quantity",
        "min_vip_quantity",
        "max_whole_quantity",
        "max_retail_quantity",
        'discount',
        'status'
    ];
    protected $casts = ['min_whole_quantity'=>'float','min_retail_quantity'=>'float','min_vip_quantity'=>'float','max_whole_quantity'=>'float','max_retail_quantity'=>'float','category_id'=>'integer','company_id'=>'integer','unit_group_id'=>'integer','whole_unit_id'=>'integer','retail_unit_id'=>'integer','vip_unit_id'=>'integer','whole_sale_price'=>'float','retail_price'=>'float','vip_price'=>'float','discount'=>'float','status'=>'integer'];


    public function company()
    {
        return $this->belongsTo(Company::class,'company_id');
    }

    public function category()
    {
        return $this->belongsTo(Category::class,'category_id');
    }
    public function unit_group()
    {
        return $this->belongsTo(Unitgroup::class,'unit_group_id');
    }
    public function whole_unit()
    {
        return $this->belongsTo(Unit::class,'whole_unit_id');
    }
    public function retail_unit()
    {
        return $this->belongsTo(Unit::class,'retail_unit_id');
    }
    public function vip_unit()
    {
        return $this->belongsTo(Unit::class,'vip_unit_id');
    }
    public function cart_items()
    {
        return $this->hasMany(Cart::class);
    }
    public function required_products():BelongsToMany
    {
        return $this->belongsToMany(Product::class, 'required_products', 'product_id', 'required_product_id')->using(RequireProduct::class)
                    ->withPivot('unit_id', 'quantity', 'required_unit_id', 'required_quantiy', 'status');
    
            
    }
}
